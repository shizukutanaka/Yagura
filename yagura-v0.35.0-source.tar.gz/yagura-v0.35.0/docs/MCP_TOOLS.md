# MCP tools reference

Generated from a live yagura — **47 tools**.

Tools are tagged `[G]` (guide / feedforward) or `[S]` (sensor / feedback) per the [Fowler harness taxonomy](https://martinfowler.com/articles/harness-engineering.html).

---

## Table of contents

- [Alerts](#alerts) (2)
- [Graph](#graph) (3)
- [Handoff](#handoff) (1)
- [Harness (guides)](#harness-guides) (8)
- [Inventory](#inventory) (8)
- [Misc](#misc) (9)
- [Observability](#observability) (4)
- [Plan tracking](#plan-tracking) (2)
- [Security (sensors)](#security-sensors) (10)

---

## Alerts

### `yagura_alert_fix`

[S] Aggregate health signals across portfolio. Returns actionable alerts with suggested_tool + args.

**Arguments:**

| Name | Required | Description |
|---|---|---|
| `open_issues_high` (integer) |  |  |
| `scorecard_min` (number) |  |  |
| `severity_min` (string) |  |  |
| `slug` (string) |  |  |
| `stale_days` (integer) |  |  |

---

### `yagura_alert_resolve`

[G] Manage alert lifecycle: resolve/snooze/reopen. Persists to {state_dir}/alert_state.jsonl.

**Arguments:**

| Name | Required | Description |
|---|---|---|
| `action` (string) | ★ |  |
| `alert_id` (string) | ★ |  |
| `note` (string) |  |  |
| `snooze_days` (integer) |  |  |

---

## Graph

### `yagura_graph_impact`

[G] Project impact (transitive reverse deps). Cycle-aware.

**Arguments:**

| Name | Required | Description |
|---|---|---|
| `slug` (string) | ★ |  |

---

### `yagura_graph_neighbors`

[G] Graph walk from slug. Returns direct + N-hop deps/dependents.

**Arguments:**

| Name | Required | Description |
|---|---|---|
| `depth` (integer) |  | max hops (default 2, max 10) |
| `slug` (string) | ★ | project slug to explore from |

---

### `yagura_graph_stats`

[G] Graph stats: nodes/edges/hubs + dangling deps.

---

## Handoff

### `yagura_handoff`

[S] Handoff: save + mark + launch target. dry_run optional.

**Arguments:**

| Name | Required | Description |
|---|---|---|
| `dry_run` (boolean) |  |  |
| `free_notes` (string) |  |  |
| `target` (string) | ★ |  |
| `workspace` (string) |  |  |

---

## Harness (guides)

### `yagura_agents_md`

[G] Generate AGENTS.md for a registered project from Plan.md + registry facts. Cross-tool: Claude Code / Codex / Cursor.

**Arguments:**

| Name | Required | Description |
|---|---|---|
| `include_rules` (boolean) |  | Include house rules section (default true) |
| `slug` (string) | ★ |  |
| `write` (boolean) |  | Also write to {local_path}/AGENTS.md (v0.33.0) |

---

### `yagura_feature_list`

[G] Convert Plan.md into Anthropic-style feature-list.json for long-running agent harnesses.

**Arguments:**

| Name | Required | Description |
|---|---|---|
| `slug` (string) | ★ |  |
| `write` (boolean) |  | Also write to {local_path}/feature-list.json (v0.33.0) |

---

### `yagura_harness_coverage`

[G] Self-audit: which Fowler taxonomy quadrants does yagura cover? Returns guides/sensors × computational/inferential matrix.

---

### `yagura_harness_recommend`

[G] Claude Code .claude/ scaffold by slug or language.

**Arguments:**

| Name | Required | Description |
|---|---|---|
| `language` (string) |  | language override (go/typescript/python/rust/...) |
| `slug` (string) |  | project slug (looks up language from registry) |

---

### `yagura_init_sh`

[G] Generate init script (sh or PowerShell) for long-running agent sessions (Anthropic 2-agent harness).

**Arguments:**

| Name | Required | Description |
|---|---|---|
| `slug` (string) | ★ |  |
| `target` (string) |  | 'posix' (default, init.sh) or 'powershell'/'windows' (init.ps1). |
| `write` (boolean) |  | Also write to {local_path}/init.{sh,ps1}. |

---

### `yagura_progress_file`

[G] Generate claude-progress.txt for cross-session handoff (Anthropic 2-agent harness pattern).

**Arguments:**

| Name | Required | Description |
|---|---|---|
| `note` (string) |  | Optional free-form intent / state. |
| `slug` (string) | ★ |  |
| `write` (boolean) |  | Also write to {local_path}/claude-progress.txt |

---

### `yagura_skill_audit`

[G] SKILL.md audit: trigger, Gotchas, length. 0-100 score + retire signal.

**Arguments:**

| Name | Required | Description |
|---|---|---|
| `content` (string) | ★ | full SKILL.md text including frontmatter |

---

### `yagura_subagent_audit`

[G] Subagent .md audit: prompt style, tools, description.

**Arguments:**

| Name | Required | Description |
|---|---|---|
| `content` (string) | ★ | full subagent .md text including frontmatter |

---

## Inventory

### `yagura_get`

[G] Get project by slug.

**Arguments:**

| Name | Required | Description |
|---|---|---|
| `slug` (string) | ★ |  |

---

### `yagura_list`

[G] List projects (compact). Optional limit caps rows.

**Arguments:**

| Name | Required | Description |
|---|---|---|
| `limit` (integer) |  | 最大返却件数(省略時は全件)。トークン節約用。 |

---

### `yagura_register`

[G] Register project.

**Arguments:**

| Name | Required | Description |
|---|---|---|
| `depends_on` (array) |  |  |
| `display_name` (string) |  |  |
| `language` (string) |  |  |
| `local_path` (string) |  |  |
| `notes` (string) |  |  |
| `priority` (integer) |  |  |
| `repository` (string) | ★ |  |
| `slug` (string) | ★ |  |
| `stage` (string) |  |  |
| `tags` (array) |  |  |

---

### `yagura_search`

[G] Search projects: tag/lang/stage/text (AND).

**Arguments:**

| Name | Required | Description |
|---|---|---|
| `language` (string) |  | 言語完全一致 (大文字小文字無視) |
| `limit` (integer) |  | 最大返却件数(省略時は全件)。 |
| `query` (string) |  | slug/name/notes/tags を横断する部分一致 |
| `stage` (string) |  | active / maintenance / paused / archived |
| `tag` (string) |  | tag 完全一致 (大文字小文字無視) |

---

### `yagura_stats`

[G] Portfolio counts/totals/averages.

---

### `yagura_today`

[G] Top projects today by score.

**Arguments:**

| Name | Required | Description |
|---|---|---|
| `limit` (integer) |  |  |

---

### `yagura_unregister`

[G] Unregister project (hard delete).

**Arguments:**

| Name | Required | Description |
|---|---|---|
| `slug` (string) | ★ |  |

---

### `yagura_update`

[G] Update project manual fields. Omit field = unchanged.

**Arguments:**

| Name | Required | Description |
|---|---|---|
| `depends_on` (array) |  |  |
| `display_name` (string) |  |  |
| `language` (string) |  |  |
| `local_path` (string) |  |  |
| `notes` (string) |  |  |
| `priority` (integer) |  |  |
| `slug` (string) | ★ |  |
| `stage` (string) |  |  |
| `tags` (array) |  |  |

---

## Misc

### `yagura_dedupe_stats`

[S] Content cache stats: hits/misses/bytes saved. Visualizes redundant-read prevention.

---

### `yagura_heartbeat`

[S] Agent heartbeat (~5min). Detects stale agents.

**Arguments:**

| Name | Required | Description |
|---|---|---|
| `agent` (string) | ★ |  |

---

### `yagura_parallel_plan`

[G] Plan parallel task fan-out across AI agents.

**Arguments:**

| Name | Required | Description |
|---|---|---|
| `agents` (array) | ★ | AI agents to fan out to. Each: {name, tier, capacity_percent?, max_concurrency?}. |
| `global_concurrency` (integer) |  |  |
| `strategy` (string) |  |  |
| `task_count` (integer) |  | Shorthand: N uniform unit-weight tasks (task-1..task-N) when 'tasks' omitted. |
| `tasks` (array) |  | Independent work items. Each: {id, weight?, min_tier?}. |

---

### `yagura_quota_forecast`

[S] Empty-time linreg forecast. Needs ≥3 samples.

**Arguments:**

| Name | Required | Description |
|---|---|---|
| `agent` (string) | ★ |  |

---

### `yagura_session_load`

[S] Load handoff context. Null if none.

---

### `yagura_session_save`

[S] Save handoff context.

**Arguments:**

| Name | Required | Description |
|---|---|---|
| `active_files` (array) |  |  |
| `branch` (string) |  |  |
| `free_notes` (string) |  |  |
| `last_commit` (string) |  |  |
| `open_todos` (array) |  |  |
| `plan_md_step` (string) |  |  |
| `saved_by` (string) |  |  |
| `workspace` (string) | ★ |  |

---

### `yagura_token_stats`

[S] Per-tool byte counts since daemon start.

---

### `yagura_tools_catalog`

[G] Full tool details lookup. Use when compact mode hides info you need.

**Arguments:**

| Name | Required | Description |
|---|---|---|
| `name` (string) |  |  |
| `query` (string) |  |  |

---

### `yagura_usage_summary`

[S] Agent usage summary + sparkline. Both agents by default.

**Arguments:**

| Name | Required | Description |
|---|---|---|
| `agent` (string) |  |  |

---

## Observability

### `yagura_agent_status`

[S] Get both agents' quota state + recommended next agent.

---

### `yagura_hook_stats`

[S] Aggregate Claude Code hook stats per project (event counts, errors, top tools).

**Arguments:**

| Name | Required | Description |
|---|---|---|
| `slug` (string) |  | Project slug. Empty = all projects. |
| `top_n` (integer) |  | Top-N tools. Default 10. |

---

### `yagura_hook_timeline`

[S] Recent Claude Code hook events for a project. Use to see what tools agents have invoked recently.

**Arguments:**

| Name | Required | Description |
|---|---|---|
| `event_type` (string) |  | Filter by hook_event_name (PreToolUse, PostToolUse, Stop, …). |
| `hours` (integer) |  | Look-back window. Default 24. |
| `limit` (integer) |  | Max events returned. Default 100, capped at 500. |
| `slug` (string) |  | Project slug. Empty = all projects. |

---

### `yagura_quota_report`

[S] Report agent quota. Triggers auto-handoff.

**Arguments:**

| Name | Required | Description |
|---|---|---|
| `agent` (string) | ★ |  |
| `remaining_percent` (integer) | ★ |  |
| `source` (string) |  |  |
| `weekly_resets_at` (string) |  |  |
| `window_resets_at` (string) |  |  |

---

## Plan tracking

### `yagura_plan_status`

[G] Plan.md progress for project. Parses checkboxes + required sections (目的/スコープ/フェーズ/DoD).

**Arguments:**

| Name | Required | Description |
|---|---|---|
| `slug` (string) | ★ |  |

---

### `yagura_release_radar`

[S] Cross-project release readiness ranking. Aggregates Plan/CI/issues/quality/AI-risk.

**Arguments:**

| Name | Required | Description |
|---|---|---|
| `limit` (integer) |  |  |
| `scan_code` (boolean) |  |  |

---

## Security (sensors)

### `yagura_ai_verify`

[G] AI code risk audit. 6 categories: auth/billing/data/external/crypto/secret. 2x multiplier inside AI-marker zones.

**Arguments:**

| Name | Required | Description |
|---|---|---|
| `files` (object) |  |  |
| `path` (string) |  |  |
| `summary_only` (boolean) |  |  |
| `text` (string) |  |  |

---

### `yagura_gha_audit`

[G] GHA workflow audit: 7 supply-chain risk patterns.

**Arguments:**

| Name | Required | Description |
|---|---|---|
| `files` (object) | ★ |  |
| `summary_only` (boolean) |  |  |

---

### `yagura_health`

[S] Security summary: vuln + Scorecard issues. Cached.

**Arguments:**

| Name | Required | Description |
|---|---|---|
| `individual` (boolean) |  |  |
| `slug` (string) |  |  |

---

### `yagura_pin_drift`

[G] GHA SHA pin verify via API. Detects drift/stale.

**Arguments:**

| Name | Required | Description |
|---|---|---|
| `concurrency` (integer) |  |  |
| `files` (object) | ★ |  |
| `summary_only` (boolean) |  |  |

---

### `yagura_quality_check`

[G] Code lint: as any, ts-ignore, TODO. 3 severity tiers.

**Arguments:**

| Name | Required | Description |
|---|---|---|
| `files` (object) |  |  |
| `language` (string) |  |  |
| `summary_only` (boolean) |  |  |
| `text` (string) |  |  |

---

### `yagura_sbom`

[G] yagura SBOM CycloneDX 1.5. Set summary_only for compact.

**Arguments:**

| Name | Required | Description |
|---|---|---|
| `summary_only` (boolean) |  |  |

---

### `yagura_scorecard`

[S] OpenSSF Scorecard fetch. priority_only=top 7 checks.

**Arguments:**

| Name | Required | Description |
|---|---|---|
| `priority_only` (boolean) |  | 重要 7 check に絞る |
| `repo` (string) |  | owner/repo 形式 |
| `slug` (string) |  |  |

---

### `yagura_secretscan`

[G] Secret scan: 14 patterns + entropy. Redacts hits.

**Arguments:**

| Name | Required | Description |
|---|---|---|
| `min_severity` (string) |  |  |
| `slug` (string) |  |  |

---

### `yagura_test_audit`

[G] Source-test coverage detection. Go/TS/JS/Python/Rust/Java filename + Rust inline #[cfg(test)] + Python doctest.

**Arguments:**

| Name | Required | Description |
|---|---|---|
| `files` (object) | ★ |  |
| `untested_only` (boolean) |  |  |

---

### `yagura_vulns`

[S] OSV.dev vulns by CVSS desc.

**Arguments:**

| Name | Required | Description |
|---|---|---|
| `ecosystem` (string) |  | OSV ecosystem(Go/PyPI/npm 等) |
| `min_severity` (string) |  |  |
| `package` (string) |  | パッケージ識別子(Go module path 等) |
| `slug` (string) |  | 登録済みプロジェクトの slug |
| `version` (string) |  | バージョン文字列(省略時は全バージョン) |

---

## Generation

Auto-generated from `tools/list`. Regenerate with `make docs-mcp`.
