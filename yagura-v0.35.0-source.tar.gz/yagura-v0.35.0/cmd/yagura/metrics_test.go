package main

import (
	"bytes"
	"net/http/httptest"
	"os"
	"path/filepath"
	"strings"
	"testing"

	"github.com/shizukutanaka/yagura/internal/hookreceiver"
	"github.com/shizukutanaka/yagura/internal/mcp"
	"github.com/shizukutanaka/yagura/internal/project"
	"github.com/shizukutanaka/yagura/internal/promexport"
	"github.com/shizukutanaka/yagura/internal/registry"
)

func TestCollectYaguraMetrics_HookToolCalls(t *testing.T) {
	dir := t.TempDir()
	reg, err := registry.New(filepath.Join(dir, "projects"))
	if err != nil {
		t.Fatal(err)
	}
	proj := filepath.Join(dir, "breeze")
	if err := os.MkdirAll(proj, 0o755); err != nil {
		t.Fatal(err)
	}
	if err := reg.Add(&project.Project{
		Slug: "breeze", DisplayName: "Breeze", Repository: "o/breeze",
		LocalPath: proj, Stage: project.StageActive,
	}); err != nil {
		t.Fatal(err)
	}
	hr, err := hookreceiver.NewReceiver(filepath.Join(dir, "hooks.jsonl"), &registryLookup{reg: reg}, 100)
	if err != nil {
		t.Fatal(err)
	}
	// a Claude Code tool event and a foreign-agent (Gemini) one, both in the project cwd
	for _, payload := range []string{
		`{"hook_event_name":"PreToolUse","tool_name":"Bash","cwd":"` + proj + `"}`,
		`{"agent":"gemini_cli","event":"beforeToolCall","tool":"Bash","cwd":"` + proj + `"}`,
	} {
		req := httptest.NewRequest("POST", "/hooks/agent", strings.NewReader(payload))
		hr.Handle(httptest.NewRecorder(), req)
	}

	cols := collectYaguraMetrics(mcp.New("", nil), hr)
	var buf bytes.Buffer
	if err := promexport.Render(&buf, cols); err != nil {
		t.Fatal(err)
	}
	out := buf.String()
	if !strings.Contains(out, "yagura_hook_tool_calls_total") {
		t.Fatalf("per-tool hook metric missing:\n%s", out)
	}
	if !strings.Contains(out, `project="breeze"`) || !strings.Contains(out, `tool="Bash"`) {
		t.Errorf("expected project/tool labels:\n%s", out)
	}
	// both agents counted under the same tool → value 2
	if !strings.Contains(out, `tool="Bash"} 2`) {
		t.Errorf("expected 2 Bash calls across agents:\n%s", out)
	}
}
