package main

import (
	"testing"

	"github.com/shizukutanaka/yagura/internal/alertfix"
	"github.com/shizukutanaka/yagura/internal/project"
	"github.com/shizukutanaka/yagura/internal/registry"
)

func TestHealthSweep_FlagsCriticalVuln(t *testing.T) {
	reg, err := registry.New(t.TempDir())
	if err != nil {
		t.Fatal(err)
	}
	if err := reg.Add(&project.Project{
		Slug: "breeze", DisplayName: "Breeze", Repository: "github.com/o/breeze",
		Stage: project.StageActive,
	}); err != nil {
		t.Fatal(err)
	}
	// sensor fields are scanner-only in production (MCP can't set them), but the
	// registry layer persists the full struct — mirror what the scanner does.
	p, _ := reg.Get("breeze")
	p.VulnCritical = 3
	if err := reg.Update(p); err != nil {
		t.Fatalf("inject sensor data: %v", err)
	}

	report := healthSweep(reg)
	if report.ProjectsScanned != 1 {
		t.Errorf("projects_scanned = %d, want 1", report.ProjectsScanned)
	}
	if !report.HasCritical {
		t.Errorf("expected a critical alert for 3 critical vulns, got %+v", report.BySeverity)
	}
	if report.BySeverity[alertfix.SevCritical] < 1 {
		t.Errorf("expected >=1 critical, got %d", report.BySeverity[alertfix.SevCritical])
	}
}

func TestHealthSweep_CleanPortfolio(t *testing.T) {
	reg, err := registry.New(t.TempDir())
	if err != nil {
		t.Fatal(err)
	}
	_ = reg.Add(&project.Project{
		Slug: "calm", DisplayName: "Calm", Repository: "github.com/o/calm",
		Stage: project.StageActive,
	})
	report := healthSweep(reg)
	if report.ProjectsScanned != 1 {
		t.Errorf("projects_scanned = %d, want 1", report.ProjectsScanned)
	}
	if report.HasCritical {
		t.Error("a project with no sensor findings should not be critical")
	}
}
