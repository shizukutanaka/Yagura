package main

import (
	"testing"

	"github.com/shizukutanaka/yagura/internal/alertfix"
	"github.com/shizukutanaka/yagura/internal/project"
	"github.com/shizukutanaka/yagura/internal/registry"
)

func TestHealthSweep_FlagsCriticalVuln(t *testing.T) {
	reg, err := registry.New(t.TempDir())
	if err != nil {
		t.Fatal(err)
	}
	if err := reg.Add(&project.Project{
		Slug: "breeze", DisplayName: "Breeze", Repository: "github.com/o/breeze",
		Stage: project.StageActive,
	}); err != nil {
		t.Fatal(err)
	}
	// sensor fields are scanner-only in production (MCP can't set them), but the
	// registry layer persists the full struct — mirror what the scanner does.
	p, _ := reg.Get("breeze")
	p.VulnCritical = 3
	if err := reg.Update(p); err != nil {
		t.Fatalf("inject sensor data: %v", err)
	}

	report := healthSweep(reg)
	if report.ProjectsScanned != 1 {
		t.Errorf("projects_scanned = %d, want 1", report.ProjectsScanned)
	}
	if !report.HasCritical {
		t.Errorf("expected a critical alert for 3 critical vulns, got %+v", report.BySeverity)
	}
	if report.BySeverity[alertfix.SevCritical] < 1 {
		t.Errorf("expected >=1 critical, got %d", report.BySeverity[alertfix.SevCritical])
	}
}

func TestHealthState_ProviderReflectsLatestSweep(t *testing.T) {
	h := &healthState{}
	// before any sweep → not ready
	if _, ok := h.PortfolioHealth(); ok {
		t.Error("PortfolioHealth should be ok=false before the first sweep")
	}
	h.set(alertfix.Report{
		Total:       2,
		HasCritical: true,
		BySeverity:  map[alertfix.Severity]int{alertfix.SevCritical: 1, alertfix.SevHigh: 1},
	})
	hs, ok := h.PortfolioHealth()
	if !ok {
		t.Fatal("PortfolioHealth should be ok after a sweep")
	}
	if hs.Total != 2 || hs.Critical != 1 || hs.High != 1 || !hs.HasCritical {
		t.Errorf("summary mismatch: %+v", hs)
	}
	if hs.At.IsZero() {
		t.Error("expected a sweep timestamp")
	}
}

func TestHealthSweep_CleanPortfolio(t *testing.T) {
	reg, err := registry.New(t.TempDir())
	if err != nil {
		t.Fatal(err)
	}
	_ = reg.Add(&project.Project{
		Slug: "calm", DisplayName: "Calm", Repository: "github.com/o/calm",
		Stage: project.StageActive,
	})
	report := healthSweep(reg)
	if report.ProjectsScanned != 1 {
		t.Errorf("projects_scanned = %d, want 1", report.ProjectsScanned)
	}
	if report.HasCritical {
		t.Error("a project with no sensor findings should not be critical")
	}
}
