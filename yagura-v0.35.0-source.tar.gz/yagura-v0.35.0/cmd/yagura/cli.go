// cli.go: yagura v0.35 "CLI direct mode".
//
// 動機 (v0.35.0):
//   v0.34 まで、registry 操作や local scan は MCP client(JSON-RPC over HTTP)
//   経由でしか叩けなかった(MCP server デメリット #7)。シェルスクリプトや CI
//   ステップから素早く `yagura list` / `yagura register` したいケースに応えられ
//   なかった。
//
// 本ファイルは MCP を介さず、registry / project / scanner パッケージの domain
// logic を直接呼ぶ top-level subcommand 群を提供する。ロジックは再実装せず、
// internal/mcp の各 tool handler と同じ呼び出しを行う(出力 shape も合わせる)。
//
// 設計:
//   - 各 verb は専用の flag.FlagSet(ContinueOnError, output=stderr)で parse。
//     ExitOnError を使わないのは os.Exit を避けてテスト/dispatch が制御を保つため。
//   - token 不要(registry CRUD / sbom / secretscan / gha-audit)は
//     config.ResolveStateDir() で state dir のみ解決(GitHub token を要求しない)。
//   - pin-drift だけ GitHub API が必要なので config.Load()(token 検証)を通す。
//   - register / update / unregister は daemon と同様に audit log へ best-effort
//     で追記する(trust base の append-only 監査証跡を CLI でも欠かさない)。

package main

import (
	"context"
	"errors"
	"flag"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"strings"
	"time"

	"github.com/shizukutanaka/yagura/internal/audit"
	"github.com/shizukutanaka/yagura/internal/config"
	"github.com/shizukutanaka/yagura/internal/ghaaudit"
	"github.com/shizukutanaka/yagura/internal/github"
	"github.com/shizukutanaka/yagura/internal/pindrift"
	"github.com/shizukutanaka/yagura/internal/project"
	"github.com/shizukutanaka/yagura/internal/registry"
	"github.com/shizukutanaka/yagura/internal/sbom"
	"github.com/shizukutanaka/yagura/internal/secretscan"
)

// mainModulePath は sbom 生成対象(yagura 自身)の module path。
// run() のハードコードと同じ値を CLI でも使う。
const mainModulePath = "github.com/shizukutanaka/yagura"

// errUsage は flag parse / 引数不足を示す番兵。runCLI で exit code 2 に変換する。
// FlagSet 側が既に詳細を stderr に出している。
var errUsage = errors.New("usage error")

// cliVerbs は dispatch() が runCLI に委譲する direct-mode subcommand の集合。
var cliVerbs = map[string]bool{
	"list": true, "get": true, "search": true, "stats": true,
	"register": true, "update": true, "unregister": true,
	"sbom": true, "secretscan": true, "gha-audit": true, "pin-drift": true,
}

// runCLI は direct-mode subcommand を実行し、プロセス exit code を返す。
func runCLI(verb string, args []string, stdout, stderr io.Writer) int {
	var err error
	switch verb {
	case "list":
		err = cliList(args, stdout, stderr)
	case "get":
		err = cliGet(args, stdout, stderr)
	case "search":
		err = cliSearch(args, stdout, stderr)
	case "stats":
		err = cliStats(args, stdout, stderr)
	case "register":
		err = cliRegister(args, stdout, stderr)
	case "update":
		err = cliUpdate(args, stdout, stderr)
	case "unregister":
		err = cliUnregister(args, stdout, stderr)
	case "sbom":
		err = cliSbom(args, stdout, stderr)
	case "secretscan":
		err = cliSecretScan(args, stdout, stderr)
	case "gha-audit":
		err = cliGhaAudit(args, stdout, stderr)
	case "pin-drift":
		err = cliPinDrift(args, stdout, stderr)
	default:
		fmt.Fprintf(stderr, "yagura: unknown command %q\n", verb)
		return 2
	}
	if err != nil {
		if errors.Is(err, errUsage) {
			return 2
		}
		fmt.Fprintf(stderr, "yagura %s: %v\n", verb, err)
		return 1
	}
	return 0
}

// newFlagSet は ContinueOnError(os.Exit しない)で stderr 出力の FlagSet を返す。
func newFlagSet(name string, stderr io.Writer) *flag.FlagSet {
	fs := flag.NewFlagSet(name, flag.ContinueOnError)
	fs.SetOutput(stderr)
	return fs
}

// parseArgs は flag が positional の前後どちらにあっても解釈する(GNU getopt 風)。
// 標準 flag は最初の非 flag で停止するため、`register breeze repo --lang go` の
// ように flag を後置すると無視されてしまう。これを permute して回避し、
// positional 引数を順序どおり返す。
func parseArgs(fs *flag.FlagSet, args []string) ([]string, error) {
	var positionals []string
	for {
		if err := fs.Parse(args); err != nil {
			return nil, err
		}
		rest := fs.Args()
		if len(rest) == 0 {
			break
		}
		positionals = append(positionals, rest[0])
		args = rest[1:]
	}
	return positionals, nil
}

// openRegistry は token 不要の state-dir resolver で registry を開く。
// partial-load エラーは warning として表示し、致命扱いにしない(daemon と同じ)。
func openRegistry(stderr io.Writer) (*registry.Registry, error) {
	sd, err := config.ResolveStateDir()
	if err != nil {
		return nil, err
	}
	reg, err := registry.New(config.ProjectsDirFor(sd))
	if reg == nil {
		return nil, err
	}
	if err != nil {
		fmt.Fprintf(stderr, "yagura: warning: registry partial load: %v\n", err)
	}
	return reg, nil
}

// ─── registry read commands ──────────────────────────────────

func cliList(args []string, stdout, stderr io.Writer) error {
	fs := newFlagSet("list", stderr)
	jsonOut := fs.Bool("json", false, "machine-readable JSON output")
	stage := fs.String("stage", "", "filter by stage (active/maintenance/paused/archived)")
	tag := fs.String("tag", "", "filter by tag (exact, case-insensitive)")
	lang := fs.String("language", "", "filter by language (exact, case-insensitive)")
	if err := fs.Parse(args); err != nil {
		return errUsage
	}
	reg, err := openRegistry(stderr)
	if err != nil {
		return err
	}
	projects, err := filterProjects(reg, *stage, *tag, *lang, "")
	if err != nil {
		return err
	}
	now := time.Now()
	if *jsonOut {
		return emitJSON(stdout, listPayload(projects, now))
	}
	humanList(stdout, projects, now)
	return nil
}

func cliSearch(args []string, stdout, stderr io.Writer) error {
	fs := newFlagSet("search", stderr)
	jsonOut := fs.Bool("json", false, "JSON output")
	tag := fs.String("tag", "", "filter by tag")
	lang := fs.String("language", "", "filter by language")
	stage := fs.String("stage", "", "filter by stage")
	query := fs.String("query", "", "substring over slug/name/notes/repo/tags")
	pos, err := parseArgs(fs, args)
	if err != nil {
		return errUsage
	}
	// 先頭の positional も query として許容(`yagura search foo`)。
	if *query == "" && len(pos) > 0 {
		*query = pos[0]
	}
	reg, err := openRegistry(stderr)
	if err != nil {
		return err
	}
	projects, err := filterProjects(reg, *stage, *tag, *lang, *query)
	if err != nil {
		return err
	}
	now := time.Now()
	if *jsonOut {
		return emitJSON(stdout, listPayload(projects, now))
	}
	humanList(stdout, projects, now)
	return nil
}

func cliGet(args []string, stdout, stderr io.Writer) error {
	fs := newFlagSet("get", stderr)
	jsonOut := fs.Bool("json", false, "JSON output")
	pos, err := parseArgs(fs, args)
	if err != nil {
		return errUsage
	}
	if len(pos) < 1 {
		return fmt.Errorf("usage: yagura get <slug> [--json]")
	}
	reg, err := openRegistry(stderr)
	if err != nil {
		return err
	}
	p, err := reg.Get(pos[0])
	if err != nil {
		if errors.Is(err, registry.ErrNotFound) {
			return fmt.Errorf("not found: %s", pos[0])
		}
		return err
	}
	if *jsonOut {
		return emitJSON(stdout, p)
	}
	humanProject(stdout, p)
	return nil
}

func cliStats(args []string, stdout, stderr io.Writer) error {
	fs := newFlagSet("stats", stderr)
	jsonOut := fs.Bool("json", false, "JSON output")
	if err := fs.Parse(args); err != nil {
		return errUsage
	}
	reg, err := openRegistry(stderr)
	if err != nil {
		return err
	}
	st := computeStats(reg.List(), time.Now())
	if *jsonOut {
		return emitJSON(stdout, st)
	}
	humanStats(stdout, st)
	return nil
}

// ─── registry mutation commands (audited) ────────────────────

func cliRegister(args []string, stdout, stderr io.Writer) error {
	fs := newFlagSet("register", stderr)
	jsonOut := fs.Bool("json", false, "JSON output")
	displayName := fs.String("display-name", "", "display name (default: slug)")
	lang := fs.String("language", "", "language")
	localPath := fs.String("local-path", "", "local filesystem path")
	tags := fs.String("tags", "", "comma-separated tags")
	dependsOn := fs.String("depends-on", "", "comma-separated dependency slugs")
	stage := fs.String("stage", "", "stage (default: active)")
	priority := fs.Int("priority", 0, "priority 0-5")
	notes := fs.String("notes", "", "free-text notes")
	pos, err := parseArgs(fs, args)
	if err != nil {
		return errUsage
	}
	if len(pos) < 2 {
		return fmt.Errorf("usage: yagura register <slug> <repository> [flags]")
	}
	slug, repo := pos[0], pos[1]
	dn := *displayName
	if dn == "" {
		dn = slug
	}
	st := project.Stage(strings.ToLower(strings.TrimSpace(*stage)))
	if st == "" {
		st = project.StageActive
	}
	p := &project.Project{
		Slug:        slug,
		DisplayName: dn,
		Repository:  repo,
		Language:    *lang,
		LocalPath:   *localPath,
		Tags:        splitCSV(*tags),
		DependsOn:   splitCSV(*dependsOn),
		Stage:       st,
		Priority:    *priority,
		Notes:       *notes,
	}
	reg, err := openRegistry(stderr)
	if err != nil {
		return err
	}
	if err := reg.Add(p); err != nil {
		if errors.Is(err, registry.ErrAlreadyExists) {
			return fmt.Errorf("already exists: %s", slug)
		}
		return err // project.Validate() のメッセージをそのまま見せる
	}
	auditMutation(stderr, "yagura_register", slug, map[string]any{"via": "cli", "repository": repo})
	if *jsonOut {
		return emitJSON(stdout, map[string]any{"slug": slug, "created": true})
	}
	fmt.Fprintf(stdout, "registered %s\n", slug)
	return nil
}

func cliUpdate(args []string, stdout, stderr io.Writer) error {
	fs := newFlagSet("update", stderr)
	jsonOut := fs.Bool("json", false, "JSON output")
	displayName := fs.String("display-name", "", "display name")
	lang := fs.String("language", "", "language")
	localPath := fs.String("local-path", "", "local path")
	tags := fs.String("tags", "", "comma-separated tags")
	dependsOn := fs.String("depends-on", "", "comma-separated dependency slugs")
	stage := fs.String("stage", "", "stage")
	priority := fs.Int("priority", 0, "priority 0-5")
	notes := fs.String("notes", "", "notes")
	pos, err := parseArgs(fs, args)
	if err != nil {
		return errUsage
	}
	if len(pos) < 1 {
		return fmt.Errorf("usage: yagura update <slug> [flags]")
	}
	slug := pos[0]
	reg, err := openRegistry(stderr)
	if err != nil {
		return err
	}
	cur, err := reg.Get(slug)
	if err != nil {
		if errors.Is(err, registry.ErrNotFound) {
			return fmt.Errorf("not found: %s", slug)
		}
		return err
	}
	// ユーザが明示的に指定した flag のみ適用(manual-metadata のみ。
	// sensor フィールドは scanner 専用なので CLI からは触れない)。
	set := map[string]bool{}
	fs.Visit(func(f *flag.Flag) { set[f.Name] = true })
	if set["display-name"] {
		cur.DisplayName = *displayName
	}
	if set["language"] {
		cur.Language = *lang
	}
	if set["local-path"] {
		cur.LocalPath = *localPath
	}
	if set["tags"] {
		cur.Tags = splitCSV(*tags)
	}
	if set["depends-on"] {
		cur.DependsOn = splitCSV(*dependsOn)
	}
	if set["stage"] {
		st := project.Stage(strings.ToLower(strings.TrimSpace(*stage)))
		switch st {
		case project.StageActive, project.StageMaintenance,
			project.StagePaused, project.StageArchived:
			cur.Stage = st
		default:
			return fmt.Errorf("stage must be one of active/maintenance/paused/archived")
		}
	}
	if set["priority"] {
		if *priority < 0 || *priority > 5 {
			return fmt.Errorf("priority must be 0-5")
		}
		cur.Priority = *priority
	}
	if set["notes"] {
		cur.Notes = *notes
	}
	if err := reg.Update(cur); err != nil {
		return err
	}
	auditMutation(stderr, "yagura_update", slug, map[string]any{"via": "cli"})
	if *jsonOut {
		return emitJSON(stdout, map[string]any{"slug": slug, "updated": true})
	}
	fmt.Fprintf(stdout, "updated %s\n", slug)
	return nil
}

func cliUnregister(args []string, stdout, stderr io.Writer) error {
	fs := newFlagSet("unregister", stderr)
	jsonOut := fs.Bool("json", false, "JSON output")
	pos, err := parseArgs(fs, args)
	if err != nil {
		return errUsage
	}
	if len(pos) < 1 {
		return fmt.Errorf("usage: yagura unregister <slug>")
	}
	slug := pos[0]
	reg, err := openRegistry(stderr)
	if err != nil {
		return err
	}
	if err := reg.Delete(slug); err != nil {
		if errors.Is(err, registry.ErrNotFound) {
			return fmt.Errorf("not found: %s", slug)
		}
		return err
	}
	auditMutation(stderr, "yagura_unregister", slug, map[string]any{"via": "cli"})
	if *jsonOut {
		return emitJSON(stdout, map[string]any{"slug": slug, "deleted": true})
	}
	fmt.Fprintf(stdout, "unregistered %s\n", slug)
	return nil
}

// ─── local scan commands ─────────────────────────────────────

func cliSbom(args []string, stdout, stderr io.Writer) error {
	fs := newFlagSet("sbom", stderr)
	jsonOut := fs.Bool("json", false, "JSON output")
	summary := fs.Bool("summary", false, "summary only")
	if err := fs.Parse(args); err != nil {
		return errUsage
	}
	bom, err := sbom.New().Generate(mainModulePath, version)
	if err != nil {
		return err
	}
	if *summary {
		s := bom.Summarize()
		if *jsonOut {
			return emitJSON(stdout, s)
		}
		humanSbomSummary(stdout, s)
		return nil
	}
	if *jsonOut {
		return emitJSON(stdout, bom)
	}
	humanSbom(stdout, bom)
	return nil
}

func cliSecretScan(args []string, stdout, stderr io.Writer) error {
	fs := newFlagSet("secretscan", stderr)
	jsonOut := fs.Bool("json", false, "JSON output")
	slug := fs.String("slug", "", "scan only this project (default: all non-archived)")
	minSev := fs.String("min-severity", "", "LOW/MEDIUM/HIGH/CRITICAL")
	if err := fs.Parse(args); err != nil {
		return errUsage
	}
	reg, err := openRegistry(stderr)
	if err != nil {
		return err
	}
	var toScan []*project.Project
	if *slug != "" {
		p, err := reg.Get(*slug)
		if err != nil {
			if errors.Is(err, registry.ErrNotFound) {
				return fmt.Errorf("not found: %s", *slug)
			}
			return err
		}
		toScan = []*project.Project{p}
	} else {
		for _, p := range reg.List() {
			if p.Stage != project.StageArchived {
				toScan = append(toScan, p)
			}
		}
	}
	var items []secretscan.ScanItem
	for _, p := range toScan {
		items = append(items, projectScanItems(p)...)
	}
	result := secretscan.New().ScanBatch(items)
	if *minSev != "" {
		m := strings.ToUpper(*minSev)
		if m != "LOW" && m != "MEDIUM" && m != "HIGH" && m != "CRITICAL" {
			return fmt.Errorf("min-severity must be LOW/MEDIUM/HIGH/CRITICAL")
		}
		result = filterBySeverity(result, secretscan.Severity(m))
	}
	if *jsonOut {
		return emitJSON(stdout, map[string]any{
			"scanned_projects": len(toScan),
			"sources_scanned":  len(items),
			"total_findings":   result.Total,
			"by_severity":      result.BySeverity,
			"by_source":        result.BySource,
			"source_order":     result.SourceOrder,
		})
	}
	humanSecretScan(stdout, result, len(toScan), len(items))
	return nil
}

func cliGhaAudit(args []string, stdout, stderr io.Writer) error {
	fs := newFlagSet("gha-audit", stderr)
	jsonOut := fs.Bool("json", false, "JSON output")
	dir := fs.String("dir", ".", "directory containing workflow YAML files")
	summary := fs.Bool("summary", false, "summary only")
	if err := fs.Parse(args); err != nil {
		return errUsage
	}
	files, err := readWorkflowFiles(*dir)
	if err != nil {
		return err
	}
	results := ghaaudit.New().AuditDir(*dir, files)
	if *summary {
		s := ghaaudit.Summarize(results)
		if *jsonOut {
			return emitJSON(stdout, s)
		}
		humanGhaSummary(stdout, s)
		return nil
	}
	if *jsonOut {
		return emitJSON(stdout, map[string]any{"results": results, "summary": ghaaudit.Summarize(results)})
	}
	humanGhaAudit(stdout, results)
	return nil
}

func cliPinDrift(args []string, stdout, stderr io.Writer) error {
	fs := newFlagSet("pin-drift", stderr)
	jsonOut := fs.Bool("json", false, "JSON output")
	dir := fs.String("dir", ".", "directory containing workflow YAML files")
	concurrency := fs.Int("concurrency", 4, "parallel API checks")
	if err := fs.Parse(args); err != nil {
		return errUsage
	}
	// pin-drift だけ GitHub API が必須 → config.Load() で token を検証する。
	cfg, err := config.Load()
	if err != nil {
		return fmt.Errorf("pin-drift requires YAGURA_GITHUB_TOKEN (GitHub API SHA verification): %w", err)
	}
	files, err := readWorkflowFiles(*dir)
	if err != nil {
		return err
	}
	var pins []pindrift.Pin
	for path, content := range files {
		pins = append(pins, pindrift.ExtractPins(path, content)...)
	}
	if len(pins) == 0 {
		if *jsonOut {
			return emitJSON(stdout, map[string]any{
				"results": []pindrift.Result{},
				"summary": pindrift.Summary{ByStatus: map[string]int{}},
				"note":    "no SHA-pinned uses found (try gha-audit first)",
			})
		}
		fmt.Fprintln(stdout, "no SHA-pinned uses found (try gha-audit first)")
		return nil
	}
	gh := newGitHubClient(cfg)
	checker := pindrift.New(gh)
	checker.RateLimit = pindrift.NewRateLimitGuard(gh.LastRateLimit)
	if *concurrency < 1 {
		*concurrency = 1
	}
	results := checker.CheckPinsParallel(context.Background(), pins, *concurrency)
	if *jsonOut {
		return emitJSON(stdout, map[string]any{"results": results, "summary": pindrift.Summarize(results)})
	}
	humanPinDrift(stdout, results)
	return nil
}

// ─── shared helpers ──────────────────────────────────────────

// filterProjects は stage/tag/language/query で registry を絞り込む。
// すべて空なら List()(全件)を返す。internal/mcp の search/list と同じ条件。
func filterProjects(reg *registry.Registry, stage, tag, lang, query string) ([]*project.Project, error) {
	var st project.Stage
	if stage != "" {
		st = project.Stage(strings.ToLower(strings.TrimSpace(stage)))
		switch st {
		case project.StageActive, project.StageMaintenance,
			project.StagePaused, project.StageArchived:
		default:
			return nil, fmt.Errorf("stage must be one of active/maintenance/paused/archived")
		}
	}
	if stage == "" && tag == "" && lang == "" && query == "" {
		return reg.List(), nil
	}
	return reg.Filter(func(p *project.Project) bool {
		if tag != "" && !p.HasTag(tag) {
			return false
		}
		if lang != "" && !strings.EqualFold(p.Language, lang) {
			return false
		}
		if stage != "" && p.Stage != st {
			return false
		}
		if query != "" && !matchesQuery(p, query) {
			return false
		}
		return true
	}), nil
}

// matchesQuery は internal/mcp の同名 helper(unexported)と同じ部分一致判定。
func matchesQuery(p *project.Project, q string) bool {
	q = strings.ToLower(strings.TrimSpace(q))
	if q == "" {
		return true
	}
	if strings.Contains(strings.ToLower(p.Slug), q) ||
		strings.Contains(strings.ToLower(p.DisplayName), q) ||
		strings.Contains(strings.ToLower(p.Notes), q) ||
		strings.Contains(strings.ToLower(p.Repository), q) {
		return true
	}
	for _, t := range p.Tags {
		if strings.Contains(strings.ToLower(t), q) {
			return true
		}
	}
	return false
}

// splitCSV は "a, b ,c" → ["a","b","c"]。空文字は nil。
func splitCSV(s string) []string {
	s = strings.TrimSpace(s)
	if s == "" {
		return nil
	}
	parts := strings.Split(s, ",")
	out := make([]string, 0, len(parts))
	for _, p := range parts {
		if p = strings.TrimSpace(p); p != "" {
			out = append(out, p)
		}
	}
	return out
}

// projectScanItems は internal/mcp.projectFieldsAsScanItems と同じ変換
// (Project のテキストフィールド → ScanItem)。
func projectScanItems(p *project.Project) []secretscan.ScanItem {
	var items []secretscan.ScanItem
	add := func(field, text string) {
		if strings.TrimSpace(text) == "" {
			return
		}
		items = append(items, secretscan.ScanItem{Source: p.Slug + ":" + field, Text: text})
	}
	add("display_name", p.DisplayName)
	add("notes", p.Notes)
	add("tags", strings.Join(p.Tags, " "))
	if p.Sprint != nil {
		add("sprint.goal", p.Sprint.Goal)
		for i, m := range p.Sprint.Milestones {
			add(fmt.Sprintf("sprint.milestone[%d]", i), m.Title)
		}
	}
	return items
}

// filterBySeverity は min 以上の severity だけを残した BatchResult を返す。
// internal/mcp.filterFindingsBatch と同じロジック。
func filterBySeverity(r secretscan.BatchResult, min secretscan.Severity) secretscan.BatchResult {
	minRank := severityRank(min)
	out := secretscan.BatchResult{
		BySource:    map[string][]secretscan.Finding{},
		SourceOrder: []string{},
		BySeverity:  map[string]int{},
	}
	for _, src := range r.SourceOrder {
		var keep []secretscan.Finding
		for _, f := range r.BySource[src] {
			if severityRank(f.Severity) >= minRank {
				keep = append(keep, f)
				out.BySeverity[string(f.Severity)]++
				out.Total++
			}
		}
		if len(keep) > 0 {
			out.BySource[src] = keep
			out.SourceOrder = append(out.SourceOrder, src)
		}
	}
	return out
}

func severityRank(s secretscan.Severity) int {
	switch s {
	case secretscan.SeverityCritical:
		return 4
	case secretscan.SeverityHigh:
		return 3
	case secretscan.SeverityMedium:
		return 2
	case secretscan.SeverityLow:
		return 1
	default:
		return 0
	}
}

// readWorkflowFiles は dir 直下の *.yml / *.yaml を {filename: content} で読む。
func readWorkflowFiles(dir string) (map[string]string, error) {
	entries, err := os.ReadDir(dir)
	if err != nil {
		return nil, fmt.Errorf("read dir %s: %w", dir, err)
	}
	files := map[string]string{}
	for _, e := range entries {
		if e.IsDir() {
			continue
		}
		name := e.Name()
		if !strings.HasSuffix(name, ".yml") && !strings.HasSuffix(name, ".yaml") {
			continue
		}
		data, err := os.ReadFile(filepath.Join(dir, name))
		if err != nil {
			return nil, fmt.Errorf("read %s: %w", name, err)
		}
		files[name] = string(data)
	}
	return files, nil
}

// newGitHubClient は run() と同じ構成で GitHub client を組み立てる(pin-drift 用)。
func newGitHubClient(cfg *config.Config) *github.Client {
	ts := github.NewTokenStore(cfg.GitHubToken)
	for owner, token := range cfg.GitHubTokens {
		ts.AddOwnerToken(owner, token)
	}
	return github.NewClient(github.Config{
		Tokens:  ts,
		BaseURL: cfg.GitHubBase,
		Timeout: cfg.ScanTimeout,
	})
}

// auditMutation は registry 変更を audit log に best-effort で追記する。
// CLAUDE.md の方針どおり、audit 失敗は warning に留めコマンド自体は失敗させない。
func auditMutation(stderr io.Writer, kind, target string, fields map[string]any) {
	sd, err := config.ResolveStateDir()
	if err != nil {
		fmt.Fprintf(stderr, "yagura: warning: audit skipped: %v\n", err)
		return
	}
	log, err := audit.New(config.AuditDirFor(sd))
	if err != nil {
		fmt.Fprintf(stderr, "yagura: warning: audit unavailable: %v\n", err)
		return
	}
	defer func() { _ = log.Close() }()
	if err := log.Append(audit.Record{Kind: kind, Actor: "cli", Target: target, Fields: fields}); err != nil {
		fmt.Fprintf(stderr, "yagura: warning: audit append failed: %v\n", err)
	}
}
