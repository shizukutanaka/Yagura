package main

import (
	"bytes"
	"encoding/json"
	"os"
	"path/filepath"
	"strings"
	"testing"

	"github.com/shizukutanaka/yagura/internal/audit"
)

// runCLICapture は YAGURA_STATE_DIR を tmp に向けて runCLI を実行し、出力を返す。
func runCLICapture(t *testing.T, args ...string) (code int, stdout, stderr string) {
	t.Helper()
	var out, errBuf bytes.Buffer
	verb := ""
	rest := []string{}
	if len(args) > 0 {
		verb = args[0]
		rest = args[1:]
	}
	code = runCLI(verb, rest, &out, &errBuf)
	return code, out.String(), errBuf.String()
}

func TestCLI_RegisterListGetUnregister(t *testing.T) {
	t.Setenv("YAGURA_STATE_DIR", t.TempDir())

	// empty list
	code, out, _ := runCLICapture(t, "list")
	if code != 0 || !strings.Contains(out, "count: 0") {
		t.Fatalf("empty list: code=%d out=%q", code, out)
	}

	// register (flags trailing the positionals)
	code, _, errs := runCLICapture(t, "register", "breeze", "shizukutanaka/breeze",
		"--language", "go", "--priority", "3", "--tags", "rust,cli")
	if code != 0 {
		t.Fatalf("register: code=%d err=%q", code, errs)
	}

	// get shows the trailing flags were applied
	code, out, _ = runCLICapture(t, "get", "breeze")
	if code != 0 {
		t.Fatalf("get: code=%d", code)
	}
	for _, want := range []string{"language: ", "go", "priority: ", "3", "rust, cli"} {
		if !strings.Contains(out, want) {
			t.Errorf("get output missing %q in:\n%s", want, out)
		}
	}

	// list now has 1, json shape matches MCP
	code, out, _ = runCLICapture(t, "list", "--json")
	if code != 0 {
		t.Fatalf("list --json: code=%d", code)
	}
	var payload struct {
		Count    int `json:"count"`
		Projects []struct {
			Slug     string `json:"slug"`
			Language string `json:"language"`
			Priority int    `json:"priority"`
		} `json:"projects"`
	}
	if err := json.Unmarshal([]byte(out), &payload); err != nil {
		t.Fatalf("list --json invalid: %v\n%s", err, out)
	}
	if payload.Count != 1 || payload.Projects[0].Slug != "breeze" ||
		payload.Projects[0].Language != "go" || payload.Projects[0].Priority != 3 {
		t.Errorf("unexpected list payload: %+v", payload)
	}

	// unregister
	code, _, _ = runCLICapture(t, "unregister", "breeze")
	if code != 0 {
		t.Fatalf("unregister: code=%d", code)
	}
	code, out, _ = runCLICapture(t, "list")
	if !strings.Contains(out, "count: 0") {
		t.Errorf("list after unregister: %q", out)
	}
}

func TestCLI_RegisterErrors(t *testing.T) {
	t.Setenv("YAGURA_STATE_DIR", t.TempDir())

	// missing repository
	if code, _, _ := runCLICapture(t, "register", "onlyslug"); code == 0 {
		t.Errorf("register without repository should fail")
	}
	// invalid slug (uppercase)
	if code, _, _ := runCLICapture(t, "register", "Breeze", "o/r"); code == 0 {
		t.Errorf("register with invalid slug should fail")
	}
	// duplicate
	if code, _, _ := runCLICapture(t, "register", "breeze", "o/r"); code != 0 {
		t.Fatalf("first register failed")
	}
	if code, _, errs := runCLICapture(t, "register", "breeze", "o/r"); code == 0 ||
		!strings.Contains(errs, "already exists") {
		t.Errorf("duplicate register should fail with already exists: code=%d err=%q", code, errs)
	}
}

func TestCLI_UpdatePartialPreservesFields(t *testing.T) {
	t.Setenv("YAGURA_STATE_DIR", t.TempDir())
	if code, _, _ := runCLICapture(t, "register", "breeze", "o/r",
		"--language", "go", "--priority", "3"); code != 0 {
		t.Fatal("register failed")
	}
	// update only notes
	if code, _, _ := runCLICapture(t, "update", "breeze", "--notes", "WIP"); code != 0 {
		t.Fatal("update failed")
	}
	_, out, _ := runCLICapture(t, "get", "breeze")
	if !strings.Contains(out, "WIP") {
		t.Errorf("notes not updated: %s", out)
	}
	if !strings.Contains(out, "priority: ") || !strings.Contains(out, "3") ||
		!strings.Contains(out, "go") {
		t.Errorf("unmentioned fields not preserved: %s", out)
	}
	// unknown slug
	if code, _, _ := runCLICapture(t, "update", "ghost", "--notes", "x"); code == 0 {
		t.Errorf("update unknown slug should fail")
	}
	// invalid priority
	if code, _, _ := runCLICapture(t, "update", "breeze", "--priority", "9"); code == 0 {
		t.Errorf("update priority 9 should fail")
	}
}

func TestCLI_MutationsAreAudited(t *testing.T) {
	dir := t.TempDir()
	t.Setenv("YAGURA_STATE_DIR", dir)
	if code, _, _ := runCLICapture(t, "register", "breeze", "o/r"); code != 0 {
		t.Fatal("register failed")
	}
	results, err := audit.Verify(filepath.Join(dir, "audit"))
	if err != nil {
		t.Fatalf("audit verify: %v", err)
	}
	if len(results) == 0 || !results[0].OK || results[0].TotalRecords < 1 {
		t.Fatalf("expected an OK audit record after register, got %+v", results)
	}
	// confirm the record is the cli-originated register
	data, _ := os.ReadFile(results[0].File)
	if !strings.Contains(string(data), "yagura_register") || !strings.Contains(string(data), `"actor":"cli"`) {
		t.Errorf("audit record missing cli register marker:\n%s", data)
	}
}

func TestCLI_SearchAndStats(t *testing.T) {
	t.Setenv("YAGURA_STATE_DIR", t.TempDir())
	runCLICapture(t, "register", "breeze", "o/breeze", "--language", "go", "--tags", "rust")
	runCLICapture(t, "register", "otedama", "o/otedama", "--language", "python")

	// search by tag
	_, out, _ := runCLICapture(t, "search", "--tag", "rust", "--json")
	var p struct {
		Count int `json:"count"`
	}
	_ = json.Unmarshal([]byte(out), &p)
	if p.Count != 1 {
		t.Errorf("search --tag rust expected 1, got %d", p.Count)
	}
	// search by positional query (flag after positional)
	_, out, _ = runCLICapture(t, "search", "breeze", "--json")
	_ = json.Unmarshal([]byte(out), &p)
	if p.Count != 1 {
		t.Errorf("search breeze expected 1, got %d", p.Count)
	}
	// stats
	_, out, _ = runCLICapture(t, "stats", "--json")
	var st struct {
		Total      int            `json:"total"`
		ByLanguage map[string]int `json:"by_language"`
	}
	if err := json.Unmarshal([]byte(out), &st); err != nil {
		t.Fatalf("stats json: %v", err)
	}
	if st.Total != 2 || st.ByLanguage["go"] != 1 || st.ByLanguage["python"] != 1 {
		t.Errorf("unexpected stats: %+v", st)
	}
}

func TestCLI_ListLimit(t *testing.T) {
	t.Setenv("YAGURA_STATE_DIR", t.TempDir())
	for _, s := range []string{"a", "b", "c"} {
		runCLICapture(t, "register", s, "o/"+s)
	}
	_, out, _ := runCLICapture(t, "list", "--limit", "2", "--json")
	var p struct {
		Count     int  `json:"count"`
		Total     int  `json:"total"`
		Truncated bool `json:"truncated"`
	}
	if err := json.Unmarshal([]byte(out), &p); err != nil {
		t.Fatalf("json: %v\n%s", err, out)
	}
	if p.Count != 2 || p.Total != 3 || !p.Truncated {
		t.Errorf("expected count=2 total=3 truncated=true, got %+v", p)
	}
	// human mode shows the truncation note
	if _, hout, _ := runCLICapture(t, "list", "--limit", "1"); !strings.Contains(hout, "showing 1 of 3") {
		t.Errorf("expected truncation note, got: %q", hout)
	}
}

func TestCLI_SecretScan(t *testing.T) {
	t.Setenv("YAGURA_STATE_DIR", t.TempDir())
	// empty registry → 0 findings
	if code, out, _ := runCLICapture(t, "secretscan"); code != 0 || !strings.Contains(out, "total_findings: 0") {
		t.Fatalf("empty secretscan: code=%d out=%q", code, out)
	}
	// plant a fake AWS key in notes
	runCLICapture(t, "register", "breeze", "o/r", "--notes", "key AKIAIOSFODNN7EXAMPLE end")
	_, out, _ := runCLICapture(t, "secretscan", "--slug", "breeze")
	if !strings.Contains(out, "total_findings: 1") || !strings.Contains(out, "aws-access-key-id") {
		t.Errorf("expected aws key finding, got:\n%s", out)
	}
	// min-severity filter removes nothing (CRITICAL >= HIGH)
	if _, out, _ := runCLICapture(t, "secretscan", "--slug", "breeze", "--min-severity", "HIGH"); !strings.Contains(out, "total_findings: 1") {
		t.Errorf("min-severity HIGH should keep the CRITICAL finding: %s", out)
	}
	// invalid severity
	if code, _, _ := runCLICapture(t, "secretscan", "--min-severity", "BOGUS"); code == 0 {
		t.Errorf("invalid min-severity should fail")
	}
	// unknown slug
	if code, _, _ := runCLICapture(t, "secretscan", "--slug", "ghost"); code == 0 {
		t.Errorf("secretscan unknown slug should fail")
	}
}

func TestCLI_Sbom(t *testing.T) {
	t.Setenv("YAGURA_STATE_DIR", t.TempDir())
	if code, out, _ := runCLICapture(t, "sbom", "--summary"); code != 0 || !strings.Contains(out, "CycloneDX") {
		t.Fatalf("sbom summary: code=%d out=%q", code, out)
	}
	code, out, _ := runCLICapture(t, "sbom", "--json")
	if code != 0 {
		t.Fatalf("sbom json: code=%d", code)
	}
	var bom struct {
		BomFormat string `json:"bomFormat"`
	}
	if err := json.Unmarshal([]byte(out), &bom); err != nil || bom.BomFormat != "CycloneDX" {
		t.Errorf("sbom json invalid: %v bom=%+v", err, bom)
	}
}

func TestCLI_GhaAudit(t *testing.T) {
	t.Setenv("YAGURA_STATE_DIR", t.TempDir())
	wf := t.TempDir()
	// a workflow with an unpinned action (mutable tag) → should produce a finding
	content := "" +
		"name: ci\n" +
		"on: [push]\n" +
		"jobs:\n" +
		"  build:\n" +
		"    runs-on: ubuntu-latest\n" +
		"    steps:\n" +
		"      - uses: actions/checkout@v4\n"
	if err := os.WriteFile(filepath.Join(wf, "ci.yml"), []byte(content), 0o644); err != nil {
		t.Fatal(err)
	}
	code, out, _ := runCLICapture(t, "gha-audit", "--dir", wf)
	if code != 0 {
		t.Fatalf("gha-audit: code=%d", code)
	}
	if !strings.Contains(out, "files: 1") {
		t.Errorf("expected 1 file audited, got:\n%s", out)
	}
	// empty dir → zero files, still exit 0
	if code, out, _ := runCLICapture(t, "gha-audit", "--dir", t.TempDir()); code != 0 || !strings.Contains(out, "files: 0") {
		t.Errorf("empty gha-audit: code=%d out=%q", code, out)
	}
}

func TestCLI_SkillAudit(t *testing.T) {
	t.Setenv("YAGURA_STATE_DIR", t.TempDir())
	dir := t.TempDir()
	mustWrite := func(sub, content string) {
		if err := os.MkdirAll(filepath.Join(dir, sub), 0o755); err != nil {
			t.Fatal(err)
		}
		if err := os.WriteFile(filepath.Join(dir, sub, "SKILL.md"), []byte(content), 0o644); err != nil {
			t.Fatal(err)
		}
	}
	mustWrite("good", "---\nname: go-test\ndescription: Use when the user asks to fix Go tests.\n---\n\n# Go\n\n## Gotchas\n\n- use t.TempDir\n")
	mustWrite("stub", "# placeholder\n\nTODO\n")

	_, out, _ := runCLICapture(t, "skill-audit", "--dir", dir, "--json")
	var r struct {
		Scanned          int `json:"scanned"`
		RetireCandidates int `json:"retire_candidates"`
		Skills           []struct {
			Path              string `json:"path"`
			Score             int    `json:"score"`
			RetireRecommended bool   `json:"retire_recommended"`
		} `json:"skills"`
	}
	if err := json.Unmarshal([]byte(out), &r); err != nil {
		t.Fatalf("json: %v\n%s", err, out)
	}
	if r.Scanned != 2 || r.RetireCandidates != 1 {
		t.Errorf("expected scanned=2 retire=1, got %+v", r)
	}
	// retire-only narrows to the stub
	_, ro, _ := runCLICapture(t, "skill-audit", "--dir", dir, "--retire-only", "--json")
	_ = json.Unmarshal([]byte(ro), &r)
	if len(r.Skills) != 1 || !r.Skills[0].RetireRecommended {
		t.Errorf("retire-only should return 1 retire skill, got %+v", r.Skills)
	}
	// missing dir → 0, exit 0
	if code, mout, _ := runCLICapture(t, "skill-audit", "--dir", filepath.Join(dir, "nope")); code != 0 || !strings.Contains(mout, "scanned: 0") {
		t.Errorf("missing dir: code=%d out=%q", code, mout)
	}
}

func TestCLI_PinDriftRequiresToken(t *testing.T) {
	t.Setenv("YAGURA_STATE_DIR", t.TempDir())
	t.Setenv("YAGURA_GITHUB_TOKEN", "") // ensure unset
	code, _, errs := runCLICapture(t, "pin-drift", "--dir", t.TempDir())
	if code == 0 || !strings.Contains(errs, "YAGURA_GITHUB_TOKEN") {
		t.Errorf("pin-drift without token should fail with token hint: code=%d err=%q", code, errs)
	}
}

func TestCLI_UsageAndUnknown(t *testing.T) {
	t.Setenv("YAGURA_STATE_DIR", t.TempDir())
	// unknown verb routed through runCLI
	if code := runCLI("bogus", nil, &bytes.Buffer{}, &bytes.Buffer{}); code != 2 {
		t.Errorf("unknown verb: want exit 2, got %d", code)
	}
	// bad flag → ContinueOnError, no panic, exit 2
	if code, _, _ := runCLICapture(t, "list", "--nope"); code != 2 {
		t.Errorf("bad flag: want exit 2, got %d", code)
	}
	// missing positional
	if code, _, _ := runCLICapture(t, "get"); code != 1 {
		t.Errorf("get without slug: want exit 1, got %d", code)
	}
}

// TestCLI_DispatchRouting は dispatch() が CLI verb を runCLI に委譲することを確認。
func TestCLI_DispatchRouting(t *testing.T) {
	t.Setenv("YAGURA_STATE_DIR", t.TempDir())
	var out, errBuf bytes.Buffer
	code := dispatch([]string{"list"}, &out, &errBuf)
	if code != 0 || !strings.Contains(out.String(), "count: 0") {
		t.Errorf("dispatch list: code=%d out=%q", code, out.String())
	}
}

func TestCLI_WorkflowAudit(t *testing.T) {
	t.Setenv("YAGURA_STATE_DIR", t.TempDir())
	dir := t.TempDir()
	mustWrite := func(name, content string) {
		if err := os.WriteFile(filepath.Join(dir, name), []byte(content), 0o644); err != nil {
			t.Fatal(err)
		}
	}
	// clean fan-out workflow: parallel + per-agent model + token budget, no issues.
	mustWrite("clean.js", "const r = await parallel(files.map(f => () => agent(`review ${f}`, { model: \"haiku\", maxTokens: 2000 })));\nconst out = await agent(\"merge\", { model: \"opus\", maxTokens: 4000 });\n")
	// flagged workflow: single agent, no token budget -> over-reach + no budget.
	mustWrite("thin.js", "const out = await agent(\"explain this module\", { model: \"sonnet\" });\n")
	// a non-workflow .js file in the dir (should still be scanned, flagged).
	mustWrite("notwf.mjs", "export const x = 1;\n")

	_, out, _ := runCLICapture(t, "workflow-audit", "--dir", dir, "--json")
	var r struct {
		Scanned   int `json:"scanned"`
		Flagged   int `json:"flagged"`
		Workflows []struct {
			Path       string   `json:"path"`
			Score      int      `json:"score"`
			IsWorkflow bool     `json:"is_workflow"`
			Issues     []string `json:"issues"`
		} `json:"workflows"`
	}
	if err := json.Unmarshal([]byte(out), &r); err != nil {
		t.Fatalf("json: %v\n%s", err, out)
	}
	if r.Scanned != 3 {
		t.Errorf("expected scanned=3, got %d", r.Scanned)
	}
	if r.Flagged != 2 {
		t.Errorf("expected flagged=2 (thin + notwf), got %d", r.Flagged)
	}

	// flagged-only narrows to the two with issues.
	_, fo, _ := runCLICapture(t, "workflow-audit", "--dir", dir, "--flagged-only", "--json")
	_ = json.Unmarshal([]byte(fo), &r)
	if len(r.Workflows) != 2 {
		t.Errorf("flagged-only should return 2 workflows, got %d", len(r.Workflows))
	}

	// missing dir -> 0, exit 0.
	if code, mout, _ := runCLICapture(t, "workflow-audit", "--dir", filepath.Join(dir, "nope")); code != 0 || !strings.Contains(mout, "scanned: 0") {
		t.Errorf("missing dir: code=%d out=%q", code, mout)
	}
}

func TestCLI_SettingsAudit(t *testing.T) {
	t.Setenv("YAGURA_STATE_DIR", t.TempDir())
	dir := t.TempDir()
	claudeDir := filepath.Join(dir, ".claude")
	if err := os.MkdirAll(claudeDir, 0o755); err != nil {
		t.Fatal(err)
	}
	// settings.json: clean (deny guards rm -rf, has hooks) -> no issues.
	clean := `{"permissions":{"deny":["Bash(rm -rf *)"]},"hooks":{"Stop":[{"hooks":[{"type":"command","command":"go vet ./..."}]}]}}`
	if err := os.WriteFile(filepath.Join(claudeDir, "settings.json"), []byte(clean), 0o644); err != nil {
		t.Fatal(err)
	}
	// settings.local.json: no permissions + unrestricted allow -> flagged.
	local := `{"permissions":{"allow":["Bash(*)"]}}`
	if err := os.WriteFile(filepath.Join(claudeDir, "settings.local.json"), []byte(local), 0o644); err != nil {
		t.Fatal(err)
	}

	_, out, _ := runCLICapture(t, "settings-audit", "--dir", claudeDir, "--json")
	var r struct {
		Scanned  int `json:"scanned"`
		Flagged  int `json:"flagged"`
		Settings []struct {
			Path        string `json:"path"`
			Score       int    `json:"score"`
			HasDenyList bool   `json:"has_deny_list"`
		} `json:"settings"`
	}
	if err := json.Unmarshal([]byte(out), &r); err != nil {
		t.Fatalf("json: %v\n%s", err, out)
	}
	if r.Scanned != 2 {
		t.Errorf("expected scanned=2, got %d", r.Scanned)
	}
	if r.Flagged != 1 {
		t.Errorf("expected flagged=1 (local only), got %d", r.Flagged)
	}

	// missing dir -> 0, exit 0.
	if code, mout, _ := runCLICapture(t, "settings-audit", "--dir", filepath.Join(dir, "nope")); code != 0 || !strings.Contains(mout, "scanned: 0") {
		t.Errorf("missing dir: code=%d out=%q", code, mout)
	}
}

func TestCLI_AgentConfigAudit(t *testing.T) {
	t.Setenv("YAGURA_STATE_DIR", t.TempDir())
	dir := t.TempDir()
	// a config with a dangling primary + insecure LAN settings → flagged.
	cfg := `{
      "gateway": {"auth": {"mode": "token", "token": "openclaw-local-token-123"}, "controlUi": {"dangerouslyDisableDeviceAuth": true}},
      "agents": {"defaults": {"model": {"primary": "vllm/missing"}}},
      "models": {"providers": {"vllm": {"apiKey": "EMPTY", "models": [{"id": "qwen3.6-27b", "contextWindow": 262144, "maxTokens": 32768}]}}}
    }`
	path := filepath.Join(dir, "openclaw.json")
	if err := os.WriteFile(path, []byte(cfg), 0o644); err != nil {
		t.Fatal(err)
	}

	_, out, _ := runCLICapture(t, "agent-config-audit", "--file", path, "--json")
	var r struct {
		Scanned int `json:"scanned"`
		Flagged int `json:"flagged"`
		Configs []struct {
			Path            string `json:"path"`
			Score           int    `json:"score"`
			PrimaryResolves bool   `json:"primary_resolves"`
		} `json:"configs"`
	}
	if err := json.Unmarshal([]byte(out), &r); err != nil {
		t.Fatalf("json: %v\n%s", err, out)
	}
	if r.Scanned != 1 || r.Flagged != 1 {
		t.Errorf("expected scanned=1 flagged=1, got %+v", r)
	}
	if len(r.Configs) != 1 || r.Configs[0].PrimaryResolves {
		t.Errorf("dangling primary should not resolve: %+v", r.Configs)
	}

	// positional arg form also works.
	if code, pout, _ := runCLICapture(t, "agent-config-audit", path); code != 0 || !strings.Contains(pout, "scanned: 1") {
		t.Errorf("positional form: code=%d out=%q", code, pout)
	}

	// missing file → scanned 0, exit 0.
	if code, mout, _ := runCLICapture(t, "agent-config-audit", "--file", filepath.Join(dir, "nope.json")); code != 0 || !strings.Contains(mout, "scanned: 0") {
		t.Errorf("missing file: code=%d out=%q", code, mout)
	}
}

func TestCLI_PluginAudit(t *testing.T) {
	t.Setenv("YAGURA_STATE_DIR", t.TempDir())
	dir := t.TempDir()
	// a plugin.json with a non-kebab name + non-relative agent path → flagged.
	plugin := `{"name":"My_Plugin","agents":["agents/x.md"]}`
	ppath := filepath.Join(dir, "plugin.json")
	if err := os.WriteFile(ppath, []byte(plugin), 0o644); err != nil {
		t.Fatal(err)
	}
	_, out, _ := runCLICapture(t, "plugin-audit", "--file", ppath, "--json")
	var r struct {
		Scanned   int `json:"scanned"`
		Flagged   int `json:"flagged"`
		Manifests []struct {
			Kind      string `json:"kind"`
			Score     int    `json:"score"`
			NameValid bool   `json:"name_valid"`
		} `json:"manifests"`
	}
	if err := json.Unmarshal([]byte(out), &r); err != nil {
		t.Fatalf("json: %v\n%s", err, out)
	}
	if r.Scanned != 1 || r.Flagged != 1 {
		t.Errorf("expected scanned=1 flagged=1, got %+v", r)
	}
	if len(r.Manifests) != 1 || r.Manifests[0].Kind != "plugin" || r.Manifests[0].NameValid {
		t.Errorf("expected a flagged plugin with invalid name, got %+v", r.Manifests)
	}

	// a marketplace.json is auto-detected.
	mkt := `{"name":"mk","owner":{"name":"o"},"plugins":[{"name":"p","source":"./p"}]}`
	mpath := filepath.Join(dir, "marketplace.json")
	if err := os.WriteFile(mpath, []byte(mkt), 0o644); err != nil {
		t.Fatal(err)
	}
	if _, mout, _ := runCLICapture(t, "plugin-audit", mpath); !strings.Contains(mout, "marketplace") {
		t.Errorf("marketplace should be auto-detected: %q", mout)
	}

	// missing file → scanned 0, exit 0.
	if code, nout, _ := runCLICapture(t, "plugin-audit", "--file", filepath.Join(dir, "nope.json")); code != 0 || !strings.Contains(nout, "scanned: 0") {
		t.Errorf("missing file: code=%d out=%q", code, nout)
	}
}

func TestCLI_PublicityScan(t *testing.T) {
	t.Setenv("YAGURA_STATE_DIR", t.TempDir())
	dir := t.TempDir()
	// a doc with a real leak (home path) + a clean line.
	if err := os.WriteFile(filepath.Join(dir, "SKILL.md"), []byte("see /Users/hiroro/work\nbind 127.0.0.1:8090\n"), 0o644); err != nil {
		t.Fatal(err)
	}
	// a non-text file is ignored.
	if err := os.WriteFile(filepath.Join(dir, "bin.dat"), []byte("/Users/secret/x"), 0o644); err != nil {
		t.Fatal(err)
	}
	_, out, _ := runCLICapture(t, "publicity-scan", "--dir", dir, "--json")
	var r struct {
		Scanned  int `json:"scanned"`
		Findings []struct {
			Path     string `json:"path"`
			RuleID   string `json:"rule_id"`
			Severity string `json:"severity"`
		} `json:"findings"`
		Summary struct {
			Total int `json:"total"`
		} `json:"summary"`
	}
	if err := json.Unmarshal([]byte(out), &r); err != nil {
		t.Fatalf("json: %v\n%s", err, out)
	}
	if r.Scanned != 1 { // only SKILL.md (bin.dat ignored)
		t.Errorf("expected 1 text file scanned, got %d", r.Scanned)
	}
	if r.Summary.Total != 1 || r.Findings[0].RuleID != "absolute-home-path" {
		t.Errorf("expected 1 home-path finding (loopback ignored), got %+v", r.Findings)
	}

	// single-file positional form.
	if code, fout, _ := runCLICapture(t, "publicity-scan", filepath.Join(dir, "SKILL.md")); code != 0 || !strings.Contains(fout, "absolute-home-path") {
		t.Errorf("positional file: code=%d out=%q", code, fout)
	}

	// missing path → scanned 0, exit 0.
	if code, nout, _ := runCLICapture(t, "publicity-scan", "--dir", filepath.Join(dir, "nope")); code != 0 || !strings.Contains(nout, "scanned: 0") {
		t.Errorf("missing path: code=%d out=%q", code, nout)
	}
}

func TestCLI_PublicityScanStrict(t *testing.T) {
	t.Setenv("YAGURA_STATE_DIR", t.TempDir())
	dir := t.TempDir()
	// clean file → --strict exits 0.
	if err := os.WriteFile(filepath.Join(dir, "clean.md"), []byte("open http://127.0.0.1:8090\n"), 0o644); err != nil {
		t.Fatal(err)
	}
	if code, _, _ := runCLICapture(t, "publicity-scan", "--strict", "--dir", dir); code != 0 {
		t.Errorf("clean --strict should exit 0, got %d", code)
	}
	// leaky file → --strict exits non-zero.
	if err := os.WriteFile(filepath.Join(dir, "leak.md"), []byte("path /Users/hiroro/x\n"), 0o644); err != nil {
		t.Fatal(err)
	}
	code, out, errOut := runCLICapture(t, "publicity-scan", "--strict", "--dir", dir)
	if code == 0 {
		t.Errorf("leaky --strict should exit non-zero, got 0")
	}
	if !strings.Contains(out, "absolute-home-path") {
		t.Errorf("findings should still be printed to stdout, got %q", out)
	}
	if !strings.Contains(errOut, "--strict") {
		t.Errorf("stderr should explain the strict failure, got %q", errOut)
	}
	// without --strict, the same leak exits 0 (report-only).
	if code2, _, _ := runCLICapture(t, "publicity-scan", "--dir", dir); code2 != 0 {
		t.Errorf("non-strict should exit 0 even with findings, got %d", code2)
	}
}
