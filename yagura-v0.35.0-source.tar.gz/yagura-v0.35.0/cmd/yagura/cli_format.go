// cli_format.go: output formatters for CLI direct mode (v0.35.0).
//
// 2 つの出力経路:
//   - emitJSON: MCP tool handler が返すのと同じ struct/map を indent 付き JSON で
//     出す(--json)。既存 json タグを再利用するので shape は MCP と一致する。
//   - human*: text/tabwriter による整列テキスト(デフォルト)。verify / secret
//     subcommand と同じ「素朴で grep しやすい」世界観。

package main

import (
	"encoding/json"
	"fmt"
	"io"
	"sort"
	"strings"
	"text/tabwriter"
	"time"

	"github.com/shizukutanaka/yagura/internal/ghaaudit"
	"github.com/shizukutanaka/yagura/internal/pindrift"
	"github.com/shizukutanaka/yagura/internal/project"
	"github.com/shizukutanaka/yagura/internal/sbom"
	"github.com/shizukutanaka/yagura/internal/secretscan"
)

// emitJSON は v を indent 付き JSON + 改行で書く。
func emitJSON(w io.Writer, v any) error {
	b, err := json.MarshalIndent(v, "", "  ")
	if err != nil {
		return fmt.Errorf("marshal json: %w", err)
	}
	_, err = fmt.Fprintln(w, string(b))
	return err
}

// ─── list / search ───────────────────────────────────────────

// cliListView は MCP listOut と同じ compact shape(--json 用)。
type cliListView struct {
	Slug            string `json:"slug"`
	DisplayName     string `json:"display_name"`
	Stage           string `json:"stage"`
	Priority        int    `json:"priority"`
	Language        string `json:"language"`
	OpenPRs         int    `json:"open_prs"`
	OpenIssues      int    `json:"open_issues"`
	CIStatus        string `json:"ci_status"`
	LatestVersion   string `json:"latest_version"`
	DaysSinceCommit int    `json:"days_since_commit"`
}

func listPayload(projects []*project.Project, now time.Time) map[string]any {
	out := make([]cliListView, 0, len(projects))
	for _, p := range projects {
		out = append(out, cliListView{
			Slug:            p.Slug,
			DisplayName:     p.DisplayName,
			Stage:           string(p.Stage),
			Priority:        p.Priority,
			Language:        p.Language,
			OpenPRs:         p.OpenPRs,
			OpenIssues:      p.OpenIssues,
			CIStatus:        string(p.CIStatus),
			LatestVersion:   p.LatestVersion,
			DaysSinceCommit: project.DaysSince(p.LatestActivity, now),
		})
	}
	return map[string]any{"count": len(out), "projects": out}
}

func humanList(w io.Writer, projects []*project.Project, now time.Time) {
	if len(projects) == 0 {
		fmt.Fprintln(w, "count: 0")
		return
	}
	tw := tabwriter.NewWriter(w, 0, 2, 2, ' ', 0)
	fmt.Fprintln(tw, "SLUG\tSTAGE\tPRI\tLANG\tCI\tPRS\tISSUES\tIDLE\tREPO")
	for _, p := range projects {
		idle := project.DaysSince(p.LatestActivity, now)
		idleStr := "-"
		if idle >= 0 {
			idleStr = fmt.Sprintf("%dd", idle)
		}
		fmt.Fprintf(tw, "%s\t%s\t%d\t%s\t%s\t%d\t%d\t%s\t%s\n",
			p.Slug, p.Stage, p.Priority, dash(p.Language), dash(string(p.CIStatus)),
			p.OpenPRs, p.OpenIssues, idleStr, p.Repository)
	}
	_ = tw.Flush()
	fmt.Fprintf(w, "count: %d\n", len(projects))
}

// ─── get ─────────────────────────────────────────────────────

func humanProject(w io.Writer, p *project.Project) {
	tw := tabwriter.NewWriter(w, 0, 2, 1, ' ', 0)
	kv := func(k string, v any) { fmt.Fprintf(tw, "%s:\t%v\n", k, v) }
	kv("slug", p.Slug)
	kv("display_name", p.DisplayName)
	kv("repository", p.Repository)
	if p.LocalPath != "" {
		kv("local_path", p.LocalPath)
	}
	if p.Language != "" {
		kv("language", p.Language)
	}
	kv("stage", p.Stage)
	kv("priority", p.Priority)
	if len(p.Tags) > 0 {
		kv("tags", strings.Join(p.Tags, ", "))
	}
	if len(p.DependsOn) > 0 {
		kv("depends_on", strings.Join(p.DependsOn, ", "))
	}
	if p.CIStatus != "" {
		kv("ci_status", p.CIStatus)
	}
	if p.LatestVersion != "" {
		kv("latest_version", p.LatestVersion)
	}
	kv("open_prs", p.OpenPRs)
	kv("open_issues", p.OpenIssues)
	if p.Notes != "" {
		kv("notes", p.Notes)
	}
	if !p.LatestActivity.IsZero() {
		kv("latest_activity", p.LatestActivity.Format(time.RFC3339))
	}
	kv("created_at", p.CreatedAt.Format(time.RFC3339))
	kv("updated_at", p.UpdatedAt.Format(time.RFC3339))
	_ = tw.Flush()
}

// ─── stats ───────────────────────────────────────────────────

// statsView は MCP yagura_stats と同じ集計 shape(--json 用)。
type statsView struct {
	Total            int            `json:"total"`
	ByStage          map[string]int `json:"by_stage"`
	ByCIStatus       map[string]int `json:"by_ci_status"`
	ByLanguage       map[string]int `json:"by_language"`
	TotalOpenPRs     int            `json:"total_open_prs"`
	TotalOpenIssues  int            `json:"total_open_issues"`
	StaleActiveCount int            `json:"stale_active_count"`
	WithActiveSprint int            `json:"with_active_sprint"`
	AvgPriority      float64        `json:"avg_priority"`
	AsOf             string         `json:"as_of"`
}

func computeStats(projects []*project.Project, now time.Time) statsView {
	st := statsView{
		ByStage:    map[string]int{},
		ByCIStatus: map[string]int{},
		ByLanguage: map[string]int{},
		Total:      len(projects),
		AsOf:       now.Format(time.RFC3339),
	}
	var prioritySum, priorityN int
	for _, p := range projects {
		st.ByStage[string(p.Stage)]++
		ciKey := string(p.CIStatus)
		if ciKey == "" {
			ciKey = "unknown"
		}
		st.ByCIStatus[ciKey]++
		if p.Language != "" {
			st.ByLanguage[p.Language]++
		}
		st.TotalOpenPRs += p.OpenPRs
		st.TotalOpenIssues += p.OpenIssues
		if p.Sprint != nil {
			st.WithActiveSprint++
		}
		if p.Priority > 0 {
			prioritySum += p.Priority
			priorityN++
		}
		if p.Stage == project.StageActive && !p.LatestActivity.IsZero() &&
			int(now.Sub(p.LatestActivity).Hours()/24) >= 14 {
			st.StaleActiveCount++
		}
	}
	if priorityN > 0 {
		st.AvgPriority = float64(prioritySum) / float64(priorityN)
	}
	return st
}

func humanStats(w io.Writer, st statsView) {
	fmt.Fprintf(w, "total: %d\n", st.Total)
	fmt.Fprintf(w, "open PRs: %d   open issues: %d   stale active: %d   avg priority: %.2f\n",
		st.TotalOpenPRs, st.TotalOpenIssues, st.StaleActiveCount, st.AvgPriority)
	printCountMap(w, "by stage", st.ByStage)
	printCountMap(w, "by ci_status", st.ByCIStatus)
	printCountMap(w, "by language", st.ByLanguage)
}

func printCountMap(w io.Writer, title string, m map[string]int) {
	if len(m) == 0 {
		return
	}
	keys := make([]string, 0, len(m))
	for k := range m {
		keys = append(keys, k)
	}
	sort.Strings(keys)
	fmt.Fprintf(w, "%s:\n", title)
	tw := tabwriter.NewWriter(w, 0, 2, 2, ' ', 0)
	for _, k := range keys {
		fmt.Fprintf(tw, "  %s\t%d\n", k, m[k])
	}
	_ = tw.Flush()
}

// ─── secretscan ──────────────────────────────────────────────

func humanSecretScan(w io.Writer, r secretscan.BatchResult, scanned, sources int) {
	fmt.Fprintf(w, "scanned_projects: %d   sources_scanned: %d   total_findings: %d\n",
		scanned, sources, r.Total)
	if r.Total == 0 {
		return
	}
	printCountMap(w, "by severity", r.BySeverity)
	for _, src := range r.SourceOrder {
		for _, f := range r.BySource[src] {
			fmt.Fprintf(w, "  [%s] %s  %s  (entropy %.2f)\n", f.Severity, src, f.RuleID, f.Entropy)
		}
	}
}

// ─── sbom ────────────────────────────────────────────────────

func humanSbom(w io.Writer, b *sbom.Bom) {
	humanSbomSummary(w, b.Summarize())
	if len(b.Components) == 0 {
		return
	}
	fmt.Fprintln(w, "components:")
	tw := tabwriter.NewWriter(w, 0, 2, 2, ' ', 0)
	for _, c := range b.Components {
		fmt.Fprintf(tw, "  %s\t%s\n", c.Name, c.Version)
	}
	_ = tw.Flush()
}

func humanSbomSummary(w io.Writer, s sbom.Summary) {
	fmt.Fprintf(w, "%s %s (%s)\n", dash(s.Application), s.Version, dash(s.GoVersion))
	fmt.Fprintf(w, "spec: CycloneDX %s   components: %d   generated_at: %s\n",
		s.SpecVersion, s.TotalComponents, s.GeneratedAt)
}

// ─── gha-audit ───────────────────────────────────────────────

func humanGhaAudit(w io.Writer, results map[string][]ghaaudit.Finding) {
	s := ghaaudit.Summarize(results)
	humanGhaSummary(w, s)
	files := make([]string, 0, len(results))
	for f := range results {
		files = append(files, f)
	}
	sort.Strings(files)
	for _, f := range files {
		for _, fn := range results[f] {
			fmt.Fprintf(w, "  [%s] %s:%d  %s  %s\n", fn.Severity, f, fn.Line, fn.RuleID, fn.Description)
		}
	}
}

func humanGhaSummary(w io.Writer, s ghaaudit.Summary) {
	fmt.Fprintf(w, "files: %d   findings: %d\n", s.TotalFiles, s.TotalFindings)
	printCountMap(w, "by severity", s.BySeverity)
}

// ─── pin-drift ───────────────────────────────────────────────

func humanPinDrift(w io.Writer, results []pindrift.Result) {
	s := pindrift.Summarize(results)
	fmt.Fprintf(w, "total_pins: %d\n", s.TotalPins)
	printCountMap(w, "by status", s.ByStatus)
	tw := tabwriter.NewWriter(w, 0, 2, 2, ' ', 0)
	for _, r := range results {
		fmt.Fprintf(tw, "  %s\t%s/%s@%s\t%s\n",
			r.Status, r.Pin.Owner, r.Pin.Repo, shortSHA(r.Pin.PinnedSHA), r.Detail)
	}
	_ = tw.Flush()
}

// ─── small helpers ───────────────────────────────────────────

func dash(s string) string {
	if s == "" {
		return "-"
	}
	return s
}

func shortSHA(s string) string {
	if len(s) > 12 {
		return s[:12]
	}
	return s
}
