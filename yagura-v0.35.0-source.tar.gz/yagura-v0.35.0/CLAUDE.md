# CLAUDE.md — yagura development guide

> このファイルは yagura を Claude Code / Windsurf で開発する際の context guide。
> m's harness G1.P 「Plan.md 必須記載項目」の構造に従う + Claude Code 推奨形式
> (Why / Map / Rules / Workflows) を採用。

## Why — yagura は何か、何でないか

yagura は **portfolio orchestrator + harness** で、m's sovereign computing stack
23+ projects (Breeze, Tessera, IZANAGI, Cotton, Strawberry, Otedama, ...) を
**1 つの zero-dep Go daemon** で運用する MCP server。

cortex flywheel 4 段階すべてを単体で機械化:
- ② Review:  `quality_check` + `ai_verify` + `test_audit` + `secretscan` + `gha_audit` + `pin_drift`
- ③ Release: `release_radar` (Plan.md aware ranking)
- ④ Alert-Fix: `alert_fix` (6 source × 4 severity の rule-based recommendation hub)

**yagura が *ない* もの**:
- LLM 呼出(全 rule-based、deterministic)
- 外部 SaaS 依存(GitHub API は scanner 経由のみ、optional)
- マルチエージェント orchestrator(MCP server 一品)
- code generation tool(yagura は audit/orchestrate のみ)

## Map — 46 internal packages

### Core orchestration
- `internal/registry` — 23+ projects の inventory CRUD
- `internal/project` — Project struct + validation
- `internal/mcp` — MCP server + 58 tool definitions
- `internal/audit` — JSONL audit log + replay
- `internal/config` — env / flag 設定

### Quality guides (pre-emptive)
- `internal/qualitycheck` — code lint (as any, TODO/FIXME 等)
- `internal/secretscan` — gitleaks-like secret 検出
- `internal/publicityscan` — 公開前 leak 検出(home パス/内部 host/private IP/email)★ v0.35
- `internal/sbom` — CycloneDX SBOM 生成
- `internal/vex` — OpenVEX v0.2.0 文書の決定論的生成(Build/Merge)+ 構造 lint
  (Validate/ParseAndValidate)。spec: `docs/vex-spec.md`。CLI `vex-audit` が
  `docs/vex/*.json` を CI 検証(SBOM 過剰報告の補完)★ v0.35
- `internal/ghaaudit` — GitHub Actions workflow audit
- `internal/pindrift` — 依存 pin 漏れ検出
- `internal/aiverify` — AI 生成 code の risk pattern 検出 ★ v0.25
- `internal/testcoverage` — source-test 対応検出 ★ v0.26

### Security sensors (observation)
- `internal/osv` — OSV.dev 脆弱性 API client
- `internal/scorecard` — OpenSSF Scorecard 取得
- `internal/scanner` — 24h 周期で project metadata 更新

### Agent handoff (Claude Code ↔ Windsurf)
- `internal/quotamonitor` — quota tracking + forecast + JSONL persist
- `internal/handoff` — handoff session management
- `internal/agentlauncher` — agent process spawn
- `internal/workspace` — session save/load
- `internal/harness` — .claude/ + MCP 監査(skill/subagent/workflow/settings/agent-config/plugin/mcp)

### Reasoning / multi-AI (★ v0.35)
- `internal/agentparallel` — 複数 AI への deterministic な並列 dispatch planner(LPT)
- `internal/riskreason` — Cyber Risk Reasoning Layer(CVSS+資産+到達性+攻撃性の複合判断)
- `internal/recovery` — self-healing orchestration の決定論的 recovery 判断(retry/replan/escalate)
- `internal/selfimprove` — harness レベル再帰的自己改善(RSI)の決定論的カーネル
  (自己メトリクス→優先度つき改善提案 + 後退検出)。spec: `docs/self-improvement.md` ★ v0.35
- `internal/pathpolicy` — 変更パスを glob ルールで deny/review/allow する deterministic guardrail
  (CLI `path-policy` / `.yagura/paths.json` で ADR-0001 等を gate)★ v0.35

### Graph / dependencies
- `internal/projectgraph` — depends_on graph(neighbors / impact / stats)

### Cross-tool infra
- `internal/dedupe` — content-addressed cache (LRU + TTL) ★ v0.23
- `internal/plantracker` — Plan.md aware progress parser ★ v0.24
- `internal/alertfix` — health signal aggregator + rule-based recommendation ★ v0.27

### Observation / meta
- `internal/dashboard` — HTML dashboard (薄め)
- `internal/telemetry` — internal stats
- `internal/metrics` — counter / gauge primitives
- `internal/logging` — structured slog wrapper
- `internal/httplimit` — http rate limit middleware
- `internal/github` — minimal GitHub API client

## Rules (immutable — 22 リリースで維持)

### ADR-0001 — Zero external Go dependencies
- `go.mod` は `github.com/shizukutanaka/yagura` のみ、stdlib のみ依存
- 22 リリース連続で維持(reproducible build の前提)
- 例外: 検証なし(他案を尽くしてから提案)

### Reproducibility
- `make verify` が byte-for-byte identical build を 2 回連続で生成
- `-trimpath -buildvcs=false` + `CGO_ENABLED=0`
- 22 リリース連続で SHA 一致を維持

### Trust base
- sensor data (vuln_critical, ci_status, scorecard_score, latest_activity 等)
  は scanner 専用で MCP tool 経由 update 不可
- これにより agent / human が sensor 値を捏造できない
- `yagura_update` は manual metadata (display_name, language, local_path, notes,
  priority, tags, stage, depends_on) のみ受付

### Tool descriptions
- v0.21 以降 caveman 化: 最大 ~50 byte 平均
- `[G]` prefix = Guide (pre-emptive control)
- `[S]` prefix = Sensor (observation)
- compact mode (`YAGURA_MCP_COMPACT=1`) では `[G]` / `[S]` だけに圧縮

### Deterministic output
- sort 順、tie-break が決定論的
- audit log は時系列順
- regression test で出力比較が安定

## Workflows (典型的な開発フロー)

### 新 MCP tool 追加
1. `internal/<topic>/<topic>.go` で domain logic を書く(test cov ≥ 90% 目標)
2. `internal/mcp/tools.go` に `build<X>Tool(d Deps) *Tool` を追加
3. `RegisterDefaultTools` の末尾に `s.Register(build<X>Tool(d))` を追加
4. `cmd/yagura/integration_test.go` の expected names list と tool 数 (`if len(...) != N`) を更新
5. `internal/mcp/server_test.go` も同様
6. CHANGELOG に entry 追加(必ず Synergy / What's not yet / Sources セクション含む)
7. version bump (`cmd/yagura/main.go`, `cmd/yagura/main_test.go`,
   `internal/dashboard/dashboard.go`, `README.md`)
8. `make verify` で reproducible 確認
9. tarball を `/mnt/user-data/outputs/yagura-vX.Y.Z-source.tar.gz` に出力

### 新 sensor 統合
1. 既存 `internal/scanner` の 24h loop に hook
2. `project.Project` struct に新 field 追加(`omitempty`)
3. registry validate を通すか確認
4. alertfix.ProjectSnapshot に extract field 追加
5. alertfix.Evaluate に新 rule 追加(rule-based recommendation 込み)

### handoff loop の test
1. 2 つの agent (claude_code + windsurf) を `quota_report` で manual 報告
2. `usage_summary` で reliability check (samples ≥ 3 必要)
3. `handoff` で switch trigger
4. `agent_status` で state 確認

## Gotchas — 22 リリースで踏んだ罠

### Registry.Get は `(*project.Project, error)`、Registry.List は `[]*project.Project`
ポインタ。値型と勘違いしやすい。

### `yagura_register` の priority は 0-5
9 や 10 を渡すと validate で reject される。

### Plan.md は LocalPath 配下にあるのが前提
`yagura_register` で local_path を省略すると plan_status / release_radar が
全 project skip する。

### compact mode は env opt-in
`YAGURA_MCP_COMPACT=1` で発火。他は完全に後方互換。

### dedupe cache は in-memory のみ
daemon restart で消失。重い計算結果は persistent cache(v0.29+ 候補)が必要。

### audit log の write は best-effort
write エラーは ignore。critical path をブロックしない設計。

### JSONL legacy / compact 両対応
v0.17 以降の `usage_history.jsonl` は legacy + compact 形式が混在。
`persistEntry.resolve()` が両方を扱う。手動で書き換えるとフォーマットが
壊れる可能性。

### sensor data は MCP tool で update 不可
trust base 保護のため意図的。alert_fix の live smoke で plan 以外は scanner
経由 inject が必要。

## Roadmap (carry-over)

優先度順:
1. **tools.go の topic 別分割** (v0.29 候補, scope 大)
2. **Scanner ↔ alert_fix periodic loop** (v0.29 候補)
3. **Persistent cache** (sbom / aiverify 結果を disk に)
4. **Custom rule loading** (`.yagura/aiverify.yaml` 等)
5. **Alert lifecycle** (last-seen / resolved / snooze)
6. **AST analysis** (zero-dep 制約と相談)
7. **OAuth / Marketplace / Code Mode** (long-standing)

## References

- m's harness V1.8 (一次入力)
- cortex / aircloset 2026/05 Zenn 記事 (4 flywheel)
- arXiv 2604.01052 VibeGuard (AI Code Security Gate Framework)
- Anthropic engineering blog (advanced tool use)
- Veracode 2025 (45% OWASP failure for AI code)
