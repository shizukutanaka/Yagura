package secrets

import (
	"bytes"
	"crypto/sha256"
	"encoding/hex"
	"errors"
	"os"
	"path/filepath"
	"strings"
	"testing"
)

// ─── Encrypt / Decrypt round-trip ────────────────────────────

func TestEncryptDecrypt_RoundTrip(t *testing.T) {
	plaintext := []byte("hello, world. this is a secret.")
	passphrase := "correct-horse-battery-staple"

	encrypted, err := Encrypt(plaintext, passphrase)
	if err != nil {
		t.Fatal(err)
	}
	if !bytes.HasPrefix(encrypted, []byte(formatHeader)) {
		t.Errorf("output should start with format header")
	}

	decrypted, err := Decrypt(encrypted, passphrase)
	if err != nil {
		t.Fatal(err)
	}
	if !bytes.Equal(decrypted, plaintext) {
		t.Errorf("round-trip mismatch:\n  in:  %q\n  out: %q", plaintext, decrypted)
	}
}

func TestEncrypt_DifferentSaltsEachCall(t *testing.T) {
	plaintext := []byte("same")
	passphrase := "same-passphrase-12345"
	a, _ := Encrypt(plaintext, passphrase)
	b, _ := Encrypt(plaintext, passphrase)
	if bytes.Equal(a, b) {
		t.Error("two encryptions of same plaintext should differ (salt + nonce)")
	}
}

func TestEncrypt_PassphraseTooShort(t *testing.T) {
	_, err := Encrypt([]byte("hi"), "short")
	if !errors.Is(err, ErrPassphraseTooShort) {
		t.Errorf("expected ErrPassphraseTooShort, got %v", err)
	}
}

func TestEncrypt_ExactMinLength(t *testing.T) {
	// 12 chars exactly
	_, err := Encrypt([]byte("data"), "exactly12chr")
	if err != nil {
		t.Errorf("12-char passphrase should be accepted: %v", err)
	}
}

func TestDecrypt_WrongPassphrase(t *testing.T) {
	encrypted, _ := Encrypt([]byte("secret"), "correct-passphrase-1")
	_, err := Decrypt(encrypted, "wrong-passphrase-12345")
	if !errors.Is(err, ErrAuthenticationFailed) {
		t.Errorf("expected ErrAuthenticationFailed, got %v", err)
	}
}

func TestDecrypt_TamperedCiphertext(t *testing.T) {
	encrypted, _ := Encrypt([]byte("secret data"), "correct-passphrase-1")
	// Flip one byte in the data line
	idx := bytes.Index(encrypted, []byte("data="))
	if idx < 0 {
		t.Fatal("data= not found")
	}
	// Flip a base64 character somewhere safe
	encrypted[idx+10] ^= 0x01

	_, err := Decrypt(encrypted, "correct-passphrase-1")
	if err == nil {
		t.Error("tampered ciphertext should fail to decrypt")
	}
}

func TestDecrypt_TamperedHeader(t *testing.T) {
	encrypted, _ := Encrypt([]byte("secret"), "correct-passphrase-1")
	// Replace YAGURA-SECRET-V1 with YAGURA-SECRET-V2
	encrypted = bytes.Replace(encrypted, []byte("YAGURA-SECRET-V1"), []byte("YAGURA-SECRET-V2"), 1)
	_, err := Decrypt(encrypted, "correct-passphrase-1")
	if !errors.Is(err, ErrInvalidFormat) {
		t.Errorf("expected ErrInvalidFormat, got %v", err)
	}
}

func TestDecrypt_InvalidFormat(t *testing.T) {
	tests := [][]byte{
		[]byte(""),
		[]byte("hello"),
		[]byte("YAGURA-SECRET-V1\n"),                       // no fields
		[]byte("YAGURA-SECRET-V1\niter=600000\n"),          // partial
		[]byte("YAGURA-SECRET-V1\nmalformed-line\n"),       // missing =
	}
	for i, in := range tests {
		_, err := Decrypt(in, "correct-passphrase-1")
		if err == nil {
			t.Errorf("case %d: expected error", i)
		}
	}
}

func TestDecrypt_FileTooLarge(t *testing.T) {
	big := make([]byte, maxFileSize+1)
	_, err := Decrypt(big, "correct-passphrase-1")
	if err == nil || !strings.Contains(err.Error(), "too large") {
		t.Errorf("expected size error, got %v", err)
	}
}

// ─── PBKDF2 reference vectors ────────────────────────────────

// RFC 6070 vectors are for SHA-1 only. For SHA-256 we use the
// reference vectors from https://stackoverflow.com/a/5136918
// and confirmed against Python's hashlib.pbkdf2_hmac.
func TestPBKDF2_KnownVectors(t *testing.T) {
	tests := []struct {
		password string
		salt     string
		iter     int
		keyLen   int
		expected string // hex
	}{
		// PBKDF2-HMAC-SHA256 test vector (RFC-style, verified)
		{
			password: "password",
			salt:     "salt",
			iter:     1,
			keyLen:   32,
			expected: "120fb6cffcf8b32c43e7225256c4f837a86548c92ccc35480805987cb70be17b",
		},
		{
			password: "password",
			salt:     "salt",
			iter:     2,
			keyLen:   32,
			expected: "ae4d0c95af6b46d32d0adff928f06dd02a303f8ef3c251dfd6e2d85a95474c43",
		},
		{
			password: "passwordPASSWORDpassword",
			salt:     "saltSALTsaltSALTsaltSALTsaltSALTsalt",
			iter:     4096,
			keyLen:   40,
			expected: "348c89dbcbd32b2f32d814b8116e84cf2b17347ebc1800181c4e2a1fb8dd53e1c635518c7dac47e9",
		},
	}
	for i, tt := range tests {
		got := pbkdf2Key([]byte(tt.password), []byte(tt.salt), tt.iter, tt.keyLen)
		gotHex := hex.EncodeToString(got)
		if gotHex != tt.expected {
			t.Errorf("vector %d: got %s want %s", i, gotHex, tt.expected)
		}
	}
}

func TestPBKDF2_DerivedKeyDeterministic(t *testing.T) {
	// Same input → same output
	a := pbkdf2Key([]byte("pw"), []byte("salt"), 1000, 32)
	b := pbkdf2Key([]byte("pw"), []byte("salt"), 1000, 32)
	if !bytes.Equal(a, b) {
		t.Error("PBKDF2 should be deterministic")
	}
	// Different salts → different outputs
	c := pbkdf2Key([]byte("pw"), []byte("other"), 1000, 32)
	if bytes.Equal(a, c) {
		t.Error("different salt should give different key")
	}
}

func TestSHA256Available(t *testing.T) {
	// Smoke test ensuring our pbkdf2 produces 32-byte output consistent with sha256
	h := sha256.Sum256([]byte("test"))
	if len(h) != 32 {
		t.Fatal("sha256 broken")
	}
}

// ─── validateName ────────────────────────────────────────────

func TestValidateName(t *testing.T) {
	valid := []string{"a", "github-token", "MCP_TOKEN", "v1.2.3", "abc123", "x.y.z"}
	for _, n := range valid {
		if err := validateName(n); err != nil {
			t.Errorf("%q should be valid: %v", n, err)
		}
	}
	invalid := []string{
		"",                  // empty
		"../etc/passwd",     // path traversal
		"/abs",              // absolute
		"name with spaces",  // space
		"name\x00null",      // null byte
		".hidden",           // leading dot
		"-flag",             // leading hyphen
		strings.Repeat("a", 201), // too long
		"日本語",              // non-ASCII (intentional restriction)
		"name/sub",          // slash
	}
	for _, n := range invalid {
		if err := validateName(n); err == nil {
			t.Errorf("%q should be invalid", n)
		}
	}
}

// ─── Store ───────────────────────────────────────────────────

func TestStore_RoundTrip(t *testing.T) {
	s, err := NewStore(t.TempDir())
	if err != nil {
		t.Fatal(err)
	}
	pass := "correct-horse-battery-staple"
	if err := s.Set("github_pat", []byte("ghp_abc123"), pass); err != nil {
		t.Fatal(err)
	}
	got, err := s.Get("github_pat", pass)
	if err != nil {
		t.Fatal(err)
	}
	if string(got) != "ghp_abc123" {
		t.Errorf("round-trip: got %q", got)
	}

	// File should be mode 0600
	info, _ := os.Stat(filepath.Join(s.dir, "github_pat.enc"))
	if info.Mode().Perm() != 0o600 {
		t.Errorf("expected mode 0600, got %v", info.Mode().Perm())
	}
}

func TestStore_Get_NotFound(t *testing.T) {
	s, _ := NewStore(t.TempDir())
	_, err := s.Get("missing", "correct-passphrase-1")
	if !errors.Is(err, os.ErrNotExist) {
		t.Errorf("expected ErrNotExist, got %v", err)
	}
}

func TestStore_List(t *testing.T) {
	s, _ := NewStore(t.TempDir())
	pass := "correct-passphrase-1"
	_ = s.Set("alpha", []byte("a"), pass)
	_ = s.Set("beta", []byte("b"), pass)
	_ = s.Set("gamma", []byte("c"), pass)

	names, err := s.List()
	if err != nil {
		t.Fatal(err)
	}
	if len(names) != 3 {
		t.Fatalf("expected 3 entries, got %d", len(names))
	}
}

func TestStore_List_Empty(t *testing.T) {
	s, _ := NewStore(t.TempDir())
	names, err := s.List()
	if err != nil {
		t.Fatal(err)
	}
	if len(names) != 0 {
		t.Errorf("expected 0, got %d", len(names))
	}
}

func TestStore_Delete(t *testing.T) {
	s, _ := NewStore(t.TempDir())
	pass := "correct-passphrase-1"
	_ = s.Set("delete-me", []byte("data"), pass)
	if err := s.Delete("delete-me"); err != nil {
		t.Fatal(err)
	}
	_, err := s.Get("delete-me", pass)
	if !errors.Is(err, os.ErrNotExist) {
		t.Errorf("should be gone, got %v", err)
	}
	// Delete is idempotent
	if err := s.Delete("delete-me"); err != nil {
		t.Errorf("second delete should be no-op: %v", err)
	}
}

func TestStore_RejectsInvalidNames(t *testing.T) {
	s, _ := NewStore(t.TempDir())
	for _, bad := range []string{"", "../escape", "name with space"} {
		if err := s.Set(bad, []byte("data"), "correct-passphrase-1"); err == nil {
			t.Errorf("Set(%q) should be rejected", bad)
		}
		if _, err := s.Get(bad, "correct-passphrase-1"); err == nil {
			t.Errorf("Get(%q) should be rejected", bad)
		}
		if err := s.Delete(bad); err == nil {
			t.Errorf("Delete(%q) should be rejected", bad)
		}
	}
}

func TestStore_AtomicReplace(t *testing.T) {
	s, _ := NewStore(t.TempDir())
	pass := "correct-passphrase-1"

	if err := s.Set("v", []byte("v1"), pass); err != nil {
		t.Fatal(err)
	}
	if err := s.Set("v", []byte("v2"), pass); err != nil {
		t.Fatal(err)
	}
	got, _ := s.Get("v", pass)
	if string(got) != "v2" {
		t.Errorf("expected v2, got %q", got)
	}
	// .tmp file should not linger
	entries, _ := os.ReadDir(s.dir)
	for _, e := range entries {
		if strings.HasSuffix(e.Name(), ".tmp") {
			t.Errorf("leftover .tmp file: %s", e.Name())
		}
	}
}

// ─── EqualBytes ─────────────────────────────────────────────

func TestEqualBytes(t *testing.T) {
	if !EqualBytes([]byte("abc"), []byte("abc")) {
		t.Error("equal slices should be equal")
	}
	if EqualBytes([]byte("abc"), []byte("abd")) {
		t.Error("different slices should not be equal")
	}
	if EqualBytes([]byte("abc"), []byte("abcd")) {
		t.Error("different-length slices should not be equal")
	}
}
