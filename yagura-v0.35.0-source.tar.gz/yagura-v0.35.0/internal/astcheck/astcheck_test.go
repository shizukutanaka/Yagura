package astcheck

import (
	"strings"
	"testing"
)

func ruleSet(fs []Finding) map[string]int {
	m := map[string]int{}
	for _, f := range fs {
		m[f.Rule]++
	}
	return m
}

// ─── os-exit-library: needs package context (regex cannot do this) ───────

func TestScanFile_OsExitInLibrary(t *testing.T) {
	src := `package foo
import "os"
func Boom() { os.Exit(1) }
`
	got := ruleSet(ScanFile("foo.go", src))
	if got["os-exit-library"] != 1 {
		t.Errorf("expected 1 os-exit-library finding in a non-main package, got %d", got["os-exit-library"])
	}
}

func TestScanFile_OsExitInMain_OK(t *testing.T) {
	src := `package main
import "os"
func main() { os.Exit(1) }
`
	if n := ruleSet(ScanFile("main.go", src))["os-exit-library"]; n != 0 {
		t.Errorf("os.Exit in package main is fine, got %d findings", n)
	}
}

func TestScanFile_OsExitInTest_OK(t *testing.T) {
	src := `package foo
import "os"
func TestX() { os.Exit(1) }
`
	if n := ruleSet(ScanFile("foo_test.go", src))["os-exit-library"]; n != 0 {
		t.Errorf("os.Exit in *_test.go is allowed, got %d findings", n)
	}
}

// ─── empty-nil-branch: needs block structure (regex cannot do this) ──────

func TestScanFile_EmptyNilBranch(t *testing.T) {
	src := `package foo
func F() {
	err := do()
	if err != nil {
	}
}
func do() error { return nil }
`
	if n := ruleSet(ScanFile("foo.go", src))["empty-nil-branch"]; n != 1 {
		t.Errorf("expected 1 empty-nil-branch finding, got %d", n)
	}
}

func TestScanFile_NonEmptyNilBranch_OK(t *testing.T) {
	src := `package foo
func F() error {
	err := do()
	if err != nil {
		return err
	}
	return nil
}
func do() error { return nil }
`
	if n := ruleSet(ScanFile("foo.go", src))["empty-nil-branch"]; n != 0 {
		t.Errorf("a handled err != nil branch should not flag, got %d", n)
	}
}

// ─── parse errors are surfaced, not silently skipped ─────────────────────

func TestScanFile_ParseError(t *testing.T) {
	got := ruleSet(ScanFile("broken.go", "package foo\nfunc F( {"))
	if got["parse-error"] < 1 {
		t.Errorf("expected a parse-error finding for unparseable Go, got %v", got)
	}
}

// ─── ScanFiles: Go-only, deterministic ───────────────────────────────────

func TestScanFiles_SkipsNonGo(t *testing.T) {
	files := map[string]string{
		"a.go":   "package foo\nimport \"os\"\nfunc B(){ os.Exit(1) }\n",
		"b.txt":  "os.Exit(1) here is just text",
		"c.json": "{}",
	}
	res := ScanFiles(files)
	if res.FilesScanned != 1 {
		t.Errorf("only a.go is Go; FilesScanned=%d want 1", res.FilesScanned)
	}
	if res.ByRule["os-exit-library"] != 1 {
		t.Errorf("expected the .go os.Exit flagged, non-go ignored; got %v", res.ByRule)
	}
}

// TestScanFiles_Deterministic: output must be byte-stable across the
// randomized map iteration (total-order sort), per the repo invariant.
func TestScanFiles_Deterministic(t *testing.T) {
	files := map[string]string{}
	for _, n := range []string{"a", "b", "c", "d", "e"} {
		files[n+".go"] = "package foo\nimport \"os\"\nfunc X(){ os.Exit(1) }\n"
	}
	sig := func(r Result) string {
		var sb strings.Builder
		for _, f := range r.Findings {
			sb.WriteString(f.File)
			sb.WriteByte('\n')
		}
		return sb.String()
	}
	want := sig(ScanFiles(files))
	for i := 0; i < 30; i++ {
		if got := sig(ScanFiles(files)); got != want {
			t.Fatalf("non-deterministic ScanFiles order:\n%s\nvs\n%s", want, got)
		}
	}
}

// ─── defer-in-loop: needs loop+func scope tracking (regex cannot) ─────────

func TestScanFile_DeferInForLoop(t *testing.T) {
	src := `package foo
func F(xs []string) {
	for i := 0; i < len(xs); i++ {
		defer cleanup()
	}
}
func cleanup() {}
`
	if n := ruleSet(ScanFile("foo.go", src))["defer-in-loop"]; n != 1 {
		t.Errorf("expected 1 defer-in-loop finding, got %d", n)
	}
}

func TestScanFile_DeferInRangeLoop(t *testing.T) {
	src := `package foo
func F(xs []string) {
	for range xs {
		defer cleanup()
	}
}
func cleanup() {}
`
	if n := ruleSet(ScanFile("foo.go", src))["defer-in-loop"]; n != 1 {
		t.Errorf("expected 1 defer-in-loop finding for range loop, got %d", n)
	}
}

func TestScanFile_DeferNotInLoop_OK(t *testing.T) {
	src := `package foo
func F() {
	defer cleanup()
}
func cleanup() {}
`
	if n := ruleSet(ScanFile("foo.go", src))["defer-in-loop"]; n != 0 {
		t.Errorf("a top-level defer must not flag, got %d", n)
	}
}

// A defer inside a closure that is invoked each iteration is the idiomatic fix
// (the closure returns every iteration), so it must NOT be flagged.
func TestScanFile_DeferInClosureInLoop_OK(t *testing.T) {
	src := `package foo
func F(xs []string) {
	for range xs {
		func() {
			defer cleanup()
		}()
	}
}
func cleanup() {}
`
	if n := ruleSet(ScanFile("foo.go", src))["defer-in-loop"]; n != 0 {
		t.Errorf("defer in a per-iteration closure is fine, got %d", n)
	}
}
