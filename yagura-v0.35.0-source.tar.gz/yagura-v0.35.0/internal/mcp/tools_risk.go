// tools_risk.go: yagura_risk_triage — Cyber Risk Reasoning Layer。
//
// 「AIセキュリティは検知ロジックから複合判断へ」— CVSS 単体ではなく、脆弱性深刻度 +
// 資産の業務重要度 + 到達可能性 + 攻撃可能性 + 横展開 blast radius + パッチ業務影響を
// 合わせて修正優先度を出す(internal/riskreason)。Yagura は LLM を使わず rule-based /
// deterministic に判断し、根拠(factors)と評価できなかった文脈(unknowns)を必ず返す
// ので、SOC/CSIRT/脆弱性管理/経営が検証できる(Human-in-the-Loop / audit 前提)。
//
// findings(CVE+CVSS 等、yagura_vulns の出力を流せる)を入力に取り、slug が registry に
// あれば asset_priority/stage/tags を自動補完し、projectgraph の Impact で blast radius
// (依存元数)を埋める。これが記事の言う「技術ログ・脆弱性・到達性・業務影響を 1 つの
// 説明可能な判断にまとめる」層にあたる。

package mcp

import (
	"context"
	"encoding/json"
	"fmt"

	"github.com/shizukutanaka/yagura/internal/projectgraph"
	"github.com/shizukutanaka/yagura/internal/riskreason"
)

func buildRiskTriageTool(d Deps) *Tool {
	return &Tool{
		Name:        "yagura_risk_triage",
		Description: "[G] Composite fix-priority for CVEs (asset+reach+exploit, with rationale).",
		InputSchema: map[string]any{
			"type": "object",
			"properties": map[string]any{
				"findings": map[string]any{
					"type":        "array",
					"description": "Vulnerabilities to triage. Each: {cve, cvss?, severity?, internet_exposed?, auth_required?, waf_protected?, known_exploited?, public_exploit?, patch_blocks_business?}.",
					"items":       map[string]any{"type": "object"},
				},
				"slug": map[string]any{
					"type":        "string",
					"description": "Registered asset slug — auto-fills asset_priority/stage/tags and blast radius (dependents) from the registry + dependency graph.",
				},
				// slug が無い/未登録のときに資産文脈を明示する任意フィールド。
				"asset_priority": map[string]any{"type": "integer"},
				"stage":          map[string]any{"type": "string"},
				"tags":           map[string]any{"type": "array", "items": map[string]any{"type": "string"}},
				"dependents":     map[string]any{"type": "integer"},
			},
			"required": []string{"findings"},
		},
		Handler: func(ctx context.Context, args json.RawMessage) (any, error) {
			var in struct {
				Findings []struct {
					CVE                 string  `json:"cve"`
					CVSS                float64 `json:"cvss"`
					Severity            string  `json:"severity"`
					InternetExposed     *bool   `json:"internet_exposed"`
					AuthRequired        *bool   `json:"auth_required"`
					WAFProtected        *bool   `json:"waf_protected"`
					KnownExploited      *bool   `json:"known_exploited"`
					PublicExploit       *bool   `json:"public_exploit"`
					PatchBlocksBusiness *bool   `json:"patch_blocks_business"`
				} `json:"findings"`
				Slug          string   `json:"slug"`
				AssetPriority int      `json:"asset_priority"`
				Stage         string   `json:"stage"`
				Tags          []string `json:"tags"`
				Dependents    int      `json:"dependents"`
			}
			if err := json.Unmarshal(args, &in); err != nil {
				return nil, &ToolError{Code: "invalid_input", Cause: err}
			}
			if len(in.Findings) == 0 {
				return nil, &ToolError{Code: "invalid_input", Message: "at least one finding is required"}
			}

			// slug があれば registry + graph から資産文脈を補完。
			assetPriority, stage, tags, dependents := in.AssetPriority, in.Stage, in.Tags, in.Dependents
			resolvedSlug := ""
			var warnings []string
			if in.Slug != "" {
				resolved := false
				if d.Registry != nil {
					if p, err := d.Registry.Get(in.Slug); err == nil && p != nil {
						resolvedSlug = p.Slug
						assetPriority = p.Priority
						stage = string(p.Stage)
						tags = p.Tags
						g := projectgraph.Build(toGraphProjects(d.Registry.List()))
						dependents = g.Impact(p.Slug).ImpactCount
						resolved = true
					}
				}
				if !resolved {
					// slug が解決しないと caller 提供の文脈を黙って使ってしまうため明示する。
					warnings = append(warnings, fmt.Sprintf(
						"slug %q not found in registry; using caller-supplied asset context (priority/stage/tags/dependents)", in.Slug))
				}
			}

			inputs := make([]riskreason.Input, 0, len(in.Findings))
			for _, f := range in.Findings {
				inputs = append(inputs, riskreason.Input{
					CVE: f.CVE, CVSS: f.CVSS, Severity: f.Severity,
					AssetPriority: assetPriority, Stage: stage, Tags: tags,
					InternetExposed: f.InternetExposed, AuthRequired: f.AuthRequired, WAFProtected: f.WAFProtected,
					KnownExploited: f.KnownExploited, PublicExploit: f.PublicExploit,
					Dependents: dependents, PatchBlocksBusiness: f.PatchBlocksBusiness,
				})
			}
			results := riskreason.ScoreAll(inputs)

			// priority 別サマリ(決定論)。
			summary := map[string]int{}
			for _, r := range results {
				summary[string(r.Priority)]++
			}
			out := map[string]any{
				"asset": map[string]any{
					"slug":           resolvedSlug,
					"asset_priority": assetPriority,
					"stage":          stage,
					"dependents":     dependents,
				},
				"triaged": results,
				"summary": summary,
			}
			if len(warnings) > 0 {
				out["warnings"] = warnings
			}
			return out, nil
		},
	}
}
