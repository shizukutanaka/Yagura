package mcp

import (
	"context"
	"encoding/json"
	"testing"
	"time"
)

func vexDeps() Deps {
	return Deps{Now: func() time.Time { return time.Date(2026, 6, 6, 12, 0, 0, 0, time.UTC) }}
}

func callVEX(t *testing.T, args string) map[string]any {
	t.Helper()
	tool := buildVEXTool(vexDeps())
	out, err := tool.Handler(context.Background(), json.RawMessage(args))
	if err != nil {
		t.Fatalf("handler error: %v", err)
	}
	m, ok := out.(map[string]any)
	if !ok {
		t.Fatalf("output not a map: %T", out)
	}
	return m
}

func TestVEXTool_BuildAndValidate(t *testing.T) {
	m := callVEX(t, `{"author":"acme","statements":[
		{"cve":"CVE-2025-0001","status":"not_affected","justification":"component_not_present"},
		{"cve":"CVE-2025-0002","status":"affected","action":"upgrade to 2.0","product":"pkg:golang/x"}
	]}`)
	issues, _ := m["issues"].([]string)
	if len(issues) != 0 {
		t.Errorf("expected no issues, got %v", issues)
	}
	if m["document"] == nil {
		t.Error("expected document in output")
	}
}

func TestVEXTool_SurfacesIssues(t *testing.T) {
	m := callVEX(t, `{"statements":[{"cve":"CVE-2025-0001","status":"not_affected"}]}`)
	issues, _ := m["issues"].([]string)
	if len(issues) == 0 {
		t.Error("expected a lint issue for not_affected without justification")
	}
}

func TestVEXTool_EmptyStatements(t *testing.T) {
	tool := buildVEXTool(vexDeps())
	if _, err := tool.Handler(context.Background(), json.RawMessage(`{"statements":[]}`)); err == nil {
		t.Error("expected error for empty statements")
	}
}

func TestVEXTool_BadInput(t *testing.T) {
	tool := buildVEXTool(vexDeps())
	if _, err := tool.Handler(context.Background(), json.RawMessage(`{`)); err == nil {
		t.Error("expected error for malformed JSON")
	}
}
