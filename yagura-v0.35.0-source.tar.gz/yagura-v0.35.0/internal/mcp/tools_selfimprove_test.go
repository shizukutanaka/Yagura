package mcp

import (
	"context"
	"encoding/json"
	"testing"
)

func TestSelfImproveTool(t *testing.T) {
	tool := buildSelfImproveTool(Deps{})
	out, err := tool.Handler(context.Background(), json.RawMessage(`{
		"session_calls": 100,
		"tools": [{"name":"yagura_x","calls":20,"errors":8,"avg_resp_bytes":200}],
		"skills": [{"path":"a/SKILL.md","score":20,"retire":true}],
		"coverage_gaps": ["feedback:runtime"]
	}`))
	if err != nil {
		t.Fatalf("handler error: %v", err)
	}
	b, _ := json.Marshal(out)
	var r struct {
		Proposals []struct {
			Kind     string `json:"kind"`
			Severity string `json:"severity"`
		} `json:"proposals"`
		Summary string `json:"summary"`
	}
	if err := json.Unmarshal(b, &r); err != nil {
		t.Fatalf("unmarshal: %v", err)
	}
	if len(r.Proposals) < 3 {
		t.Errorf("expected reliability+retire+coverage proposals, got %d: %s", len(r.Proposals), b)
	}
	if r.Proposals[0].Severity != "high" {
		t.Errorf("highest-severity proposal should rank first, got %s", r.Proposals[0].Severity)
	}
	if r.Summary == "" {
		t.Error("summary should be set")
	}
}

func TestSelfImproveTool_Empty(t *testing.T) {
	tool := buildSelfImproveTool(Deps{})
	out, err := tool.Handler(context.Background(), json.RawMessage(`{}`))
	if err != nil {
		t.Fatalf("handler error: %v", err)
	}
	b, _ := json.Marshal(out)
	if !json.Valid(b) {
		t.Fatal("output not valid json")
	}
}

func TestSelfImproveTool_BadInput(t *testing.T) {
	tool := buildSelfImproveTool(Deps{})
	if _, err := tool.Handler(context.Background(), json.RawMessage(`{`)); err == nil {
		t.Error("expected error for malformed JSON")
	}
}
