// tools_security.go: extracted from tools.go in v0.29 (gstack-style topic split).
//
// All tools in this file are registered via RegisterDefaultTools in tools.go.
// See CLAUDE.md Workflows for the registration pattern.

package mcp

import (
	"context"
	"encoding/json"
	"errors"
	"strings"
	"time"
	"github.com/shizukutanaka/yagura/internal/osv"
	"github.com/shizukutanaka/yagura/internal/project"
	"github.com/shizukutanaka/yagura/internal/scorecard"
)

func buildVulnsTool(d Deps) *Tool {
	return &Tool{
		Name: "yagura_vulns",
		Description: "[S] OSV.dev vulns by CVSS desc.",
		InputSchema: map[string]any{
			"type": "object",
			"properties": map[string]any{
				"slug":      map[string]any{"type": "string", "description": "登録済みプロジェクトの slug"},
				"package":   map[string]any{"type": "string", "description": "パッケージ識別子(Go module path 等)"},
				"version":   map[string]any{"type": "string", "description": "バージョン文字列(省略時は全バージョン)"},
				"ecosystem": map[string]any{"type": "string", "description": "OSV ecosystem(Go/PyPI/npm 等)"},
				"min_severity": map[string]any{
					"type":        "string",
				},
			},
		},
		Handler: func(ctx context.Context, args json.RawMessage) (any, error) {
			if d.OSV == nil {
				return nil, &ToolError{Code: "unavailable",
					Message: "OSV client not configured at startup"}
			}
			var in struct {
				Slug        string `json:"slug"`
				Package     string `json:"package"`
				Version     string `json:"version"`
				Ecosystem   string `json:"ecosystem"`
				MinSeverity string `json:"min_severity"`
			}
			if err := json.Unmarshal(args, &in); err != nil {
				return nil, &ToolError{Code: "invalid_input", Message: "invalid args", Cause: err}
			}

			// パターン 1: slug 経由(registry から language 取得 → ecosystem 推定)
			// パターン 2: package + ecosystem 直接指定
			pkg := strings.TrimSpace(in.Package)
			ecosystem := strings.TrimSpace(in.Ecosystem)
			version := strings.TrimSpace(in.Version)
			var resolvedFrom string

			if in.Slug != "" {
				p, err := d.Registry.Get(in.Slug)
				if err != nil {
					return nil, &ToolError{Code: "not_found",
						Message: "project not found: " + in.Slug}
				}
				if ecosystem == "" {
					ecosystem = osv.LanguageToEcosystem(p.Language)
				}
				if pkg == "" {
					// Repository field を package 識別子の fallback として使用
					// (Go の場合: "github.com/owner/repo" がそのまま module path)
					pkg = p.Repository
				}
				if version == "" && p.LatestVersion != "" {
					version = p.LatestVersion
				}
				resolvedFrom = in.Slug
			}

			if pkg == "" {
				return nil, &ToolError{Code: "invalid_input",
					Message: "package is required (either via slug or directly)"}
			}
			if ecosystem == "" {
				return nil, &ToolError{Code: "invalid_input",
					Message: "ecosystem is required (could not infer from project language)"}
			}

			vulns, err := d.OSV.Query(ctx, ecosystem, pkg, version)
			if err != nil {
				return nil, &ToolError{Code: "osv_query_failed",
					Message: "OSV query failed", Cause: err}
			}

			if in.MinSeverity != "" {
				min := osv.SeverityRank(osv.Severity(strings.ToUpper(in.MinSeverity)))
				if min == 0 && strings.ToUpper(in.MinSeverity) != "UNKNOWN" {
					return nil, &ToolError{Code: "invalid_input",
						Message: "min_severity must be one of LOW/MEDIUM/HIGH/CRITICAL"}
				}
				filtered := vulns[:0]
				for _, v := range vulns {
					if osv.SeverityRank(v.Severity) >= min {
						filtered = append(filtered, v)
					}
				}
				vulns = filtered
			}

			// Count by severity for the summary
			countBy := map[string]int{}
			for _, v := range vulns {
				countBy[string(v.Severity)]++
			}

			return map[string]any{
				"package":       pkg,
				"ecosystem":     ecosystem,
				"version":       version,
				"resolved_from": resolvedFrom,
				"total":         len(vulns),
				"by_severity":   countBy,
				"vulns":         vulns,
				"queried_at":    d.Now().Format(time.RFC3339),
			}, nil
		},
	}
}

func buildScorecardTool(d Deps) *Tool {
	return &Tool{
		Name: "yagura_scorecard",
		Description: "[S] OpenSSF Scorecard fetch. priority_only=top 7 checks.",
		InputSchema: map[string]any{
			"type": "object",
			"properties": map[string]any{
				"slug":          map[string]any{"type": "string"},
				"repo":          map[string]any{"type": "string", "description": "owner/repo 形式"},
				"priority_only": map[string]any{"type": "boolean", "description": "重要 7 check に絞る"},
			},
		},
		Handler: func(ctx context.Context, args json.RawMessage) (any, error) {
			if d.Scorecard == nil {
				return nil, &ToolError{Code: "unavailable",
					Message: "scorecard client not configured at startup"}
			}
			var in struct {
				Slug         string `json:"slug"`
				Repo         string `json:"repo"`
				PriorityOnly bool   `json:"priority_only"`
			}
			if err := json.Unmarshal(args, &in); err != nil {
				return nil, &ToolError{Code: "invalid_input", Message: "invalid args", Cause: err}
			}

			repo := strings.TrimSpace(in.Repo)
			var resolvedFrom string
			if in.Slug != "" {
				p, err := d.Registry.Get(in.Slug)
				if err != nil {
					return nil, &ToolError{Code: "not_found",
						Message: "project not found: " + in.Slug}
				}
				if repo == "" {
					repo = p.Repository
				}
				resolvedFrom = in.Slug
			}
			if repo == "" {
				return nil, &ToolError{Code: "invalid_input",
					Message: "repo is required (either via slug or directly)"}
			}

			score, err := d.Scorecard.Fetch(ctx, repo)
			if err != nil {
				if errors.Is(err, scorecard.ErrNotScored) {
					return nil, &ToolError{Code: "not_scored",
						Message: "Scorecard has not yet analyzed this repo. " +
							"Run scorecard.yml workflow once to bootstrap."}
				}
				return nil, &ToolError{Code: "scorecard_fetch_failed",
					Message: "scorecard API call failed", Cause: err}
			}

			checks := score.Checks
			if in.PriorityOnly {
				priority := make(map[string]bool, 7)
				for _, name := range scorecard.PriorityChecks() {
					priority[name] = true
				}
				filtered := checks[:0]
				for _, c := range checks {
					if priority[c.Name] {
						filtered = append(filtered, c)
					}
				}
				checks = filtered
			}

			return map[string]any{
				"repo":            score.Repo,
				"commit":          score.Commit,
				"score":           score.Score,
				"category":        scorecard.HealthCategory(score.Score),
				"analyzed_at":     score.Date.Format("2006-01-02"),
				"scorecard_version": score.ScorecardVersion,
				"resolved_from":   resolvedFrom,
				"checks":          checks,
				"check_count":     len(checks),
			}, nil
		},
	}
}

func buildHealthTool(d Deps) *Tool {
	return &Tool{
		Name: "yagura_health",
		Description: "[S] Security summary: vuln + Scorecard issues. Cached.",
		InputSchema: map[string]any{
			"type": "object",
			"properties": map[string]any{
				"slug":       map[string]any{"type": "string"},
				"individual": map[string]any{"type": "boolean"},
			},
		},
		Handler: func(ctx context.Context, args json.RawMessage) (any, error) {
			var in struct {
				Slug       string `json:"slug"`
				Individual bool   `json:"individual"`
			}
			if err := json.Unmarshal(args, &in); err != nil {
				return nil, &ToolError{Code: "invalid_input", Message: "invalid args", Cause: err}
			}

			// 個別モード
			if in.Individual {
				if in.Slug == "" {
					return nil, &ToolError{Code: "invalid_input",
						Message: "slug is required when individual=true"}
				}
				p, err := d.Registry.Get(in.Slug)
				if err != nil {
					return nil, &ToolError{Code: "not_found",
						Message: "project not found: " + in.Slug}
				}
				return projectHealthSummary(p), nil
			}

			// 全体モード
			projects := d.Registry.List()
			var (
				totalScored, totalScannedForVulns int
				scoreSum                          float64
				totalCritical, totalHigh          int
				totalMedium, totalLow             int
				needsAttention                    []map[string]any
				notYetScanned                     int
			)

			for _, p := range projects {
				if p.Stage == project.StageArchived {
					continue
				}
				if !p.ScorecardAt.IsZero() {
					totalScored++
					scoreSum += p.ScorecardScore
				}
				if !p.VulnScanAt.IsZero() {
					totalScannedForVulns++
				}
				totalCritical += p.VulnCritical
				totalHigh += p.VulnHigh
				totalMedium += p.VulnMedium
				totalLow += p.VulnLow
				if p.ScorecardAt.IsZero() && p.VulnScanAt.IsZero() {
					notYetScanned++
				}
				if p.HasCriticalSecurityIssue() {
					needsAttention = append(needsAttention, map[string]any{
						"slug":            p.Slug,
						"repository":      p.Repository,
						"scorecard_score": p.ScorecardScore,
						"vuln_critical":   p.VulnCritical,
						"vuln_high":       p.VulnHigh,
					})
				}
			}

			var avgScore float64
			if totalScored > 0 {
				avgScore = scoreSum / float64(totalScored)
			}

			return map[string]any{
				"as_of":             d.Now().Format(time.RFC3339),
				"total_active":      len(projects), // archived 除く参考値
				"scorecard_scanned": totalScored,
				"vulns_scanned":     totalScannedForVulns,
				"not_yet_scanned":   notYetScanned,
				"avg_scorecard":     avgScore,
				"total_vulns": map[string]int{
					"critical": totalCritical,
					"high":     totalHigh,
					"medium":   totalMedium,
					"low":      totalLow,
				},
				"needs_attention":      needsAttention,
				"needs_attention_count": len(needsAttention),
			}, nil
		},
	}
}

func projectHealthSummary(p *project.Project) map[string]any {
	scoreCat := ""
	if !p.ScorecardAt.IsZero() {
		switch {
		case p.ScorecardScore >= 8.0:
			scoreCat = "excellent"
		case p.ScorecardScore >= 6.0:
			scoreCat = "good"
		case p.ScorecardScore >= 4.0:
			scoreCat = "fair"
		default:
			scoreCat = "poor"
		}
	}
	scorecardAt := ""
	if !p.ScorecardAt.IsZero() {
		scorecardAt = p.ScorecardAt.Format(time.RFC3339)
	}
	vulnScanAt := ""
	if !p.VulnScanAt.IsZero() {
		vulnScanAt = p.VulnScanAt.Format(time.RFC3339)
	}
	return map[string]any{
		"slug":              p.Slug,
		"repository":        p.Repository,
		"scorecard_score":   p.ScorecardScore,
		"scorecard_category": scoreCat,
		"scorecard_at":      scorecardAt,
		"vuln_critical":     p.VulnCritical,
		"vuln_high":         p.VulnHigh,
		"vuln_medium":       p.VulnMedium,
		"vuln_low":          p.VulnLow,
		"vuln_total":        p.TotalVulns(),
		"vuln_scan_at":      vulnScanAt,
		"needs_attention":   p.HasCriticalSecurityIssue(),
	}
}
