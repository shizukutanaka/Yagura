package mcp

import (
	"context"
	"encoding/json"
	"testing"
)

func TestSessionSummaryTool(t *testing.T) {
	tool := buildSessionSummaryTool(Deps{})
	// raw events from mixed agents (Claude Code hook + generic), normalized then summarized
	out, err := tool.Handler(context.Background(), json.RawMessage(`{"events":[
		{"hook_event_name":"PreToolUse","tool_name":"Bash","session_id":"s"},
		{"hook_event_name":"PostToolUse","tool_name":"Bash","session_id":"s"},
		{"agent":"gemini_cli","event":"beforeToolCall","tool":"Read"},
		{"agent":"gemini_cli","event":"toolError","tool":"Read","error":{"type":"timeout"}}
	]}`))
	if err != nil {
		t.Fatalf("handler error: %v", err)
	}
	b, _ := json.Marshal(out)
	var r struct {
		Events          int            `json:"events"`
		ToolInvocations int            `json:"tool_invocations"`
		ByTool          map[string]int `json:"by_tool"`
		Errors          []struct {
			Tool string `json:"tool"`
		} `json:"errors"`
		Agents []string `json:"agents"`
	}
	if err := json.Unmarshal(b, &r); err != nil {
		t.Fatal(err)
	}
	if r.Events != 4 || r.ToolInvocations != 2 {
		t.Errorf("events/invocations: %d/%d (%s)", r.Events, r.ToolInvocations, b)
	}
	if r.ByTool["Bash"] != 1 || r.ByTool["Read"] != 1 {
		t.Errorf("by_tool: %+v", r.ByTool)
	}
	if len(r.Errors) != 1 || r.Errors[0].Tool != "Read" {
		t.Errorf("errors: %+v", r.Errors)
	}
	if len(r.Agents) != 2 {
		t.Errorf("expected 2 agents, got %+v", r.Agents)
	}
}

func TestSessionSummaryTool_EmptyEvents(t *testing.T) {
	tool := buildSessionSummaryTool(Deps{})
	if _, err := tool.Handler(context.Background(), json.RawMessage(`{"events":[]}`)); err == nil {
		t.Error("expected error for empty events")
	}
}

func TestSessionSummaryTool_BadInput(t *testing.T) {
	tool := buildSessionSummaryTool(Deps{})
	if _, err := tool.Handler(context.Background(), json.RawMessage(`{`)); err == nil {
		t.Error("expected error for malformed JSON")
	}
}
