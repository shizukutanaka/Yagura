package mcp

import (
	"context"
	"encoding/json"
	"testing"

	"github.com/shizukutanaka/yagura/internal/harness"
)

// ─── yagura_skill_audit ──────────────────────────────────────

func TestSkillAudit_InvalidInputs(t *testing.T) {
	tool := buildSkillAuditTool(newDeps(t))
	for name, args := range map[string]string{
		"bad json":      `{`,
		"empty content": `{"content":""}`,
		"missing field": `{}`,
	} {
		t.Run(name, func(t *testing.T) {
			if _, err := tool.Handler(context.Background(), json.RawMessage(args)); !IsCode(err, "invalid_input") {
				t.Errorf("expected invalid_input, got %v", err)
			}
		})
	}
}

func TestSkillAudit_WellFormedScoresHigh(t *testing.T) {
	tool := buildSkillAuditTool(newDeps(t))
	content := "---\nname: my-skill\ndescription: Use when the user asks to audit a thing.\n---\n" +
		"# My Skill\n\nDoes the audit.\n\n## Gotchas\n\n- watch out for X\n"
	res := mustCall(t, tool, map[string]any{"content": content}).(harness.SkillAuditResult)
	if !res.HasFrontmatter {
		t.Error("expected frontmatter detected")
	}
	if !res.IsTriggerFormat {
		t.Error("expected trigger-format description detected")
	}
	if res.RetireRecommended {
		t.Errorf("well-formed skill should not be retire-recommended (score=%d)", res.Score)
	}
}

func TestSkillAudit_StubIsRetireRecommended(t *testing.T) {
	tool := buildSkillAuditTool(newDeps(t))
	// No frontmatter, no routing description, near-empty body → stub retire path
	// (fires regardless of the numeric score).
	res := mustCall(t, tool, map[string]any{"content": "just a sentence"}).(harness.SkillAuditResult)
	if res.DescriptionLen != 0 {
		t.Errorf("expected no description, got len %d", res.DescriptionLen)
	}
	if !res.RetireRecommended {
		t.Errorf("stub skill should be retire-recommended, got %+v", res)
	}
	if res.RetireReason == "" {
		t.Error("retire-recommended result must carry a reason")
	}
}

// ─── yagura_subagent_audit ───────────────────────────────────

func TestSubagentAudit_InvalidInputs(t *testing.T) {
	tool := buildSubagentAuditTool(newDeps(t))
	for name, args := range map[string]string{
		"bad json":      `{`,
		"empty content": `{"content":""}`,
	} {
		t.Run(name, func(t *testing.T) {
			if _, err := tool.Handler(context.Background(), json.RawMessage(args)); !IsCode(err, "invalid_input") {
				t.Errorf("expected invalid_input, got %v", err)
			}
		})
	}
}

func TestSubagentAudit_HappyPath(t *testing.T) {
	tool := buildSubagentAuditTool(newDeps(t))
	content := "---\nname: reviewer\ndescription: Use when reviewing a diff for correctness.\n---\n" +
		"You are a careful code reviewer. Inspect the diff and report bugs.\n"
	res := mustCall(t, tool, map[string]any{"content": content}).(harness.SubagentAuditResult)
	if !res.HasFrontmatter {
		t.Error("expected frontmatter detected for well-formed subagent")
	}
	if res.Score <= 0 {
		t.Errorf("well-formed subagent should score > 0, got %d", res.Score)
	}
}
