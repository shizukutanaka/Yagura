// tools_sessionsummary.go: yagura_session_summary — エージェントのイベント列を
// セッション活動の構造化サマリへ集約する(internal/sessionsummary)。
//
// 着想(Hermes Desktop 参照): Hermes Desktop の目玉「ライブ tool activity と構造化 tool-call
// サマリ」の kernel 側 deterministic 版。raw イベント列を agentevent.Normalize で正規化してから
// Summarize するので、Claude Code / Gemini CLI / Codex / OTel いずれのセッションでも同じサマリが
// 得られる。UI(Hermes 風でも Yagura dashboard でも)はこれを render するだけ。LLM 不使用。

package mcp

import (
	"context"
	"encoding/json"

	"github.com/shizukutanaka/yagura/internal/agentevent"
	"github.com/shizukutanaka/yagura/internal/sessionsummary"
)

func buildSessionSummaryTool(d Deps) *Tool {
	return &Tool{
		Name:        "yagura_session_summary",
		Description: "[S] Structured tool-call summary of an agent session (any agent): counts/sequence/errors/anomalies.",
		InputSchema: map[string]any{
			"type": "object",
			"properties": map[string]any{
				"events": map[string]any{
					"type":        "array",
					"description": "chronological raw lifecycle events from any agent (each normalized via agent_event).",
					"items":       map[string]any{"type": "object"},
				},
			},
			"required": []string{"events"},
		},
		Handler: func(ctx context.Context, args json.RawMessage) (any, error) {
			var in struct {
				Events []map[string]any `json:"events"`
			}
			if err := json.Unmarshal(args, &in); err != nil {
				return nil, &ToolError{Code: "invalid_input", Cause: err}
			}
			if len(in.Events) == 0 {
				return nil, &ToolError{Code: "invalid_input", Message: "events must list at least one event"}
			}
			norm := make([]agentevent.Event, 0, len(in.Events))
			for _, raw := range in.Events {
				norm = append(norm, agentevent.Normalize(raw))
			}
			return sessionsummary.Summarize(norm), nil
		},
	}
}
