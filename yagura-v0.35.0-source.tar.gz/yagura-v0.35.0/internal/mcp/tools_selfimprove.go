// tools_selfimprove.go: yagura_self_improve — harness レベルの再帰的自己改善(RSI)を
// 安全な形で回すための決定論的カーネル(internal/selfimprove)。
//
// STOP(arXiv 2310.02304)が示すとおり、モデルを固定したまま最適化できるのは
// 「足場(harness)」であり、Yagura はその harness。本 tool は harness 自身の観測値
// (yagura_token_stats / yagura_skill_audit / yagura_harness_coverage 由来)を受け、
// 優先度つきの改善提案を rule-based に返す。前回窓(prev_tools)を渡すと、
// Darwin Gödel Machine(arXiv 2505.22954)流に「後退」を検出して採用/巻き戻しを助言する
// (盲目採用を避け、misevolution = arXiv 2509.26354 を防ぐ)。
//
// Yagura は自分のコードを書き換えない(ADR-0001 / 安全性)。判断は決定論的で audit 可能、
// 実行は人間/エージェント側。parallel_plan(1→N)・recovery_decide(失敗時)と並ぶ
// control-plane の一部。

package mcp

import (
	"context"
	"encoding/json"

	"github.com/shizukutanaka/yagura/internal/selfimprove"
)

func buildSelfImproveTool(d Deps) *Tool {
	return &Tool{
		Name:        "yagura_self_improve",
		Description: "[S] Turn harness self-metrics into ranked, gated improvement proposals (RSI, deterministic).",
		InputSchema: map[string]any{
			"type": "object",
			"properties": map[string]any{
				"tools": map[string]any{
					"type":        "array",
					"description": "observed per-tool stats (from yagura_token_stats): [{name, calls, errors, avg_resp_bytes}].",
					"items": map[string]any{
						"type": "object",
						"properties": map[string]any{
							"name":           map[string]any{"type": "string"},
							"calls":          map[string]any{"type": "integer"},
							"errors":         map[string]any{"type": "integer"},
							"avg_resp_bytes": map[string]any{"type": "integer"},
						},
						"required": []string{"name"},
					},
				},
				"prev_tools": map[string]any{
					"type":        "array",
					"description": "previous window's tool stats; enables fitness/regression detection (revert advice).",
					"items":       map[string]any{"type": "object"},
				},
				"skills": map[string]any{
					"type":        "array",
					"description": "skill audit results (from yagura_skill_audit): [{path, score, retire}].",
					"items":       map[string]any{"type": "object"},
				},
				"coverage_gaps": map[string]any{
					"type":        "array",
					"description": "Fowler matrix quadrants with no control (from yagura_harness_coverage).",
					"items":       map[string]any{"type": "string"},
				},
				"session_calls": map[string]any{
					"type":        "integer",
					"description": "total tool calls in the window (used for token-economy call-share thresholds).",
				},
			},
		},
		Handler: func(ctx context.Context, args json.RawMessage) (any, error) {
			var snap selfimprove.Snapshot
			if len(args) > 0 {
				if err := json.Unmarshal(args, &snap); err != nil {
					return nil, &ToolError{Code: "invalid_input", Cause: err}
				}
			}
			return selfimprove.Analyze(snap), nil
		},
	}
}
