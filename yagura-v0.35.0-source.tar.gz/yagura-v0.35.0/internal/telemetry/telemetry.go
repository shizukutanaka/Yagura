// Package telemetry は OpenTelemetry 互換の分散トレース hook を提供する。
//
// 設計判断:
//   - ADR-0001 (ゼロ依存) を守るため、本パッケージ自体は go.opentelemetry.io には依存しない
//   - 代わりに OTel 互換のミニマル interface を提供し、呼出側 (将来のプラグイン) で
//     実装する余地を残す
//   - デフォルト実装は no-op (本番デフォルト)。OTel SDK を埋め込みたい使用者は
//     Tracer interface を実装した自作 wrapper を渡せばよい
//
// OTel Trace API との互換性:
//   - StartSpan / End / SetAttributes は OpenTelemetry v1.0 trace API
//     (https://opentelemetry.io/docs/specs/otel/trace/api/) に sub-set 準拠
//   - 将来 go.opentelemetry.io/otel/trace に置き換えた場合の breaking change を最小化
package telemetry

import (
	"context"
	"sync"
	"time"
)

// Tracer は span を開始するファクトリ。
//
// HTTP / scanner / MCP tool ハンドラの critical path で hook を仕込む想定。
// no-op 実装はゼロアロケーション、ホットパスに置いても overhead がない。
type Tracer interface {
	// StartSpan は新しい span を開始する。返却された context は子 span 作成に使う。
	// 呼出側は Span.End() を必ず deferで呼ぶこと。
	StartSpan(ctx context.Context, name string, opts ...SpanOption) (context.Context, Span)
}

// Span は 1 つのトレース span。
type Span interface {
	// End は span を終了する。冪等(複数回呼んでも問題ない)。
	End(opts ...EndOption)
	// SetAttributes は span に key-value 属性を追加する。
	SetAttributes(attrs ...Attribute)
	// SetStatus は span のステータスを設定する。
	SetStatus(code StatusCode, description string)
	// RecordError は span にエラーイベントを記録する。
	RecordError(err error)
}

// Attribute は span の属性 (key-value pair)。
type Attribute struct {
	Key   string
	Value any // string / int64 / float64 / bool が標準
}

// String は string 属性を作る。
func String(k, v string) Attribute { return Attribute{Key: k, Value: v} }

// Int は int 属性を作る。
func Int(k string, v int) Attribute { return Attribute{Key: k, Value: int64(v)} }

// Int64 は int64 属性を作る。
func Int64(k string, v int64) Attribute { return Attribute{Key: k, Value: v} }

// Float64 は float64 属性を作る。
func Float64(k string, v float64) Attribute { return Attribute{Key: k, Value: v} }

// Bool は bool 属性を作る。
func Bool(k string, v bool) Attribute { return Attribute{Key: k, Value: v} }

// StatusCode は span のステータスコード。OTel v1.0 と互換。
type StatusCode int

const (
	// StatusUnset はステータス未設定の状態(デフォルト)。
	StatusUnset StatusCode = iota
	// StatusOK は span が正常終了したことを示す。
	StatusOK
	// StatusError は span がエラーで終了したことを示す。
	StatusError
)

// SpanKind は span の役割。OTel SpanKind との互換。
type SpanKind int

const (
	// SpanKindInternal は内部処理を表す span。
	SpanKindInternal SpanKind = iota
	// SpanKindServer はサーバー側で受信した RPC/HTTP リクエストの span。
	SpanKindServer
	// SpanKindClient はクライアントが外部サービスへ送信するリクエストの span。
	SpanKindClient
	// SpanKindProducer はメッセージキューへのメッセージ送信の span。
	SpanKindProducer
	// SpanKindConsumer はメッセージキューからのメッセージ受信の span。
	SpanKindConsumer
)

// SpanOption は StartSpan のオプション。
type SpanOption func(*spanConfig)

// spanConfig は内部設定保持構造体。
type spanConfig struct {
	kind       SpanKind
	attributes []Attribute
	startTime  time.Time
}

// WithSpanKind は span kind を指定する。
func WithSpanKind(k SpanKind) SpanOption {
	return func(c *spanConfig) { c.kind = k }
}

// WithAttributes は span 開始時に属性を設定する。
func WithAttributes(attrs ...Attribute) SpanOption {
	return func(c *spanConfig) { c.attributes = append(c.attributes, attrs...) }
}

// WithStartTime は span の開始時刻を上書きする(過去イベントの遡及記録用)。
func WithStartTime(t time.Time) SpanOption {
	return func(c *spanConfig) { c.startTime = t }
}

// EndOption は End のオプション。
type EndOption func(*endConfig)

// endConfig は End の内部設定。
type endConfig struct {
	endTime time.Time
}

// WithEndTime は span の終了時刻を上書きする。
func WithEndTime(t time.Time) EndOption {
	return func(c *endConfig) { c.endTime = t }
}

// ─── no-op default implementation ────────────────────────────

// noopTracer は何もしない Tracer。本番デフォルトとして提供される。
// ホットパスに置いてもオーバーヘッドゼロ(返却型は値渡し、メソッドは empty body)。
type noopTracer struct{}

// NewNoopTracer は何もしない Tracer を返す。
//
// 用途:
//   - 本番デフォルト
//   - テストでトレース hook を確認しない場合
//   - OTel SDK を組み込まない環境
func NewNoopTracer() Tracer { return noopTracer{} }

func (noopTracer) StartSpan(ctx context.Context, _ string, _ ...SpanOption) (context.Context, Span) {
	return ctx, noopSpan{}
}

type noopSpan struct{}

func (noopSpan) End(_ ...EndOption)                     {}
func (noopSpan) SetAttributes(_ ...Attribute)           {}
func (noopSpan) SetStatus(_ StatusCode, _ string)       {}
func (noopSpan) RecordError(_ error)                    {}

// ─── recording implementation (testing-friendly) ─────────────

// RecordingTracer は memory に span を記録する Tracer。
//
// 用途:
//   - 単体テストでトレース hook が正しく呼ばれるか検証
//   - 開発時のローカルデバッグ(完了した span を直接 inspect)
//   - 将来の OTel SDK 実装の参考実装
//
// 本番では NewNoopTracer を使う(メモリリーク防止)。
type RecordingTracer struct {
	mu    sync.Mutex
	spans []*RecordedSpan
}

// RecordedSpan は記録された span。
type RecordedSpan struct {
	Name        string
	Kind        SpanKind
	StartTime   time.Time
	EndTime     time.Time
	Attributes  []Attribute
	Status      StatusCode
	StatusDesc  string
	Errors      []error
}

// NewRecordingTracer は新しい RecordingTracer を返す。
func NewRecordingTracer() *RecordingTracer {
	return &RecordingTracer{}
}

// StartSpan は span を開始して RecordedSpan に記録を開始する。
func (r *RecordingTracer) StartSpan(ctx context.Context, name string, opts ...SpanOption) (context.Context, Span) {
	cfg := spanConfig{startTime: time.Now()}
	for _, o := range opts {
		o(&cfg)
	}
	rs := &RecordedSpan{
		Name:       name,
		Kind:       cfg.kind,
		StartTime:  cfg.startTime,
		Attributes: append([]Attribute(nil), cfg.attributes...),
	}
	r.mu.Lock()
	r.spans = append(r.spans, rs)
	r.mu.Unlock()
	return ctx, &recordingSpan{rs: rs}
}

// Spans は記録された全 span を返す(検証用)。
func (r *RecordingTracer) Spans() []*RecordedSpan {
	r.mu.Lock()
	defer r.mu.Unlock()
	out := make([]*RecordedSpan, len(r.spans))
	copy(out, r.spans)
	return out
}

// Reset は記録をクリアする。
func (r *RecordingTracer) Reset() { r.spans = nil }

type recordingSpan struct {
	rs *RecordedSpan
}

func (s *recordingSpan) End(opts ...EndOption) {
	cfg := endConfig{endTime: time.Now()}
	for _, o := range opts {
		o(&cfg)
	}
	if s.rs.EndTime.IsZero() { // 冪等
		s.rs.EndTime = cfg.endTime
	}
}

func (s *recordingSpan) SetAttributes(attrs ...Attribute) {
	s.rs.Attributes = append(s.rs.Attributes, attrs...)
}

func (s *recordingSpan) SetStatus(code StatusCode, desc string) {
	s.rs.Status = code
	s.rs.StatusDesc = desc
}

func (s *recordingSpan) RecordError(err error) {
	if err != nil {
		s.rs.Errors = append(s.rs.Errors, err)
	}
}
