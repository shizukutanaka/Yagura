// Package dedupe は content-addressed cache + tool result cache を提供する。
//
// 動機 (v0.23.0):
//   AI agent (Claude Code 等) が短期間に同じ tool を同じ引数で呼ぶ、
//   または同じ source content を scan する重複が観察される。
//   cortex (aircloset 2026/05) でも "AI が迷う頻度を構造的に減らす" として
//   Product Graph で同じ問いを 1 回で答える設計を採用している。
//
//   yagura はもう一歩踏み込んで、tool 呼出 + content scan の deterministic な
//   結果を content hash でキャッシュし、重複呼出を即時に応答する。
//
// 設計判断 (ADR-0001 ゼロ依存準拠):
//   - sync.Map ではなく explicit lock の RWMutex map[string]*entry
//   - SHA-256 で content addressing(stdlib のみ)
//   - LRU eviction(linked list + map で O(1) update)
//   - TTL: 各 entry に CreatedAt、Stats() で expired もカウント
//   - thread-safe: 全 public method は lock 取得
//
// 性能特性:
//   - Get: O(1) hash lookup + O(1) LRU update
//   - Set: O(1) insert + O(1) LRU update + 必要なら 1 eviction
//   - Stats: O(1) atomic load
package dedupe

import (
	"container/list"
	"crypto/sha256"
	"encoding/hex"
	"sync"
	"sync/atomic"
	"time"
)

// DefaultMaxEntries は cache が保持する最大 entry 数。
// 超えると LRU で evict。
const DefaultMaxEntries = 256

// DefaultTTL は entry の expiration window。
// この時間を超えた entry は Get で miss として扱われ、次の Set で上書きされる。
const DefaultTTL = 1 * time.Hour

// Cache は thread-safe な content-addressed cache。
type Cache struct {
	mu      sync.Mutex // RW lock より単純な Mutex(LRU update が write を含むため)
	max     int
	ttl     time.Duration
	entries map[string]*list.Element // key → list element
	lru     *list.List               // front = most recent

	// stats (atomic for lock-free read in Stats())
	hits        uint64
	misses      uint64
	evictions   uint64
	expirations uint64
	bytesSaved  uint64 // hit の累積で「もしキャッシュなければ生成されたであろう byte 数」

	// NowFn はテスト用時刻 hook。
	NowFn func() time.Time
}

type entry struct {
	key       string
	value     []byte
	createdAt time.Time
}

// New は cache を生成する。
// maxEntries=0 で DefaultMaxEntries 採用、ttl=0 で DefaultTTL 採用。
func New(maxEntries int, ttl time.Duration) *Cache {
	if maxEntries <= 0 {
		maxEntries = DefaultMaxEntries
	}
	if ttl <= 0 {
		ttl = DefaultTTL
	}
	return &Cache{
		max:     maxEntries,
		ttl:     ttl,
		entries: make(map[string]*list.Element, maxEntries),
		lru:     list.New(),
	}
}

func (c *Cache) now() time.Time {
	if c.NowFn != nil {
		return c.NowFn()
	}
	return time.Now()
}

// Key は引数群から決定論的な cache key を生成する。
//
// usage:
//
//	key := dedupe.Key("quality_check", string(contentHash))
//	key := dedupe.Key("vulns", "shizukutanaka/breeze")
func Key(parts ...string) string {
	h := sha256.New()
	for _, p := range parts {
		h.Write([]byte(p))
		h.Write([]byte{0}) // null separator で衝突防止
	}
	return hex.EncodeToString(h.Sum(nil))
}

// HashBytes は content の SHA-256 を hex 文字列で返す。
//
// quality_check 等で source content をキーにする用途。
func HashBytes(b []byte) string {
	h := sha256.Sum256(b)
	return hex.EncodeToString(h[:])
}

// Get は cache hit なら value と true、miss なら nil と false を返す。
//
// hit 時に LRU を更新(front に移動)、TTL 超過の entry は miss 扱い + 削除。
func (c *Cache) Get(key string) ([]byte, bool) {
	c.mu.Lock()
	defer c.mu.Unlock()
	elem, ok := c.entries[key]
	if !ok {
		atomic.AddUint64(&c.misses, 1)
		return nil, false
	}
	e := elem.Value.(*entry)
	if c.now().Sub(e.createdAt) > c.ttl {
		// expired
		c.lru.Remove(elem)
		delete(c.entries, key)
		atomic.AddUint64(&c.expirations, 1)
		atomic.AddUint64(&c.misses, 1)
		return nil, false
	}
	// LRU 更新
	c.lru.MoveToFront(elem)
	atomic.AddUint64(&c.hits, 1)
	atomic.AddUint64(&c.bytesSaved, uint64(len(e.value)))
	// caller が改変しないよう copy を返す
	out := make([]byte, len(e.value))
	copy(out, e.value)
	return out, true
}

// Set は entry を追加または更新する。
//
// max を超えた場合は LRU の末尾を evict する。
func (c *Cache) Set(key string, value []byte) {
	c.mu.Lock()
	defer c.mu.Unlock()
	now := c.now()
	if elem, ok := c.entries[key]; ok {
		// 既存 entry を更新
		e := elem.Value.(*entry)
		e.value = append(e.value[:0], value...)
		e.createdAt = now
		c.lru.MoveToFront(elem)
		return
	}
	// 容量超過なら evict
	for c.lru.Len() >= c.max {
		oldest := c.lru.Back()
		if oldest == nil {
			break
		}
		oldEntry := oldest.Value.(*entry)
		c.lru.Remove(oldest)
		delete(c.entries, oldEntry.key)
		atomic.AddUint64(&c.evictions, 1)
	}
	// 追加
	val := make([]byte, len(value))
	copy(val, value)
	e := &entry{key: key, value: val, createdAt: now}
	elem := c.lru.PushFront(e)
	c.entries[key] = elem
}

// Delete は key を削除する。存在しない場合は no-op。
func (c *Cache) Delete(key string) {
	c.mu.Lock()
	defer c.mu.Unlock()
	if elem, ok := c.entries[key]; ok {
		c.lru.Remove(elem)
		delete(c.entries, key)
	}
}

// Len は現在の entry 数を返す。
func (c *Cache) Len() int {
	c.mu.Lock()
	defer c.mu.Unlock()
	return c.lru.Len()
}

// Stats は累積統計を返す。
type Stats struct {
	Hits        uint64  `json:"hits"`
	Misses      uint64  `json:"misses"`
	Evictions   uint64  `json:"evictions"`
	Expirations uint64  `json:"expirations"`
	BytesSaved  uint64  `json:"bytes_saved"`  // hit で返した cumulative bytes(節約推定)
	HitRate     float64 `json:"hit_rate"`     // hits / (hits + misses)
	CurrentSize int     `json:"current_size"`
	MaxSize     int     `json:"max_size"`
	TTLSeconds  int64   `json:"ttl_seconds"`
}

// Stats は atomic load で snapshot を返す。
func (c *Cache) Stats() Stats {
	c.mu.Lock()
	size := c.lru.Len()
	maxv := c.max
	ttlSec := int64(c.ttl.Seconds())
	c.mu.Unlock()

	h := atomic.LoadUint64(&c.hits)
	m := atomic.LoadUint64(&c.misses)
	var rate float64
	if h+m > 0 {
		rate = float64(h) / float64(h+m)
	}
	return Stats{
		Hits:        h,
		Misses:      m,
		Evictions:   atomic.LoadUint64(&c.evictions),
		Expirations: atomic.LoadUint64(&c.expirations),
		BytesSaved:  atomic.LoadUint64(&c.bytesSaved),
		HitRate:     rate,
		CurrentSize: size,
		MaxSize:     maxv,
		TTLSeconds:  ttlSec,
	}
}

// Reset は entry と stats を全クリア(test 用)。
func (c *Cache) Reset() {
	c.mu.Lock()
	c.entries = make(map[string]*list.Element, c.max)
	c.lru.Init()
	c.mu.Unlock()
	atomic.StoreUint64(&c.hits, 0)
	atomic.StoreUint64(&c.misses, 0)
	atomic.StoreUint64(&c.evictions, 0)
	atomic.StoreUint64(&c.expirations, 0)
	atomic.StoreUint64(&c.bytesSaved, 0)
}
