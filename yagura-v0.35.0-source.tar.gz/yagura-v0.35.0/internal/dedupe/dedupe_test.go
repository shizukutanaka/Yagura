package dedupe

import (
	"fmt"
	"sync"
	"testing"
	"time"
)

// ─── 基本動作 ─────────────────────────────────────────────

func TestCache_SetGet_Basic(t *testing.T) {
	c := New(10, time.Minute)
	c.Set("k1", []byte("v1"))
	v, ok := c.Get("k1")
	if !ok {
		t.Fatal("Get should hit after Set")
	}
	if string(v) != "v1" {
		t.Errorf("got %q, want v1", v)
	}
}

func TestCache_Miss(t *testing.T) {
	c := New(10, time.Minute)
	_, ok := c.Get("never-set")
	if ok {
		t.Error("Get should miss for unset key")
	}
	s := c.Stats()
	if s.Misses != 1 {
		t.Errorf("expected 1 miss, got %d", s.Misses)
	}
}

func TestCache_GetReturnsCopy(t *testing.T) {
	c := New(10, time.Minute)
	original := []byte("hello")
	c.Set("k", original)

	got, _ := c.Get("k")
	got[0] = 'H' // 改変
	got2, _ := c.Get("k")
	if string(got2) != "hello" {
		t.Errorf("cache should return defensive copy; got %q", got2)
	}
}

// ─── LRU eviction ─────────────────────────────────────────

func TestCache_EvictsOldestWhenFull(t *testing.T) {
	c := New(3, time.Minute)
	c.Set("a", []byte("1"))
	c.Set("b", []byte("2"))
	c.Set("c", []byte("3"))
	c.Set("d", []byte("4")) // a が evict されるはず

	if _, ok := c.Get("a"); ok {
		t.Error("a should be evicted")
	}
	for _, k := range []string{"b", "c", "d"} {
		if _, ok := c.Get(k); !ok {
			t.Errorf("%s should remain", k)
		}
	}
	if c.Stats().Evictions == 0 {
		t.Error("evictions counter should be > 0")
	}
}

func TestCache_LRURecentlyUsedSurvives(t *testing.T) {
	c := New(3, time.Minute)
	c.Set("a", []byte("1"))
	c.Set("b", []byte("2"))
	c.Set("c", []byte("3"))

	_, _ = c.Get("a") // a を front に移動
	c.Set("d", []byte("4")) // b が evict されるはず(LRU)

	if _, ok := c.Get("a"); !ok {
		t.Error("a should survive (recently used)")
	}
	if _, ok := c.Get("b"); ok {
		t.Error("b should be evicted (least recently used)")
	}
}

// ─── TTL expiration ─────────────────────────────────────

func TestCache_ExpiredEntryMisses(t *testing.T) {
	c := New(10, 100*time.Millisecond)
	now := time.Date(2026, 5, 13, 12, 0, 0, 0, time.UTC)
	c.NowFn = func() time.Time { return now }
	c.Set("k", []byte("v"))

	// TTL 内
	if _, ok := c.Get("k"); !ok {
		t.Error("should hit within TTL")
	}

	// TTL 超過
	c.NowFn = func() time.Time { return now.Add(200 * time.Millisecond) }
	if _, ok := c.Get("k"); ok {
		t.Error("should miss after TTL")
	}
	s := c.Stats()
	if s.Expirations != 1 {
		t.Errorf("expected 1 expiration, got %d", s.Expirations)
	}
}

// ─── 統計 ────────────────────────────────────────────────

func TestStats_HitRate(t *testing.T) {
	c := New(10, time.Minute)
	c.Set("k", []byte("v"))
	c.Get("k")     // hit
	c.Get("k")     // hit
	c.Get("miss1") // miss
	c.Get("miss2") // miss

	s := c.Stats()
	if s.Hits != 2 || s.Misses != 2 {
		t.Errorf("hits=%d misses=%d, want 2/2", s.Hits, s.Misses)
	}
	if s.HitRate != 0.5 {
		t.Errorf("hit_rate: got %v, want 0.5", s.HitRate)
	}
}

func TestStats_BytesSavedAccumulates(t *testing.T) {
	c := New(10, time.Minute)
	c.Set("k", []byte("0123456789")) // 10 bytes
	c.Get("k")                       // +10
	c.Get("k")                       // +10
	c.Get("k")                       // +10
	s := c.Stats()
	if s.BytesSaved != 30 {
		t.Errorf("bytes_saved: got %d, want 30", s.BytesSaved)
	}
}

// ─── Key 生成 ──────────────────────────────────────────

func TestKey_DeterministicAcrossInvocations(t *testing.T) {
	k1 := Key("tool_a", "arg1", "arg2")
	k2 := Key("tool_a", "arg1", "arg2")
	if k1 != k2 {
		t.Errorf("Key should be deterministic: %s != %s", k1, k2)
	}
}

func TestKey_DifferentArgsDifferKeys(t *testing.T) {
	k1 := Key("a", "x", "y")
	k2 := Key("a", "xy", "")
	if k1 == k2 {
		t.Error("Key with different args should produce different hashes (null separator)")
	}
}

func TestHashBytes(t *testing.T) {
	a := HashBytes([]byte("hello"))
	b := HashBytes([]byte("hello"))
	if a != b {
		t.Errorf("same content should hash same: %s != %s", a, b)
	}
	c := HashBytes([]byte("world"))
	if a == c {
		t.Error("different content should differ")
	}
	if len(a) != 64 {
		t.Errorf("SHA-256 hex should be 64 chars, got %d", len(a))
	}
}

// ─── 並行性 ────────────────────────────────────────────

func TestCache_ConcurrentAccess(t *testing.T) {
	c := New(100, time.Minute)
	var wg sync.WaitGroup
	for i := 0; i < 100; i++ {
		wg.Add(1)
		go func(n int) {
			defer wg.Done()
			key := fmt.Sprintf("key-%d", n%10)
			c.Set(key, []byte(fmt.Sprintf("v-%d", n)))
			_, _ = c.Get(key)
		}(i)
	}
	wg.Wait()
	s := c.Stats()
	if s.Hits+s.Misses < 100 {
		t.Errorf("expected at least 100 accesses, got %d", s.Hits+s.Misses)
	}
}

// ─── Delete / Reset ───────────────────────────────────

func TestCache_Delete(t *testing.T) {
	c := New(10, time.Minute)
	c.Set("k", []byte("v"))
	c.Delete("k")
	if _, ok := c.Get("k"); ok {
		t.Error("should miss after Delete")
	}
	// 存在しない key の Delete は no-op
	c.Delete("never-was")
}

func TestCache_Reset(t *testing.T) {
	c := New(10, time.Minute)
	c.Set("k1", []byte("v1"))
	c.Set("k2", []byte("v2"))
	c.Get("k1") // hit
	c.Reset()

	if c.Len() != 0 {
		t.Errorf("Len after Reset: got %d, want 0", c.Len())
	}
	s := c.Stats()
	if s.Hits != 0 || s.Misses != 0 {
		t.Errorf("stats not reset: %+v", s)
	}
}

// ─── 既存 entry update ──────────────────────────────────

func TestCache_UpdateExisting(t *testing.T) {
	c := New(10, time.Minute)
	c.Set("k", []byte("v1"))
	c.Set("k", []byte("v2"))
	if c.Len() != 1 {
		t.Errorf("update should not increase Len: %d", c.Len())
	}
	v, _ := c.Get("k")
	if string(v) != "v2" {
		t.Errorf("update should replace value; got %q", v)
	}
}

// ─── Defaults ────────────────────────────────────────

func TestNew_DefaultsApplied(t *testing.T) {
	c := New(0, 0)
	if c.max != DefaultMaxEntries || c.ttl != DefaultTTL {
		t.Errorf("defaults not applied: max=%d ttl=%v", c.max, c.ttl)
	}
}
