package dashboard

import (
	"strings"
	"testing"
	"time"

	"github.com/shizukutanaka/yagura/internal/project"
	"github.com/shizukutanaka/yagura/internal/registry"
)

type fakeHealth struct {
	hs HealthSummary
	ok bool
}

func (f fakeHealth) PortfolioHealth() (HealthSummary, bool) { return f.hs, f.ok }

func healthDash(t *testing.T) *Handler {
	t.Helper()
	reg, err := registry.New(t.TempDir())
	if err != nil {
		t.Fatal(err)
	}
	_ = reg.Add(&project.Project{Slug: "breeze", DisplayName: "Breeze", Repository: "o/breeze", Stage: project.StageActive})
	h, err := New(reg, nil)
	if err != nil {
		t.Fatal(err)
	}
	return h
}

func TestHealthBanner_ShownWithAlerts(t *testing.T) {
	h := healthDash(t)
	h.SetPortfolioHealthProvider(fakeHealth{ok: true, hs: HealthSummary{
		Total: 3, Critical: 1, High: 2, HasCritical: true, At: time.Now(),
	}})
	html := get(t, h, "/dashboard").Body.String()
	if !strings.Contains(html, `class="health-banner`) {
		t.Fatal("expected a health banner when there are alerts")
	}
	for _, want := range []string{"Portfolio health", "3 alert", "1 critical", "2 high"} {
		if !strings.Contains(html, want) {
			t.Errorf("banner missing %q", want)
		}
	}
	if !strings.Contains(html, "crit") {
		t.Error("a critical sweep should use the crit banner style")
	}
}

func TestHealthBanner_HiddenWhenClean(t *testing.T) {
	h := healthDash(t)
	h.SetPortfolioHealthProvider(fakeHealth{ok: true, hs: HealthSummary{Total: 0}})
	if strings.Contains(get(t, h, "/dashboard").Body.String(), "Portfolio health:") {
		t.Error("no banner should show when there are 0 alerts")
	}
}

func TestHealthBanner_HiddenWithoutProvider(t *testing.T) {
	h := healthDash(t)
	if strings.Contains(get(t, h, "/dashboard").Body.String(), "Portfolio health:") {
		t.Error("no banner should show without a provider")
	}
}

func TestHealthBanner_HiddenBeforeFirstSweep(t *testing.T) {
	h := healthDash(t)
	h.SetPortfolioHealthProvider(fakeHealth{ok: false}) // no sweep yet
	if strings.Contains(get(t, h, "/dashboard").Body.String(), "Portfolio health:") {
		t.Error("no banner should show before the first sweep (ok=false)")
	}
}
