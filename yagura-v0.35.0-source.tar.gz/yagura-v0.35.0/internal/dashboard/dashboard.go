// Package dashboard は Yagura のミニマル HTML ダッシュボードを提供する。
//
// 設計判断:
//   - zero-dep: html/template のみ(stdlib)
//   - サーバサイドレンダリング only(JS なし、最小帯域)
//   - 単一ページ: 全プロジェクトをテーブルで一覧表示
//   - スタイル: インライン CSS(外部リソース読込なし)
//   - 200ms 以内のレスポンスを目標(in-memory データなので余裕)
//
// 認証は呼出側(main.go)で HTTP middleware を被せる前提で、
// このパッケージは認証を持たない。
package dashboard

import (
	"fmt"
	"html/template"
	"log/slog"
	"net/http"
	"sort"
	"strings"
	"time"

	"github.com/shizukutanaka/yagura/internal/project"
	"github.com/shizukutanaka/yagura/internal/quotamonitor"
	"github.com/shizukutanaka/yagura/internal/registry"
)

// Handler は /dashboard HTTP ハンドラを生成する。
type Handler struct {
	registry *registry.Registry
	logger   *slog.Logger
	tmpl     *template.Template
	now      func() time.Time
	// v0.14.0: optional agent status provider (Claude Code ↔ Windsurf handoff)
	quota AgentStatusProvider
}

// AgentStatusProvider は agent quota の最小 view interface。
// 実装は internal/quotamonitor.Monitor。
// nil の場合は dashboard に agent panel を表示しない。
type AgentStatusProvider interface {
	AllStatuses() map[quotamonitor.Agent]quotamonitor.AgentStatus
	Recommend() (quotamonitor.Agent, string)
	AnyStale(idleTimeout time.Duration) []quotamonitor.Agent
	// v0.16.0: usage history (sparkline + numeric metrics)
	AllUsageSummaries() map[quotamonitor.Agent]quotamonitor.UsageSummary
}

// New は Handler を生成する。テンプレートは起動時に 1 度だけパースする。
func New(reg *registry.Registry, logger *slog.Logger) (*Handler, error) {
	if reg == nil {
		return nil, fmt.Errorf("registry is required")
	}
	if logger == nil {
		logger = slog.Default()
	}
	tmpl, err := template.New("dashboard").Funcs(template.FuncMap{
		"stageColor":    stageColor,
		"ciColor":       ciColor,
		"staleClass":    staleClassByTime,
		"priorityClass": priorityClass,
		"daysSince":     daysSince,
		"truncate":      truncate,
		"fmtTime":       fmtTime,
		"securityCell":  securityCell,
	}).Parse(htmlTemplate)
	if err != nil {
		return nil, fmt.Errorf("parse template: %w", err)
	}
	return &Handler{registry: reg, logger: logger, tmpl: tmpl, now: time.Now}, nil
}

// SetNowFunc lets tests pin the current time (used for stale calculations).
func (h *Handler) SetNowFunc(f func() time.Time) { h.now = f }

// SetAgentStatusProvider attaches a quota monitor for the agent panel.
// Pass nil to disable the panel.
func (h *Handler) SetAgentStatusProvider(p AgentStatusProvider) {
	h.quota = p
}

// ServeHTTP は GET /dashboard を捌く。
func (h *Handler) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodGet && r.Method != http.MethodHead {
		w.Header().Set("Allow", "GET, HEAD")
		http.Error(w, "method not allowed", http.StatusMethodNotAllowed)
		return
	}

	// PWA 静的アセット(manifest / service worker / icon)。dashboard を
	// インストール可能なデスクトップアプリにするためのルート。既存の HTML 描画には
	// 触れず、既知 path のときだけ早期 return する(additive)。
	if serveAsset(w, r.URL.Path) {
		return
	}

	now := h.now()
	projects := h.registry.List()
	sort.SliceStable(projects, func(i, j int) bool {
		stageRank := map[project.Stage]int{
			project.StageActive:      0,
			project.StageMaintenance: 1,
			project.StagePaused:      2,
			project.StageArchived:    3,
		}
		if stageRank[projects[i].Stage] != stageRank[projects[j].Stage] {
			return stageRank[projects[i].Stage] < stageRank[projects[j].Stage]
		}
		if projects[i].Priority != projects[j].Priority {
			return projects[i].Priority > projects[j].Priority
		}
		return projects[i].Slug < projects[j].Slug
	})

	var counts = map[project.Stage]int{}
	var failingCI, stale int
	for _, p := range projects {
		counts[p.Stage]++
		if p.CIStatus == project.CIStatusFailing {
			failingCI++
		}
		if p.Stage == project.StageActive && !p.LatestActivity.IsZero() &&
			now.Sub(p.LatestActivity).Hours()/24 >= 14 {
			stale++
		}
	}

	data := map[string]any{
		"Now":         now,
		"Total":       len(projects),
		"Active":      counts[project.StageActive],
		"Maintenance": counts[project.StageMaintenance],
		"Paused":      counts[project.StagePaused],
		"Archived":    counts[project.StageArchived],
		"FailingCI":   failingCI,
		"Stale":       stale,
		"Projects":    projects,
	}

	// v0.14.0: agent panel data
	if h.quota != nil {
		statuses := h.quota.AllStatuses()
		recommended, reason := h.quota.Recommend()
		staleAgents := h.quota.AnyStale(quotamonitor.DefaultIdleTimeout)
		staleSet := map[quotamonitor.Agent]bool{}
		for _, a := range staleAgents {
			staleSet[a] = true
		}
		// v0.16.0: usage summaries(sparkline + numeric metrics)
		usages := h.quota.AllUsageSummaries()

		// 表示順を固定(Claude Code → Windsurf)
		var agents []map[string]any
		for _, a := range []quotamonitor.Agent{
			quotamonitor.AgentClaudeCode, quotamonitor.AgentWindsurf,
		} {
			s, ok := statuses[a]
			if !ok {
				continue
			}
			u := usages[a]
			agents = append(agents, map[string]any{
				"Name":             string(s.Agent),
				"State":            string(s.State),
				"RemainingPercent": s.RemainingPercent,
				"LastReportSource": s.LastReportSource,
				"LastReportAt":     s.LastReportAt,
				"WindowResetsAt":   s.WindowResetsAt,
				"HandoffAt":        s.HandoffAt,
				"LastHeartbeatAt":  s.LastHeartbeatAt,
				"Stale":            staleSet[a],
				// v0.16.0: usage metrics
				"TotalReports":      u.TotalReports,
				"Consumed1h":        u.Consumed1h,
				"Consumed24h":       u.Consumed24h,
				"AvgConsumePerHour": u.AvgConsumePerHour,
				"WindowHours":       u.WindowHours,
				"HasUsageHistory":   u.TotalReports >= 2,
				"SparklinePath":     buildSparklinePath(u.Samples),
			})
		}
		data["AgentsPanel"] = map[string]any{
			"Agents":               agents,
			"RecommendedAgent":     string(recommended),
			"RecommendationReason": reason,
		}
	}

	w.Header().Set("Content-Type", "text/html; charset=utf-8")
	w.Header().Set("X-Content-Type-Options", "nosniff")
	w.Header().Set("Cache-Control", "no-store")
	if err := h.tmpl.Execute(w, data); err != nil {
		h.logger.Error("dashboard: template execute failed", "err", err)
	}
}

// ─── template helpers ────────────────────────────────────────

func stageColor(s project.Stage) string {
	switch s {
	case project.StageActive:
		return "stage-active"
	case project.StageMaintenance:
		return "stage-maintenance"
	case project.StagePaused:
		return "stage-paused"
	case project.StageArchived:
		return "stage-archived"
	}
	return ""
}

func ciColor(s project.CIStatus) string {
	switch s {
	case project.CIStatusPassing:
		return "ci-pass"
	case project.CIStatusFailing:
		return "ci-fail"
	}
	return "ci-unk"
}

func staleClass(days int) string {
	switch {
	case days < 0:
		return "unknown"
	case days <= 7:
		return "fresh"
	case days <= 30:
		return "warm"
	case days <= 90:
		return "cool"
	default:
		return "cold"
	}
}

// buildSparklinePath は ReportEvent サンプル列から SVG polyline 用の "x,y" 文字列を返す。
//
// viewBox は 100×30 を想定。
//   - x 軸: サンプル index を [0, 100] にマッピング
//   - y 軸: remaining_percent を [0, 30] にマッピング(0% が下端 30、100% が上端 0)
//
// サンプル不足(< 2)は空文字を返す(template 側で非表示)。
//
// 戻り値例: "0,10 25,15 50,20 75,18 100,25"
func buildSparklinePath(samples []quotamonitor.ReportEvent) string {
	const w, hgt = 100, 30
	if len(samples) < 2 {
		return ""
	}
	var sb strings.Builder
	n := len(samples)
	for i, ev := range samples {
		if i > 0 {
			sb.WriteByte(' ')
		}
		x := float64(i) * (float64(w) / float64(n-1))
		// remaining 100 → y=0、0 → y=30
		y := float64(hgt) - float64(ev.RemainingPercent)*float64(hgt)/100.0
		if y < 0 {
			y = 0
		}
		if y > float64(hgt) {
			y = float64(hgt)
		}
		fmt.Fprintf(&sb, "%.1f,%.1f", x, y)
	}
	return sb.String()
}

// staleClassByTime は template から呼ばれる版で、stage を考慮して
// active 以外には何も返さない(意図的な非活動を強調しないため)。
func staleClassByTime(t time.Time, now time.Time, stage project.Stage) string {
	if stage != project.StageActive || t.IsZero() {
		return ""
	}
	d := int(now.Sub(t).Hours() / 24)
	if d >= 30 {
		return "stale-red"
	}
	if d >= 14 {
		return "stale-amber"
	}
	return ""
}

func stageOrder(s project.Stage) int {
	switch s {
	case project.StageActive:
		return 0
	case project.StageMaintenance:
		return 1
	case project.StagePaused:
		return 2
	case project.StageArchived:
		return 3
	}
	return 99
}

func priorityClass(p int) string {
	if p >= 4 {
		return "prio-hi"
	}
	if p >= 2 {
		return "prio-mid"
	}
	return "prio-lo"
}

func daysSince(t time.Time, now time.Time) string {
	if t.IsZero() {
		return "—"
	}
	return fmt.Sprintf("%dd", int(now.Sub(t).Hours()/24))
}

func fmtTime(t time.Time) string {
	if t.IsZero() {
		return "—"
	}
	return t.Format("2006-01-02 15:04")
}

func truncate(s string, n int) string {
	r := []rune(s)
	if len(r) <= n {
		return s
	}
	return string(r[:n-1]) + "…"
}

// securityCell は Project の security 状態を HTML 安全な文字列で返す。
// 表示パターン:
//   - 未スキャン:    "—"
//   - スコアあり:    "8.5 ✔︎"  or  "3.2 ⚠"  or  "1.0 ✗"
//   - vuln あり:     "8.5 ✔︎  ! 2C 1H"   (Critical 2 / High 1)
//   - スコアのみ:    "—  ! 2C"
func securityCell(p project.Project) template.HTML {
	hasScorecard := !p.ScorecardAt.IsZero()
	hasVulns := !p.VulnScanAt.IsZero()
	if !hasScorecard && !hasVulns {
		return template.HTML(`<span class="sec-na">—</span>`)
	}

	var b strings.Builder
	if hasScorecard {
		cls := securityScoreClass(p.ScorecardScore)
		b.WriteString(fmt.Sprintf(`<span class="%s" title="OpenSSF Scorecard: %s">%s</span>`,
			cls, scorecardTitle(p.ScorecardScore), formatScore(p.ScorecardScore)))
	} else {
		b.WriteString(`<span class="sec-na">—</span>`)
	}

	if hasVulns && p.TotalVulns() > 0 {
		parts := []string{}
		if p.VulnCritical > 0 {
			parts = append(parts, fmt.Sprintf(`<span class="vuln-crit">%dC</span>`, p.VulnCritical))
		}
		if p.VulnHigh > 0 {
			parts = append(parts, fmt.Sprintf(`<span class="vuln-high">%dH</span>`, p.VulnHigh))
		}
		if p.VulnMedium > 0 {
			parts = append(parts, fmt.Sprintf(`<span class="vuln-med">%dM</span>`, p.VulnMedium))
		}
		if p.VulnLow > 0 {
			parts = append(parts, fmt.Sprintf(`<span class="vuln-low">%dL</span>`, p.VulnLow))
		}
		b.WriteString(` <span class="vuln-sep">!</span> `)
		b.WriteString(strings.Join(parts, " "))
	}
	return template.HTML(b.String())
}

// securityScoreClass は Scorecard score に応じた CSS class を返す。
func securityScoreClass(s float64) string {
	switch {
	case s >= 8.0:
		return "sec-excellent"
	case s >= 6.0:
		return "sec-good"
	case s >= 4.0:
		return "sec-fair"
	case s > 0:
		return "sec-poor"
	}
	return "sec-na"
}

// formatScore は score を 1 桁小数で整形する。
func formatScore(s float64) string {
	return fmt.Sprintf("%.1f", s)
}

// scorecardTitle は score のカテゴリ名を返す(tooltip 用)。
func scorecardTitle(s float64) string {
	switch {
	case s >= 8.0:
		return "excellent"
	case s >= 6.0:
		return "good"
	case s >= 4.0:
		return "fair"
	default:
		return "poor"
	}
}

const htmlTemplate = `<!DOCTYPE html>
<html lang="ja">
<head>
<meta charset="UTF-8">
<title>Yagura Portfolio Dashboard</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="theme-color" content="#0d1117">
<link rel="manifest" href="/dashboard/manifest.webmanifest">
<link rel="icon" type="image/svg+xml" href="/dashboard/icon.svg">
<link rel="apple-touch-icon" href="/dashboard/icon.svg">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-title" content="Yagura">
<style>
* { box-sizing: border-box; margin: 0; padding: 0; }
html { font: 14px/1.5 -apple-system, BlinkMacSystemFont, "Hiragino Sans", "Yu Gothic UI", sans-serif; }
body { background: #0d1117; color: #e6edf3; padding: 24px; }
a { color: #58a6ff; text-decoration: none; }
a:hover { text-decoration: underline; }
.wrap { max-width: 1400px; margin: 0 auto; }
header { margin-bottom: 24px; padding-bottom: 16px; border-bottom: 1px solid #30363d; display: flex; justify-content: space-between; align-items: baseline; flex-wrap: wrap; gap: 12px; }
h1 { font-size: 18px; font-weight: 700; letter-spacing: 0.5px; }
h1 .meta { font-weight: 400; color: #8b949e; font-size: 12px; margin-left: 8px; }
.kpi-row { display: grid; grid-template-columns: repeat(auto-fit, minmax(120px, 1fr)); gap: 8px; margin-bottom: 24px; }
.kpi { background: #161b22; border: 1px solid #30363d; padding: 12px 16px; border-radius: 6px; }
.kpi .label { font-size: 11px; color: #8b949e; text-transform: uppercase; letter-spacing: 0.5px; }
.kpi .val { font-size: 22px; font-weight: 600; margin-top: 4px; }
.kpi.danger .val { color: #f85149; }
.kpi.warn .val { color: #d29922; }
.kpi.ok .val { color: #3fb950; }
table { width: 100%; border-collapse: collapse; background: #0d1117; }
th, td { padding: 10px 12px; text-align: left; border-bottom: 1px solid #21262d; font-size: 13px; }
th { color: #8b949e; font-weight: 600; font-size: 11px; text-transform: uppercase; letter-spacing: 0.5px; background: #161b22; }
tr:hover td { background: #161b22; }
.slug { font-weight: 600; }
.repo a { font-size: 12px; }
.stage { display: inline-block; padding: 2px 8px; font-size: 11px; border-radius: 3px; font-weight: 600; }
.stage-active      { background: #1f6feb33; color: #58a6ff; }
.stage-maintenance { background: #d2992233; color: #d29922; }
.stage-paused      { background: #8b949e33; color: #8b949e; }
.stage-archived    { background: #21262d;   color: #6e7681; }
.ci-pass { color: #3fb950; }
.ci-fail { color: #f85149; font-weight: 700; }
.ci-unk  { color: #6e7681; }
.prio-hi  { color: #f85149; font-weight: 700; }
.prio-mid { color: #d29922; }
.prio-lo  { color: #8b949e; }
.stale-red   { color: #f85149; font-weight: 700; }
.stale-amber { color: #d29922; }
.security { font-family: monospace; font-size: 12px; white-space: nowrap; }
.sec-na          { color: #6e7681; }
.sec-excellent   { color: #3fb950; font-weight: 700; }
.sec-good        { color: #58a6ff; }
.sec-fair        { color: #d29922; }
.sec-poor        { color: #f85149; font-weight: 700; }
.vuln-sep        { color: #6e7681; font-weight: 700; }
.vuln-crit       { color: #f85149; font-weight: 700; background: rgba(248,81,73,0.15); padding: 0 4px; border-radius: 3px; }
.vuln-high       { color: #d29922; font-weight: 700; background: rgba(210,153,34,0.15); padding: 0 4px; border-radius: 3px; }
.vuln-med        { color: #d29922; }
.vuln-low        { color: #8b949e; }
.tags { font-size: 11px; }
.tag { display: inline-block; background: #21262d; color: #8b949e; padding: 1px 6px; border-radius: 3px; margin-right: 4px; font-family: monospace; }
footer { margin-top: 32px; padding-top: 16px; border-top: 1px solid #30363d; color: #6e7681; font-size: 12px; text-align: center; }
.empty { text-align: center; padding: 40px; color: #8b949e; }
.empty code { background: #21262d; padding: 2px 8px; border-radius: 3px; }
.summary { color: #8b949e; font-size: 12px; margin-bottom: 12px; }

/* ─── WCAG 2.1 AA accessibility ─────────────────────────── */
/* Skip-to-content link (only visible when keyboard focused) */
.skip-link {
  position: absolute;
  top: -40px;
  left: 0;
  background: #58a6ff;
  color: #0d1117;
  padding: 8px 16px;
  text-decoration: none;
  font-weight: 600;
  z-index: 100;
}
.skip-link:focus {
  top: 0;
}
/* Visible keyboard focus indicator (WCAG 2.4.7) */
:focus-visible {
  outline: 2px solid #58a6ff;
  outline-offset: 2px;
}
a:focus-visible {
  outline-offset: 4px;
}
/* Screen-reader-only utility class (table caption etc.) */
.sr-only {
  position: absolute;
  width: 1px;
  height: 1px;
  padding: 0;
  margin: -1px;
  overflow: hidden;
  clip: rect(0, 0, 0, 0);
  white-space: nowrap;
  border: 0;
}
/* Respect user motion preferences (WCAG 2.3.3) */
@media (prefers-reduced-motion: reduce) {
  * { animation-duration: 0.01ms !important; transition-duration: 0.01ms !important; }
}
/* v0.14.0: agent handoff panel */
.agents { margin: 32px 0; border-top: 1px solid #30363d; padding-top: 20px; }
.agents h2 { font-size: 14px; font-weight: 600; color: #8b949e; text-transform: uppercase; letter-spacing: 1px; margin-bottom: 12px; }
.agents-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 12px; }
.agent-card { background: #161b22; border: 1px solid #30363d; border-left: 3px solid #58a6ff; padding: 14px 16px; border-radius: 6px; }
.agent-card.agent-ACTIVE { border-left-color: #3fb950; color: #3fb950; }
.agent-card.agent-WARN { border-left-color: #d29922; color: #d29922; }
.agent-card.agent-EXHAUSTED { border-left-color: #f85149; color: #f85149; }
.agent-card.agent-SWITCHED { border-left-color: #8b949e; color: #8b949e; opacity: 0.7; }
.agent-card.agent-stale { background: repeating-linear-gradient(45deg, #161b22, #161b22 8px, #1a1f26 8px, #1a1f26 16px); }
.agent-head { display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px; }
.agent-name { font-family: monospace; font-size: 13px; font-weight: 600; color: #c9d1d9; }
.agent-state { font-size: 10px; padding: 2px 8px; border-radius: 3px; letter-spacing: 0.5px; }
.badge-ACTIVE { background: #1a4730; color: #3fb950; }
.badge-WARN { background: #4a3617; color: #d29922; }
.badge-EXHAUSTED { background: #4a1a1a; color: #f85149; }
.badge-SWITCHED { background: #2d333b; color: #8b949e; }
.agent-quota { display: flex; align-items: center; gap: 10px; margin-bottom: 10px; }
.quota-bar { flex: 1; height: 8px; background: #0d1117; border: 1px solid #30363d; border-radius: 3px; overflow: hidden; }
.quota-fill { height: 100%; background: #3fb950; transition: width 0.3s; }
.agent-WARN .quota-fill { background: #d29922; }
.agent-EXHAUSTED .quota-fill { background: #f85149; }
.quota-pct { font-family: monospace; font-size: 12px; font-weight: 600; min-width: 38px; text-align: right; color: #c9d1d9; }
/* v0.16.0: usage panel(sparkline + metrics)*/
.agent-usage { display: grid; grid-template-columns: 1fr auto; gap: 12px; align-items: center; margin-bottom: 10px; padding: 8px 10px; background: #0d1117; border: 1px solid #21262d; border-radius: 4px; }
.sparkline { width: 100%; max-width: 140px; height: 28px; display: block; }
.usage-metrics { display: grid; grid-template-columns: auto auto; gap: 2px 10px; font-size: 11px; font-family: monospace; align-content: center; }
.usage-row { display: contents; }
.usage-row dt { color: #6e7681; }
.usage-row dd { color: #c9d1d9; font-weight: 600; }
.agent-meta { display: grid; grid-template-columns: auto 1fr; gap: 4px 8px; font-size: 11px; }
.agent-meta dt { color: #8b949e; }
.agent-meta dd { color: #c9d1d9; font-family: monospace; }
.agent-meta .stale-flag { color: #d29922; }
.agent-recommend { margin-top: 12px; padding: 8px 12px; background: #0d1117; border: 1px solid #30363d; border-radius: 4px; font-size: 12px; color: #8b949e; }
.agent-recommend strong { color: #58a6ff; font-family: monospace; }
.agent-recommend small { color: #6e7681; }
</style>
</head>
<body>
<a href="#main" class="skip-link">Skip to main content</a>
<div class="wrap">
  <header>
    <h1>櫓 Yagura <span class="meta">Portfolio Dashboard</span></h1>
    <span style="color:#8b949e;font-size:12px" aria-label="Page generated at">{{fmtTime .Now}}</span>
  </header>

  <main id="main">
  <div class="summary" aria-live="polite">{{.Total}} projects</div>

  <div class="kpi-row" role="group" aria-label="Portfolio summary metrics">
    <div class="kpi" role="status"><div class="label">Total</div><div class="val">{{.Total}}</div></div>
    <div class="kpi ok" role="status"><div class="label">Active</div><div class="val">{{.Active}}</div></div>
    <div class="kpi" role="status"><div class="label">Maint.</div><div class="val">{{.Maintenance}}</div></div>
    <div class="kpi" role="status"><div class="label">Paused</div><div class="val">{{.Paused}}</div></div>
    <div class="kpi" role="status"><div class="label">Archived</div><div class="val">{{.Archived}}</div></div>
    <div class="kpi {{if gt .FailingCI 0}}danger{{else}}ok{{end}}" role="status"><div class="label">CI Failing</div><div class="val">{{.FailingCI}}</div></div>
    <div class="kpi {{if gt .Stale 0}}warn{{else}}ok{{end}}" role="status"><div class="label">Stale ≥14d</div><div class="val">{{.Stale}}</div></div>
  </div>

  {{if eq .Total 0}}
  <div class="empty" role="region" aria-label="Empty portfolio">
    No projects registered yet.<br>
    Use the MCP tool <code>yagura_register</code> from Claude Code to add one.
  </div>
  {{else}}
  <table aria-label="Registered projects">
    <caption class="sr-only">List of all registered projects with their status, security score, and metadata. Sorted by stage, then priority, then slug.</caption>
    <thead>
      <tr>
        <th scope="col">Slug</th>
        <th scope="col">Repository</th>
        <th scope="col">Stage</th>
        <th scope="col" abbr="Priority">Pri</th>
        <th scope="col" abbr="Language">Lang</th>
        <th scope="col" abbr="Latest version">Ver</th>
        <th scope="col" abbr="Continuous Integration status">CI</th>
        <th scope="col" abbr="Open pull requests">PR</th>
        <th scope="col" abbr="Open issues">Iss</th>
        <th scope="col">Last commit</th>
        <th scope="col" title="OpenSSF Scorecard score (0-10) and vulnerability counts">Security</th>
        <th scope="col">Tags</th>
      </tr>
    </thead>
    <tbody>
    {{range .Projects}}
      <tr>
        <td class="slug">{{.Slug}}<br><small style="color:#8b949e">{{.DisplayName}}</small></td>
        <td class="repo"><a href="https://github.com/{{.Repository}}" target="_blank" rel="noopener noreferrer">{{.Repository}}</a></td>
        <td><span class="stage {{stageColor .Stage}}">{{.Stage}}</span></td>
        <td><span class="{{priorityClass .Priority}}">{{.Priority}}</span></td>
        <td>{{.Language}}</td>
        <td>{{if .LatestVersion}}{{.LatestVersion}}{{else}}—{{end}}</td>
        <td><span class="{{ciColor .CIStatus}}">{{if .CIStatus}}{{.CIStatus}}{{else}}—{{end}}</span></td>
        <td>{{.OpenPRs}}</td>
        <td>{{.OpenIssues}}</td>
        <td class="{{staleClass .LatestActivity $.Now .Stage}}">{{daysSince .LatestActivity $.Now}}</td>
        <td class="security">{{securityCell .}}</td>
        <td class="tags">{{range .Tags}}<span class="tag">{{.}}</span>{{end}}</td>
      </tr>
    {{end}}
    </tbody>
  </table>
  {{end}}

  {{with .AgentsPanel}}
  <section class="agents" role="group" aria-label="AI agent quota status">
    <h2>Agent Handoff Status</h2>
    <div class="agents-grid">
    {{range .Agents}}
      <article class="agent-card agent-{{.State}}{{if .Stale}} agent-stale{{end}}" aria-label="{{.Name}} state {{.State}}">
        <header class="agent-head">
          <span class="agent-name">{{.Name}}</span>
          <span class="agent-state badge-{{.State}}">{{.State}}</span>
        </header>
        <div class="agent-quota">
          <div class="quota-bar" role="progressbar" aria-valuenow="{{.RemainingPercent}}" aria-valuemin="0" aria-valuemax="100" aria-label="remaining quota {{.RemainingPercent}}%">
            <div class="quota-fill" style="width:{{.RemainingPercent}}%"></div>
          </div>
          <span class="quota-pct">{{.RemainingPercent}}%</span>
        </div>
        {{if .HasUsageHistory}}
        <div class="agent-usage" aria-label="usage history for {{.Name}}">
          <svg class="sparkline" viewBox="0 0 100 30" preserveAspectRatio="none" aria-label="quota over last {{.TotalReports}} reports">
            <polyline points="{{.SparklinePath}}" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linejoin="round" stroke-linecap="round"/>
          </svg>
          <dl class="usage-metrics">
            <div class="usage-row"><dt>reports</dt><dd>{{.TotalReports}}</dd></div>
            {{if gt .Consumed1h 0.0}}<div class="usage-row"><dt>1h</dt><dd>−{{printf "%.0f" .Consumed1h}}%</dd></div>{{end}}
            {{if gt .Consumed24h 0.0}}<div class="usage-row"><dt>24h</dt><dd>−{{printf "%.0f" .Consumed24h}}%</dd></div>{{end}}
            {{if gt .AvgConsumePerHour 0.0}}<div class="usage-row"><dt>avg/h</dt><dd>−{{printf "%.1f" .AvgConsumePerHour}}%</dd></div>{{end}}
          </dl>
        </div>
        {{end}}
        <dl class="agent-meta">
          {{if .LastReportSource}}<dt>source</dt><dd>{{.LastReportSource}}</dd>{{end}}
          {{if not .HandoffAt.IsZero}}<dt>handoff at</dt><dd>{{fmtTime .HandoffAt}}</dd>{{end}}
          {{if not .LastHeartbeatAt.IsZero}}<dt>heartbeat</dt><dd>{{fmtTime .LastHeartbeatAt}}</dd>{{end}}
          {{if .Stale}}<dt class="stale-flag">stale</dt><dd>(no heartbeat ≥ 10m)</dd>{{end}}
        </dl>
      </article>
    {{end}}
    </div>
    {{if .RecommendedAgent}}
    <p class="agent-recommend" role="status">
      → Recommended: <strong>{{.RecommendedAgent}}</strong>
      <small>({{.RecommendationReason}})</small>
    </p>
    {{end}}
  </section>
  {{end}}
  </main>

  <footer role="contentinfo">櫓 Yagura — Portfolio Orchestrator · v0.35.0</footer>
</div>
<script>if('serviceWorker' in navigator){navigator.serviceWorker.register('/dashboard/sw.js',{scope:'/dashboard'}).catch(function(){});}</script>
</body>
</html>`
