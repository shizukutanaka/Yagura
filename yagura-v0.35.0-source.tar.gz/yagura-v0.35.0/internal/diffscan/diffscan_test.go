package diffscan

import "testing"

func TestAddedLines_Simple(t *testing.T) {
	diff := `diff --git a/foo.go b/foo.go
--- a/foo.go
+++ b/foo.go
@@ -1,3 +1,4 @@
 package foo

+var added = 1
 func F() {}
`
	got := AddedLines(diff)
	if len(got) != 1 {
		t.Fatalf("expected 1 added line, got %d: %+v", len(got), got)
	}
	if got[0].Path != "foo.go" || got[0].Line != 3 || got[0].Text != "var added = 1" {
		t.Errorf("wrong added line: %+v", got[0])
	}
}

func TestAddedLines_RemovedDoesNotShift(t *testing.T) {
	// a removed line must not advance the new-file line counter.
	diff := `--- a/x.go
+++ b/x.go
@@ -1,3 +1,3 @@
 a
-old
+new
 c
`
	got := AddedLines(diff)
	if len(got) != 1 {
		t.Fatalf("expected 1 added line, got %d", len(got))
	}
	if got[0].Line != 2 || got[0].Text != "new" {
		t.Errorf("expected 'new' at new-file line 2, got %+v", got[0])
	}
}

func TestAddedLines_NewFile(t *testing.T) {
	diff := `diff --git a/new.go b/new.go
new file mode 100644
--- /dev/null
+++ b/new.go
@@ -0,0 +1,2 @@
+package new
+var x = 1
`
	got := AddedLines(diff)
	if len(got) != 2 {
		t.Fatalf("expected 2 added lines, got %d: %+v", len(got), got)
	}
	if got[0].Path != "new.go" || got[0].Line != 1 || got[1].Line != 2 {
		t.Errorf("new-file added lines wrong: %+v", got)
	}
}

func TestAddedLines_MultipleFiles(t *testing.T) {
	diff := `--- a/a.go
+++ b/a.go
@@ -1 +1,2 @@
 a
+addA
--- a/b.go
+++ b/b.go
@@ -1 +1,2 @@
 b
+addB
`
	got := AddedLines(diff)
	if len(got) != 2 {
		t.Fatalf("expected 2 added lines across files, got %d", len(got))
	}
	if got[0].Path != "a.go" || got[0].Text != "addA" || got[1].Path != "b.go" || got[1].Text != "addB" {
		t.Errorf("multi-file attribution wrong: %+v", got)
	}
}

func TestAddedLines_PlusPlusPlusNotCountedAsAdded(t *testing.T) {
	// the +++ header must never be treated as an added content line.
	diff := `--- a/x.go
+++ b/x.go
@@ -1 +1 @@
 unchanged
`
	if got := AddedLines(diff); len(got) != 0 {
		t.Errorf("no content added; +++ header must not count, got %+v", got)
	}
}

func TestAddedLines_Empty(t *testing.T) {
	if got := AddedLines(""); len(got) != 0 {
		t.Errorf("empty diff yields no added lines, got %v", got)
	}
}
