// Package riskreason は脆弱性の「複合判断」を rule-based / deterministic に行う
// Cyber Risk Reasoning Layer。
//
// 着想は「AIセキュリティは検知ロジックから複合判断へ」— CVSS 単体では本当の
// 修正優先度は決まらず、(1) 脆弱性深刻度、(2) 資産の業務重要度、(3) 到達可能性
// (公開/認証/WAF)、(4) 攻撃可能性(KEV/公開エクスプロイト)、(5) 横展開の
// blast radius(依存元数)、(6) パッチの業務影響を合わせて初めて優先度が出る、
// という考え方を構造化したもの。
//
// この層の設計要件(記事準拠)を rule-based で満たす:
//   - 根拠提示: Score がどの factor をどれだけ加点/減点したか(Factors)を返す
//   - 再現性 : 同じ入力 → 同じ判断。LLM を使わない決定論(Yagura の trust base)
//   - 文脈ギャップの明示: 評価できなかった要因(公開状況/エクスプロイト等)を
//     Unknowns として出す ——「AI が複合判断できる文脈を組織が持っているか」が
//     次の勝負、という記事の主張をそのまま機械可読にする
//   - リスクと対応の分離: パッチの業務影響は risk score を下げず、Recommendation
//     (今すぐ遮断 / 監視強化 / パッチ / 例外承認 / 経営報告)側に効く
//
// Yagura は判断を「自動実行」しない。本層は人間(SOC/CSIRT/脆弱性管理/経営)が
// 検証できる根拠付きの優先度を返す判断補助エンジンであり、audit log と併せて
// Human-in-the-Loop を前提とする。
package riskreason

import (
	"fmt"
	"sort"
	"strings"
)

// Priority は修正優先度バンド。
type Priority string

const (
	PriorityNow       Priority = "NOW"       // 今すぐ(遮断/隔離も検討)
	PrioritySoon      Priority = "SOON"      // 次の保守ウィンドウ
	PriorityScheduled Priority = "SCHEDULED" // 計画的に
	PriorityMonitor   Priority = "MONITOR"   // 監視継続・通常サイクル
	PriorityDefer     Priority = "DEFER"     // 後回し(低重要度/archived)
)

// Input は 1 脆弱性 × 1 資産の複合エビデンス。
// *bool は「不明(nil)」と「false」を区別する — 不明は Unknowns に積み、
// 組織が整えるべき文脈ギャップとして可視化する。
type Input struct {
	CVE      string  `json:"cve"`
	CVSS     float64 `json:"cvss"`     // 0-10 base score(0 = severity 文字列で判定)
	Severity string  `json:"severity"` // CVSS が無い時の代替("critical"/"high"/...)

	// 資産・業務文脈(registry 由来)。
	AssetPriority int      `json:"asset_priority"` // 0-5(project.Priority)
	Stage         string   `json:"stage"`          // active/maintenance/paused/archived
	Tags          []string `json:"tags"`           // production / pii / external 等

	// 到達可能性。
	InternetExposed *bool `json:"internet_exposed"`
	AuthRequired    *bool `json:"auth_required"`
	WAFProtected    *bool `json:"waf_protected"`

	// 攻撃可能性(脅威インテリジェンス)。
	KnownExploited *bool `json:"known_exploited"` // CISA KEV 等、実環境で悪用中
	PublicExploit  *bool `json:"public_exploit"`  // エクスプロイトコード公開

	// 横展開の blast radius(projectgraph の Impact 由来 = 依存元数)。
	Dependents int `json:"dependents"`

	// パッチの業務影響(true = すぐ当てられない)。risk score ではなく対応に効く。
	PatchBlocksBusiness *bool `json:"patch_blocks_business"`
}

// Factor は score を動かした 1 要因(根拠提示)。
type Factor struct {
	Name   string `json:"name"`
	Delta  int    `json:"delta"`
	Detail string `json:"detail"`
}

// Result は複合判断の出力。
type Result struct {
	CVE            string   `json:"cve"`
	Score          int      `json:"score"`              // 0-100 の複合リスク
	Priority       Priority `json:"priority"`           // 修正優先度バンド
	Factors        []Factor `json:"factors"`            // 根拠(加点/減点の内訳)
	Unknowns       []string `json:"unknowns,omitempty"` // 評価できなかった文脈ギャップ
	Recommendation string   `json:"recommendation"`
}

// 重み(rule-based、決定論)。
const (
	wSevCritical = 45
	wSevHigh     = 32
	wSevMedium   = 18
	wSevLow      = 7
)

// Score は複合エビデンスから修正優先度を導く。完全に決定論的。
func Score(in Input) Result {
	r := Result{CVE: in.CVE}
	score := 0
	add := func(name string, delta int, detail string) {
		if delta != 0 {
			r.Factors = append(r.Factors, Factor{Name: name, Delta: delta, Detail: detail})
			score += delta
		}
	}

	// ── (1) 深刻度ベース ──
	switch sev := severityBucket(in.CVSS, in.Severity); sev {
	case "critical":
		add("severity", wSevCritical, "CVSS critical (>=9.0)")
	case "high":
		add("severity", wSevHigh, "CVSS high (7.0-8.9)")
	case "medium":
		add("severity", wSevMedium, "CVSS medium (4.0-6.9)")
	case "low":
		add("severity", wSevLow, "CVSS low (<4.0)")
	default:
		r.Unknowns = append(r.Unknowns, "severity (no CVSS or severity string provided)")
	}

	// ── (2) 資産の業務重要度 ──
	if in.AssetPriority > 0 {
		d := in.AssetPriority * 4 // 0-5 → 0-20
		add("asset_priority", d, fmt.Sprintf("business criticality (priority %d/5)", in.AssetPriority))
	}
	switch strings.ToLower(strings.TrimSpace(in.Stage)) {
	case "archived":
		add("stage", -20, "asset archived (out of service)")
	case "paused":
		add("stage", -12, "asset paused")
	case "maintenance":
		add("stage", -3, "asset in maintenance")
	}
	add(tagSignal(in.Tags))

	// ── (3) 到達可能性 ──
	tri(in.InternetExposed, &r, &score,
		"reachability", 15, "internet-exposed (reachable by external attackers)",
		-10, "not internet-exposed (internal only)",
		"internet exposure")
	tri(in.AuthRequired, &r, &score,
		"auth", -6, "authentication required to reach",
		12, "reachable without authentication",
		"authentication requirement")
	tri(in.WAFProtected, &r, &score,
		"waf", -8, "WAF/edge filtering in front",
		4, "no WAF in front",
		"WAF coverage")

	// ── (4) 攻撃可能性 ──
	triHi(in.KnownExploited, &r, &score, "known_exploited", 28,
		"actively exploited in the wild (e.g. CISA KEV)", "known-exploited status (CISA KEV)")
	triHi(in.PublicExploit, &r, &score, "public_exploit", 12,
		"public exploit code available", "public exploit availability")

	// ── (5) 横展開 blast radius ──
	if in.Dependents > 0 {
		d := in.Dependents * 3
		if d > 18 {
			d = 18
		}
		add("blast_radius", d, fmt.Sprintf("%d asset(s) depend on this (lateral blast radius)", in.Dependents))
	}

	if score < 0 {
		score = 0
	}
	if score > 100 {
		score = 100
	}
	r.Score = score
	r.Priority = band(score)
	r.Recommendation = recommend(r.Priority, in, r.Unknowns)
	return r
}

// ScoreAll は複数 finding を score し、score 降順(tie は CVE 昇順)で返す。
func ScoreAll(inputs []Input) []Result {
	out := make([]Result, 0, len(inputs))
	for _, in := range inputs {
		out = append(out, Score(in))
	}
	sort.SliceStable(out, func(i, j int) bool {
		if out[i].Score != out[j].Score {
			return out[i].Score > out[j].Score
		}
		return out[i].CVE < out[j].CVE
	})
	return out
}

// ─── helpers ───

func severityBucket(cvss float64, sev string) string {
	if cvss > 0 {
		switch {
		case cvss >= 9.0:
			return "critical"
		case cvss >= 7.0:
			return "high"
		case cvss >= 4.0:
			return "medium"
		default:
			return "low"
		}
	}
	switch strings.ToLower(strings.TrimSpace(sev)) {
	case "critical":
		return "critical"
	case "high":
		return "high"
	case "medium", "moderate":
		return "medium"
	case "low":
		return "low"
	}
	return ""
}

// tagSignal は tags から 1 つの集約 factor を返す(production/data 機微 → 加点、
// dev/test → 減点。多重加点を避けるため上限つき)。
func tagSignal(tags []string) (string, int, string) {
	exposure, sensitive, lowval := false, false, false
	for _, t := range tags {
		switch strings.ToLower(strings.TrimSpace(t)) {
		case "production", "prod", "external", "public", "internet-facing":
			exposure = true
		case "pii", "secret", "financial", "payment", "audit", "confidential":
			sensitive = true
		case "internal", "dev", "development", "test", "staging", "sandbox", "experimental":
			lowval = true
		}
	}
	delta := 0
	parts := []string{}
	if exposure {
		delta += 8
		parts = append(parts, "production/external")
	}
	if sensitive {
		delta += 8
		parts = append(parts, "sensitive-data")
	}
	if lowval && delta == 0 {
		delta -= 6
		parts = append(parts, "non-production")
	}
	if delta == 0 {
		return "tags", 0, ""
	}
	return "tags", delta, "asset tags: " + strings.Join(parts, ", ")
}

// tri は *bool(不明/真/偽)を factor に落とす(真と偽で別 detail、nil は Unknowns)。
func tri(v *bool, r *Result, score *int, name string, dTrue int, detailTrue string, dFalse int, detailFalse string, unknownLabel string) {
	if v == nil {
		r.Unknowns = append(r.Unknowns, unknownLabel)
		return
	}
	if *v {
		if dTrue != 0 {
			r.Factors = append(r.Factors, Factor{Name: name, Delta: dTrue, Detail: detailTrue})
			*score += dTrue
		}
	} else if dFalse != 0 {
		r.Factors = append(r.Factors, Factor{Name: name, Delta: dFalse, Detail: detailFalse})
		*score += dFalse
	}
}

// triHi は「真の時だけ加点、偽は無印、nil は Unknowns」の脅威インテル型 factor。
func triHi(v *bool, r *Result, score *int, name string, dTrue int, detailTrue, unknownLabel string) {
	if v == nil {
		r.Unknowns = append(r.Unknowns, unknownLabel)
		return
	}
	if *v {
		r.Factors = append(r.Factors, Factor{Name: name, Delta: dTrue, Detail: detailTrue})
		*score += dTrue
	}
}

func band(score int) Priority {
	switch {
	case score >= 75:
		return PriorityNow
	case score >= 55:
		return PrioritySoon
	case score >= 35:
		return PriorityScheduled
	case score >= 15:
		return PriorityMonitor
	default:
		return PriorityDefer
	}
}

func isTrue(b *bool) bool { return b != nil && *b }

func recommend(p Priority, in Input, unknowns []string) string {
	var sb strings.Builder
	switch p {
	case PriorityNow:
		if isTrue(in.KnownExploited) {
			sb.WriteString("Actively exploited — ")
		}
		if isTrue(in.PatchBlocksBusiness) {
			sb.WriteString("fix now, but patching has business impact: apply compensating controls (tighten access / WAF / raise monitoring), record a risk-acceptance exception, and escalate to management")
		} else {
			sb.WriteString("patch immediately and raise monitoring until patched")
		}
		if isTrue(in.InternetExposed) {
			sb.WriteString("; restrict external reachability in the meantime")
		}
	case PrioritySoon:
		sb.WriteString("patch in the next maintenance window; raise monitoring meanwhile")
		if isTrue(in.PatchBlocksBusiness) {
			sb.WriteString(" and record the deferral as a risk-acceptance exception")
		}
	case PriorityScheduled:
		sb.WriteString("schedule a patch on the normal cadence")
	case PriorityMonitor:
		sb.WriteString("low active risk — keep monitoring; patch on the normal cadence")
	case PriorityDefer:
		sb.WriteString("defer (low criticality / archived asset); revisit if exposure or exploit status changes")
	}
	if len(unknowns) > 0 {
		sb.WriteString(fmt.Sprintf(". %d risk factor(s) are unknown (%s) — wire that context in to sharpen this judgment",
			len(unknowns), strings.Join(unknowns, ", ")))
	}
	return sb.String()
}
