package riskreason

import (
	"strings"
	"testing"
)

func b(v bool) *bool { return &v }

func hasFactor(r Result, name string) bool {
	for _, f := range r.Factors {
		if f.Name == name {
			return true
		}
	}
	return false
}

func TestScore_CriticalExposedExploited_IsNow(t *testing.T) {
	r := Score(Input{
		CVE: "CVE-2026-0001", CVSS: 9.8, AssetPriority: 5,
		Tags:            []string{"production", "pii"},
		InternetExposed: b(true), AuthRequired: b(false),
		KnownExploited: b(true), PublicExploit: b(true), Dependents: 4,
	})
	if r.Priority != PriorityNow {
		t.Errorf("expected NOW, got %s (score %d)", r.Priority, r.Score)
	}
	for _, name := range []string{"severity", "asset_priority", "reachability", "known_exploited", "blast_radius"} {
		if !hasFactor(r, name) {
			t.Errorf("expected factor %q in rationale, got %+v", name, r.Factors)
		}
	}
	if !strings.Contains(r.Recommendation, "Actively exploited") {
		t.Errorf("recommendation should flag active exploitation: %q", r.Recommendation)
	}
}

func TestScore_BusinessContextLowersPriority(t *testing.T) {
	// Same critical CVE, but on an archived, internal, non-exposed asset → not urgent.
	r := Score(Input{
		CVE: "CVE-2026-0002", CVSS: 9.8, AssetPriority: 1,
		Stage: "archived", Tags: []string{"internal", "dev"},
		InternetExposed: b(false), KnownExploited: b(false), PublicExploit: b(false),
	})
	if r.Priority == PriorityNow {
		t.Errorf("archived internal asset should not be NOW despite critical CVSS: score %d", r.Score)
	}
	if !hasFactor(r, "stage") {
		t.Errorf("expected an archived stage factor lowering score: %+v", r.Factors)
	}
}

func TestScore_UnknownsListed(t *testing.T) {
	// Only CVE + CVSS — every reachability/exploit factor is unknown.
	r := Score(Input{CVE: "CVE-2026-0003", CVSS: 7.5})
	want := []string{"internet exposure", "authentication requirement", "WAF coverage",
		"known-exploited status (CISA KEV)", "public exploit availability"}
	for _, w := range want {
		found := false
		for _, u := range r.Unknowns {
			if u == w {
				found = true
			}
		}
		if !found {
			t.Errorf("expected unknown %q, got %+v", w, r.Unknowns)
		}
	}
	if !strings.Contains(r.Recommendation, "unknown") {
		t.Errorf("recommendation should mention context gaps: %q", r.Recommendation)
	}
}

func TestScore_PatchImpactChangesResponseNotScore(t *testing.T) {
	base := Input{CVE: "CVE-2026-0004", CVSS: 9.5, AssetPriority: 5,
		InternetExposed: b(true), KnownExploited: b(true)}
	a := Score(base)
	withImpact := base
	withImpact.PatchBlocksBusiness = b(true)
	c := Score(withImpact)
	if a.Score != c.Score {
		t.Errorf("patch business impact must not change the risk score: %d vs %d", a.Score, c.Score)
	}
	if a.Recommendation == c.Recommendation {
		t.Error("patch business impact should change the recommendation")
	}
	if !strings.Contains(c.Recommendation, "compensating controls") {
		t.Errorf("blocked-patch NOW should suggest compensating controls: %q", c.Recommendation)
	}
}

func TestScore_Deterministic(t *testing.T) {
	in := Input{CVE: "CVE-2026-0005", CVSS: 8.1, AssetPriority: 3, Tags: []string{"production"},
		InternetExposed: b(true), Dependents: 2}
	if Score(in).Score != Score(in).Score {
		t.Error("scoring must be deterministic")
	}
}

func TestScoreAll_OrderedByScoreDesc(t *testing.T) {
	rs := ScoreAll([]Input{
		{CVE: "CVE-low", CVSS: 3.0, Stage: "archived"},
		{CVE: "CVE-hi", CVSS: 9.8, AssetPriority: 5, InternetExposed: b(true), KnownExploited: b(true)},
		{CVE: "CVE-mid", CVSS: 6.0, AssetPriority: 2},
	})
	if rs[0].CVE != "CVE-hi" || rs[len(rs)-1].CVE != "CVE-low" {
		t.Errorf("expected score-desc order hi..low, got %s..%s", rs[0].CVE, rs[len(rs)-1].CVE)
	}
}

func TestScore_SeverityFromStringWhenNoCVSS(t *testing.T) {
	r := Score(Input{CVE: "CVE-2026-0006", Severity: "high", AssetPriority: 2})
	if !hasFactor(r, "severity") {
		t.Errorf("severity string should drive the base factor: %+v", r.Factors)
	}
}

func TestScore_TagSignals(t *testing.T) {
	prod := Score(Input{CVE: "a", CVSS: 5, Tags: []string{"production", "pii"}})
	dev := Score(Input{CVE: "b", CVSS: 5, Tags: []string{"dev"}})
	if prod.Score <= dev.Score {
		t.Errorf("production+pii should outrank a dev asset: prod=%d dev=%d", prod.Score, dev.Score)
	}
}
