package promexport

import (
	"bytes"
	"strings"
	"testing"
)

func TestRender_SingleCounter(t *testing.T) {
	cs := []Collection{
		{
			Name: "yagura_tool_calls_total",
			Type: "counter",
			Help: "Total MCP tool invocations",
			Samples: []Sample{
				{Labels: map[string]string{"tool": "yagura_list"}, Value: 5},
			},
		},
	}
	var buf bytes.Buffer
	if err := Render(&buf, cs); err != nil {
		t.Fatal(err)
	}
	out := buf.String()
	if !strings.Contains(out, "# HELP yagura_tool_calls_total Total MCP tool invocations") {
		t.Errorf("missing HELP: %s", out)
	}
	if !strings.Contains(out, "# TYPE yagura_tool_calls_total counter") {
		t.Errorf("missing TYPE: %s", out)
	}
	if !strings.Contains(out, `yagura_tool_calls_total{tool="yagura_list"} 5`) {
		t.Errorf("missing series: %s", out)
	}
}

func TestRender_NoLabels(t *testing.T) {
	cs := []Collection{
		{Name: "uptime_seconds", Type: "gauge", Samples: []Sample{{Value: 42}}},
	}
	var buf bytes.Buffer
	_ = Render(&buf, cs)
	if !strings.Contains(buf.String(), "uptime_seconds 42") {
		t.Errorf("no-labels: %s", buf.String())
	}
}

func TestRender_DeterministicLabelsOrder(t *testing.T) {
	cs := []Collection{
		{
			Name: "x", Type: "counter",
			Samples: []Sample{
				{Labels: map[string]string{"b": "2", "a": "1"}, Value: 1},
			},
		},
	}
	var buf bytes.Buffer
	_ = Render(&buf, cs)
	// a が b より先
	if !strings.Contains(buf.String(), `x{a="1",b="2"} 1`) {
		t.Errorf("labels order: %s", buf.String())
	}
}

func TestRender_DeterministicSamplesOrder(t *testing.T) {
	cs := []Collection{
		{
			Name: "x", Type: "counter",
			Samples: []Sample{
				{Labels: map[string]string{"tool": "z"}, Value: 3},
				{Labels: map[string]string{"tool": "a"}, Value: 1},
				{Labels: map[string]string{"tool": "m"}, Value: 2},
			},
		},
	}
	var buf bytes.Buffer
	_ = Render(&buf, cs)
	// a, m, z の順
	out := buf.String()
	posA := strings.Index(out, `tool="a"`)
	posM := strings.Index(out, `tool="m"`)
	posZ := strings.Index(out, `tool="z"`)
	if !(posA < posM && posM < posZ) {
		t.Errorf("sample order broken: %s", out)
	}
}

func TestEscapeLabelValue(t *testing.T) {
	cases := []struct {
		in, want string
	}{
		{`abc`, `abc`},
		{`a"b`, `a\"b`},
		{`a\b`, `a\\b`},
		{"a\nb", `a\nb`},
		{`a\"b`, `a\\\"b`},
	}
	for _, c := range cases {
		if got := escapeLabelValue(c.in); got != c.want {
			t.Errorf("escape(%q): got %q want %q", c.in, got, c.want)
		}
	}
}

func TestFormatFloat_IntegerNoDecimal(t *testing.T) {
	if formatFloat(5) != "5" {
		t.Errorf("integer should not have decimal")
	}
}

func TestFormatFloat_Fractional(t *testing.T) {
	if !strings.Contains(formatFloat(1.5), ".") {
		t.Errorf("fractional should have decimal")
	}
}

func TestRender_FloatValueFormatted(t *testing.T) {
	cs := []Collection{
		{Name: "ratio", Type: "gauge", Samples: []Sample{{Value: 0.75}}},
	}
	var buf bytes.Buffer
	_ = Render(&buf, cs)
	if !strings.Contains(buf.String(), "ratio 0.75") {
		t.Errorf("fractional: %s", buf.String())
	}
}

func TestRender_CollectionsNameSorted(t *testing.T) {
	cs := []Collection{
		{Name: "z_metric", Type: "counter", Samples: []Sample{{Value: 1}}},
		{Name: "a_metric", Type: "counter", Samples: []Sample{{Value: 2}}},
	}
	var buf bytes.Buffer
	_ = Render(&buf, cs)
	out := buf.String()
	if strings.Index(out, "a_metric") > strings.Index(out, "z_metric") {
		t.Errorf("collection order: %s", out)
	}
}

func TestRender_LabelValueWithSpecialChars(t *testing.T) {
	cs := []Collection{
		{Name: "x", Type: "counter", Samples: []Sample{
			{Labels: map[string]string{"path": `/tmp/"quoted"\back`}, Value: 1},
		}},
	}
	var buf bytes.Buffer
	_ = Render(&buf, cs)
	out := buf.String()
	if !strings.Contains(out, `path="/tmp/\"quoted\"\\back"`) {
		t.Errorf("escape failure: %s", out)
	}
}
