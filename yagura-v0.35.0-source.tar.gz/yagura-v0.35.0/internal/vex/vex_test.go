package vex

import (
	"encoding/json"
	"strings"
	"testing"
	"time"
)

var fixedNow = time.Date(2026, 6, 6, 12, 0, 0, 0, time.UTC)

func TestBuild_Defaults(t *testing.T) {
	d := Build("", fixedNow, []Statement{
		{Vulnerability: Vuln{Name: "CVE-2025-0001"}},
	})
	if d.Author != "yagura" {
		t.Errorf("author default = %q, want yagura", d.Author)
	}
	if d.Context != contextURL {
		t.Errorf("context = %q, want %q", d.Context, contextURL)
	}
	if d.Version != 1 {
		t.Errorf("version = %d, want 1", d.Version)
	}
	if d.Timestamp != "2026-06-06T12:00:00Z" {
		t.Errorf("timestamp = %q", d.Timestamp)
	}
	if got := d.Statements[0].Status; got != StatusUnderInvestigation {
		t.Errorf("default status = %q, want under_investigation", got)
	}
	if !strings.HasPrefix(d.ID, "urn:yagura:vex:") {
		t.Errorf("@id = %q, want urn:yagura:vex: prefix", d.ID)
	}
}

func TestBuild_Deterministic(t *testing.T) {
	stmts := []Statement{
		{Vulnerability: Vuln{Name: "CVE-2025-0002"}, Status: StatusFixed},
		{Vulnerability: Vuln{Name: "CVE-2025-0001"}, Status: StatusAffected, ActionStatement: "upgrade"},
	}
	a := Build("acme", fixedNow, stmts)
	b := Build("acme", fixedNow, stmts)
	if a.ID != b.ID {
		t.Errorf("@id not deterministic: %q vs %q", a.ID, b.ID)
	}
	ja, _ := json.Marshal(a)
	jb, _ := json.Marshal(b)
	if string(ja) != string(jb) {
		t.Error("documents not byte-identical for identical input")
	}
}

func TestBuild_Sorted(t *testing.T) {
	d := Build("acme", fixedNow, []Statement{
		{Vulnerability: Vuln{Name: "CVE-2025-0009"}, Status: StatusFixed},
		{Vulnerability: Vuln{Name: "CVE-2025-0001"}, Status: StatusFixed},
		{Vulnerability: Vuln{Name: "CVE-2025-0005"}, Status: StatusFixed},
	})
	want := []string{"CVE-2025-0001", "CVE-2025-0005", "CVE-2025-0009"}
	for i, w := range want {
		if d.Statements[i].Vulnerability.Name != w {
			t.Errorf("statement[%d] = %q, want %q", i, d.Statements[i].Vulnerability.Name, w)
		}
	}
}

func TestBuild_SortByProductTieBreak(t *testing.T) {
	d := Build("acme", fixedNow, []Statement{
		{Vulnerability: Vuln{Name: "CVE-2025-0001"}, Products: []Product{{ID: "pkg:zeta"}}, Status: StatusFixed},
		{Vulnerability: Vuln{Name: "CVE-2025-0001"}, Products: []Product{{ID: "pkg:alpha"}}, Status: StatusFixed},
	})
	if d.Statements[0].Products[0].ID != "pkg:alpha" {
		t.Errorf("tie-break by product failed: got %q first", d.Statements[0].Products[0].ID)
	}
}

func TestBuild_TrimsVulnName(t *testing.T) {
	d := Build("acme", fixedNow, []Statement{
		{Vulnerability: Vuln{Name: "  CVE-2025-0001  "}, Status: StatusFixed},
	})
	if d.Statements[0].Vulnerability.Name != "CVE-2025-0001" {
		t.Errorf("name not trimmed: %q", d.Statements[0].Vulnerability.Name)
	}
}

func TestValidate_OK(t *testing.T) {
	d := Build("acme", fixedNow, []Statement{
		{Vulnerability: Vuln{Name: "CVE-2025-0001"}, Status: StatusNotAffected, Justification: JustComponentNotPresent},
		{Vulnerability: Vuln{Name: "CVE-2025-0002"}, Status: StatusAffected, ActionStatement: "upgrade to 2.0"},
		{Vulnerability: Vuln{Name: "CVE-2025-0003"}, Status: StatusFixed},
	})
	if issues := Validate(d); len(issues) != 0 {
		t.Errorf("expected no issues, got %v", issues)
	}
}

func TestValidate_NotAffectedNeedsJustification(t *testing.T) {
	d := Build("acme", fixedNow, []Statement{
		{Vulnerability: Vuln{Name: "CVE-2025-0001"}, Status: StatusNotAffected},
	})
	issues := Validate(d)
	if !hasIssue(issues, "requires a justification") {
		t.Errorf("expected justification issue, got %v", issues)
	}
}

func TestValidate_NotAffectedImpactStatementOK(t *testing.T) {
	d := Build("acme", fixedNow, []Statement{
		{Vulnerability: Vuln{Name: "CVE-2025-0001"}, Status: StatusNotAffected, ImpactStatement: "endpoint unreachable"},
	})
	if issues := Validate(d); len(issues) != 0 {
		t.Errorf("impact_statement should satisfy not_affected, got %v", issues)
	}
}

func TestValidate_InvalidJustification(t *testing.T) {
	d := Build("acme", fixedNow, []Statement{
		{Vulnerability: Vuln{Name: "CVE-2025-0001"}, Status: StatusNotAffected, Justification: "made_up"},
	})
	if !hasIssue(Validate(d), "invalid justification") {
		t.Error("expected invalid justification issue")
	}
}

func TestValidate_InvalidStatus(t *testing.T) {
	d := Document{
		Context:    contextURL,
		Statements: []Statement{{Vulnerability: Vuln{Name: "CVE-2025-0001"}, Status: "broken"}},
	}
	if !hasIssue(Validate(d), "invalid status") {
		t.Error("expected invalid status issue")
	}
}

func TestValidate_AffectedNeedsAction(t *testing.T) {
	d := Build("acme", fixedNow, []Statement{
		{Vulnerability: Vuln{Name: "CVE-2025-0001"}, Status: StatusAffected},
	})
	if !hasIssue(Validate(d), "action_statement") {
		t.Error("expected action_statement issue for affected")
	}
}

func TestValidate_MissingName(t *testing.T) {
	d := Document{
		Context:    contextURL,
		Statements: []Statement{{Status: StatusFixed}},
	}
	if !hasIssue(Validate(d), "vulnerability.name is required") {
		t.Error("expected missing name issue")
	}
}

func TestValidate_EmptyDocument(t *testing.T) {
	issues := Validate(Document{})
	if !hasIssue(issues, "missing @context") || !hasIssue(issues, "no statements") {
		t.Errorf("expected context+statements issues, got %v", issues)
	}
}

func hasIssue(issues []string, substr string) bool {
	for _, s := range issues {
		if strings.Contains(s, substr) {
			return true
		}
	}
	return false
}
