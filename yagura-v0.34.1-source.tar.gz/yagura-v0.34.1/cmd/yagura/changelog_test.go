package main

import (
	"os"
	"path/filepath"
	"regexp"
	"strconv"
	"strings"
	"testing"
)

// CHANGELOG.md は手書きの長大なドキュメントで、過去に生成フラグメントの
// 連結ミスで同一バージョン見出しが最大 4 回重複していた。これらのテストは
// その種の重複・順序崩れが再混入したら CI / `go test` で落とすための回帰ガード。
//
// 不変条件:
//  1. バージョン見出し (`## [vX.Y.Z] - ...`) は各バージョン 1 回だけ。
//  2. バージョンは厳密に降順 (semver) で並ぶ。
//  3. どの 2 つの `## ` ブロックも byte 単位で同一にならない (純粋重複の検出)。

var versionHeaderRe = regexp.MustCompile(`^## \[(v\d+)\.(\d+)\.(\d+)\]`)

// repoRoot は go.mod を上方向に探索してリポジトリルートを返す。
func repoRoot(t *testing.T) string {
	t.Helper()
	dir, err := os.Getwd()
	if err != nil {
		t.Fatalf("getwd: %v", err)
	}
	for {
		if _, err := os.Stat(filepath.Join(dir, "go.mod")); err == nil {
			return dir
		}
		parent := filepath.Dir(dir)
		if parent == dir {
			t.Fatal("go.mod not found above test directory")
		}
		dir = parent
	}
}

// changelogBlocks は CHANGELOG.md を `## ` 見出し単位のブロックへ分割する
// (preamble を含む)。
func changelogBlocks(t *testing.T) []string {
	t.Helper()
	data, err := os.ReadFile(filepath.Join(repoRoot(t), "CHANGELOG.md"))
	if err != nil {
		t.Fatalf("read CHANGELOG.md: %v", err)
	}
	var blocks []string
	var cur []string
	flush := func() {
		if len(cur) > 0 {
			blocks = append(blocks, strings.TrimRight(strings.Join(cur, "\n"), "\n"))
		}
	}
	for _, line := range strings.Split(string(data), "\n") {
		if strings.HasPrefix(line, "## ") {
			flush()
			cur = []string{line}
			continue
		}
		cur = append(cur, line)
	}
	flush()
	return blocks
}

type semver struct{ major, minor, patch int }

func parseSemver(t *testing.T, m []string) semver {
	t.Helper()
	major, _ := strconv.Atoi(strings.TrimPrefix(m[1], "v"))
	minor, _ := strconv.Atoi(m[2])
	patch, _ := strconv.Atoi(m[3])
	return semver{major, minor, patch}
}

func less(a, b semver) bool {
	if a.major != b.major {
		return a.major < b.major
	}
	if a.minor != b.minor {
		return a.minor < b.minor
	}
	return a.patch < b.patch
}

func TestChangelogVersionsUniqueAndDescending(t *testing.T) {
	blocks := changelogBlocks(t)
	seen := map[string]int{}
	var prev *semver
	first := true
	for _, b := range blocks {
		head := b
		if i := strings.IndexByte(b, '\n'); i >= 0 {
			head = b[:i]
		}
		m := versionHeaderRe.FindStringSubmatch(head)
		if m == nil {
			continue
		}
		ver := m[1] + "." + m[2] + "." + m[3]
		seen[ver]++
		if seen[ver] > 1 {
			t.Errorf("duplicate version header %s (appears %d times); CHANGELOG must list each version once", ver, seen[ver])
		}
		v := parseSemver(t, m)
		if !first && !less(v, *prev) {
			t.Errorf("version %s is not strictly below the previous entry %v; entries must be in descending order", ver, *prev)
		}
		prev = &v
		first = false
	}
	if len(seen) == 0 {
		t.Fatal("no version headers found in CHANGELOG.md")
	}
}

func TestChangelogNoByteIdenticalBlocks(t *testing.T) {
	blocks := changelogBlocks(t)
	byContent := map[string]string{}
	for _, b := range blocks {
		head := b
		if i := strings.IndexByte(b, '\n'); i >= 0 {
			head = b[:i]
		}
		if prev, ok := byContent[b]; ok {
			t.Errorf("byte-identical duplicate block detected (%q and %q); collapse duplicates", prev, head)
			continue
		}
		byContent[b] = head
	}
}
