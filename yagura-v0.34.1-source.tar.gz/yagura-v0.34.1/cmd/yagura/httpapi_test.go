package main

import (
	"bytes"
	"context"
	"encoding/json"
	"io"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"

	"github.com/shizukutanaka/yagura/internal/ghaaudit"
	"github.com/shizukutanaka/yagura/internal/github"
	"github.com/shizukutanaka/yagura/internal/pindrift"
	"github.com/shizukutanaka/yagura/internal/sbom"
)

func newTestHTTPMux(t *testing.T, authToken string) *http.ServeMux {
	t.Helper()
	mux := http.NewServeMux()
	registerHTTPAPI(mux, httpAPIDeps{
		Sbom:           sbom.New(),
		Ghaaudit:       ghaaudit.New(),
		PinDrift:       pindrift.New(&nullGH{}),
		MainModulePath: "github.com/shizukutanaka/yagura",
		MainVersion:    "0.11.0-test",
		AuthToken:      authToken,
	})
	return mux
}

// ─── GET /sbom ───────────────────────────────────────────────

func TestHTTP_GETSBOM_NoAuth(t *testing.T) {
	mux := newTestHTTPMux(t, "")
	srv := httptest.NewServer(mux)
	defer srv.Close()

	resp, err := http.Get(srv.URL + "/sbom")
	if err != nil {
		t.Fatal(err)
	}
	defer resp.Body.Close()
	if resp.StatusCode != http.StatusOK {
		t.Fatalf("status %d", resp.StatusCode)
	}
	body, _ := io.ReadAll(resp.Body)
	var bom map[string]any
	if err := json.Unmarshal(body, &bom); err != nil {
		t.Fatalf("invalid JSON: %v", err)
	}
	if bom["bomFormat"] != "CycloneDX" {
		t.Errorf("bomFormat: %v", bom["bomFormat"])
	}
	if bom["specVersion"] != "1.5" {
		t.Errorf("specVersion: %v", bom["specVersion"])
	}
}

func TestHTTP_GETSBOM_SummaryOnly(t *testing.T) {
	mux := newTestHTTPMux(t, "")
	srv := httptest.NewServer(mux)
	defer srv.Close()

	resp, err := http.Get(srv.URL + "/sbom?summary_only=1")
	if err != nil {
		t.Fatal(err)
	}
	defer resp.Body.Close()
	body, _ := io.ReadAll(resp.Body)
	var s map[string]any
	_ = json.Unmarshal(body, &s)
	if s["spec_version"] != "1.5" {
		t.Errorf("expected summary form, got: %s", body)
	}
}

func TestHTTP_GETSBOM_WrongMethod(t *testing.T) {
	mux := newTestHTTPMux(t, "")
	srv := httptest.NewServer(mux)
	defer srv.Close()
	resp, err := http.Post(srv.URL+"/sbom", "application/json", strings.NewReader("{}"))
	if err != nil {
		t.Fatal(err)
	}
	defer resp.Body.Close()
	if resp.StatusCode != http.StatusMethodNotAllowed {
		t.Errorf("expected 405, got %d", resp.StatusCode)
	}
	// GET 専用 endpoint なので Allow は GET のみ(POST は含まない)。
	if got := resp.Header.Get("Allow"); got != http.MethodGet {
		t.Errorf("expected Allow: GET, got %q", got)
	}
}

func TestQueryTrue(t *testing.T) {
	cases := map[string]bool{
		"1": true, "true": true, "yes": true, "on": true, "TRUE": true,
		"0": false, "false": false, "": false, "nope": false,
	}
	for v, want := range cases {
		r := httptest.NewRequest(http.MethodGet, "/x?flag="+v, http.NoBody)
		if got := queryTrue(r, "flag"); got != want {
			t.Errorf("queryTrue(flag=%q) = %v, want %v", v, got, want)
		}
	}
}

// ─── Auth ────────────────────────────────────────────────────

func TestHTTP_Auth_Required(t *testing.T) {
	mux := newTestHTTPMux(t, "secret-token")
	srv := httptest.NewServer(mux)
	defer srv.Close()

	// no auth → 401
	resp, err := http.Get(srv.URL + "/sbom")
	if err != nil {
		t.Fatal(err)
	}
	defer resp.Body.Close()
	if resp.StatusCode != http.StatusUnauthorized {
		t.Errorf("expected 401, got %d", resp.StatusCode)
	}

	// wrong token → 401
	req, _ := http.NewRequest(http.MethodGet, srv.URL+"/sbom", http.NoBody)
	req.Header.Set("Authorization", "Bearer wrong-token")
	resp2, err := http.DefaultClient.Do(req)
	if err != nil {
		t.Fatal(err)
	}
	defer resp2.Body.Close()
	if resp2.StatusCode != http.StatusUnauthorized {
		t.Errorf("expected 401, got %d", resp2.StatusCode)
	}

	// correct token → 200
	req3, _ := http.NewRequest(http.MethodGet, srv.URL+"/sbom", http.NoBody)
	req3.Header.Set("Authorization", "Bearer secret-token")
	resp3, err := http.DefaultClient.Do(req3)
	if err != nil {
		t.Fatal(err)
	}
	defer resp3.Body.Close()
	if resp3.StatusCode != http.StatusOK {
		t.Errorf("expected 200, got %d", resp3.StatusCode)
	}
}

// ─── POST /gha-audit ─────────────────────────────────────────

func TestHTTP_POSTGhaAudit(t *testing.T) {
	mux := newTestHTTPMux(t, "")
	srv := httptest.NewServer(mux)
	defer srv.Close()

	body := map[string]any{
		"files": map[string]string{
			"vuln.yml": `on:
  pull_request_target:
jobs:
  x:
    steps:
      - uses: tj-actions/changed-files@main
`,
		},
	}
	b, _ := json.Marshal(body)
	resp, err := http.Post(srv.URL+"/gha-audit", "application/json", bytes.NewReader(b))
	if err != nil {
		t.Fatal(err)
	}
	defer resp.Body.Close()
	if resp.StatusCode != http.StatusOK {
		buf, _ := io.ReadAll(resp.Body)
		t.Fatalf("status %d: %s", resp.StatusCode, buf)
	}
	out, _ := io.ReadAll(resp.Body)
	if !strings.Contains(string(out), "dangerous-trigger") {
		t.Errorf("expected dangerous-trigger finding: %s", out)
	}
	if !strings.Contains(string(out), "mutable-ref") {
		t.Errorf("expected mutable-ref finding: %s", out)
	}
}

func TestHTTP_POSTGhaAudit_EmptyBody(t *testing.T) {
	mux := newTestHTTPMux(t, "")
	srv := httptest.NewServer(mux)
	defer srv.Close()
	resp, err := http.Post(srv.URL+"/gha-audit", "application/json", strings.NewReader(`{"files":{}}`))
	if err != nil {
		t.Fatal(err)
	}
	defer resp.Body.Close()
	if resp.StatusCode != http.StatusBadRequest {
		t.Errorf("expected 400, got %d", resp.StatusCode)
	}
}

func TestHTTP_POSTGhaAudit_WrongContentType(t *testing.T) {
	mux := newTestHTTPMux(t, "")
	srv := httptest.NewServer(mux)
	defer srv.Close()
	resp, err := http.Post(srv.URL+"/gha-audit", "text/plain", strings.NewReader(`{"files":{}}`))
	if err != nil {
		t.Fatal(err)
	}
	defer resp.Body.Close()
	if resp.StatusCode != http.StatusBadRequest {
		t.Errorf("expected 400 for wrong content-type, got %d", resp.StatusCode)
	}
}

// ─── POST /pin-drift ─────────────────────────────────────────

func TestHTTP_POSTPinDrift_NoPins(t *testing.T) {
	mux := newTestHTTPMux(t, "")
	srv := httptest.NewServer(mux)
	defer srv.Close()
	body := map[string]any{
		"files": map[string]string{
			"x.yml": "on: [push]\n", // no uses:
		},
	}
	b, _ := json.Marshal(body)
	resp, err := http.Post(srv.URL+"/pin-drift", "application/json", bytes.NewReader(b))
	if err != nil {
		t.Fatal(err)
	}
	defer resp.Body.Close()
	if resp.StatusCode != http.StatusOK {
		t.Fatalf("status %d", resp.StatusCode)
	}
	out, _ := io.ReadAll(resp.Body)
	if !strings.Contains(string(out), "no SHA-pinned") {
		t.Errorf("expected 'no SHA-pinned' note: %s", out)
	}
}

func TestHTTP_POSTPinDrift_405_GET(t *testing.T) {
	mux := newTestHTTPMux(t, "")
	srv := httptest.NewServer(mux)
	defer srv.Close()
	resp, err := http.Get(srv.URL + "/pin-drift")
	if err != nil {
		t.Fatal(err)
	}
	defer resp.Body.Close()
	if resp.StatusCode != http.StatusMethodNotAllowed {
		t.Errorf("expected 405, got %d", resp.StatusCode)
	}
}

// nullGH は pindrift 用の no-op mock(全 SHA を 404 扱いで MISSING に)
type nullGH struct{}

func (n *nullGH) GetCommit(ctx context.Context, owner, repo, sha string) (*github.CommitInfo, error) {
	return nil, github.ErrNotFound
}
func (n *nullGH) GetTagSHA(ctx context.Context, owner, repo, tag string) (string, error) {
	return "", nil
}
