package dashboard

import (
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
	"time"

	"github.com/shizukutanaka/yagura/internal/quotamonitor"
)

// buildSparklinePath: <2 サンプルは空、>=2 で polyline 文字列、範囲外は clamp。
func TestBuildSparklinePath(t *testing.T) {
	if buildSparklinePath(nil) != "" {
		t.Error("nil samples should give empty path")
	}
	if buildSparklinePath([]quotamonitor.ReportEvent{{RemainingPercent: 50}}) != "" {
		t.Error("single sample should give empty path")
	}

	got := buildSparklinePath([]quotamonitor.ReportEvent{
		{RemainingPercent: 100}, // y=0 (top)
		{RemainingPercent: 0},   // y=30 (bottom)
	})
	// 2 点 → x は 0 と 100、y は 0.0 と 30.0。
	if got != "0.0,0.0 100.0,30.0" {
		t.Fatalf("path = %q, want \"0.0,0.0 100.0,30.0\"", got)
	}

	// 範囲外 (負/100超) は [0,30] に clamp される。
	clamped := buildSparklinePath([]quotamonitor.ReportEvent{
		{RemainingPercent: 200}, // y<0 → 0
		{RemainingPercent: -50}, // y>30 → 30
	})
	if !strings.Contains(clamped, "0.0,0.0") || !strings.HasSuffix(clamped, ",30.0") {
		t.Errorf("clamped path = %q", clamped)
	}
}

// SetAgentStatusProvider + ServeHTTP の agent panel 分岐を実 Monitor で網羅。
func TestServeHTTP_WithAgentPanel(t *testing.T) {
	h, _ := setupHandler(t)

	mon := quotamonitor.New()
	// 2 サンプル投入で usage history(sparkline)が出る。
	if err := mon.Report(quotamonitor.AgentClaudeCode, 90, "auto", time.Time{}, time.Time{}); err != nil {
		t.Fatal(err)
	}
	if err := mon.Report(quotamonitor.AgentClaudeCode, 80, "auto", time.Time{}, time.Time{}); err != nil {
		t.Fatal(err)
	}
	h.SetAgentStatusProvider(mon)

	req := httptest.NewRequest(http.MethodGet, "/dashboard", nil)
	w := httptest.NewRecorder()
	h.ServeHTTP(w, req)

	if w.Code != http.StatusOK {
		t.Fatalf("status = %d, want 200", w.Code)
	}
	body := w.Body.String()
	if !strings.Contains(strings.ToLower(body), "claude") {
		t.Error("agent panel should mention the reporting agent")
	}

	// nil で panel を無効化しても 200 で描画される。
	h.SetAgentStatusProvider(nil)
	w2 := httptest.NewRecorder()
	h.ServeHTTP(w2, httptest.NewRequest(http.MethodGet, "/dashboard", nil))
	if w2.Code != http.StatusOK {
		t.Errorf("status after disabling panel = %d, want 200", w2.Code)
	}
}
