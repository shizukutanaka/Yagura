package harness

import (
	"encoding/json"
	"strings"
	"testing"
)

// ─── RecommendForLanguage ───────────────────────────────────

func TestRecommendForLanguage_Go(t *testing.T) {
	r := RecommendForLanguage("go")
	if r.Language != "go" {
		t.Errorf("language: got %q, want go", r.Language)
	}
	if !strings.Contains(r.ClaudeMd, "Zero external dependencies") {
		t.Error("Go CLAUDE.md should mention zero-dep rule")
	}
	if !strings.Contains(r.SettingsJSON, "gofmt") {
		t.Error("Go settings should have gofmt hook")
	}
	if len(r.Skills) == 0 || len(r.Subagents) == 0 {
		t.Error("Go should have skills + subagents")
	}
}

func TestRecommendForLanguage_TypeScript(t *testing.T) {
	r := RecommendForLanguage("typescript")
	if !strings.Contains(r.ClaudeMd, "strict") {
		t.Error("TS should mention strict mode")
	}
	if !strings.Contains(r.SettingsJSON, "tsc") {
		t.Error("TS settings should have tsc hook")
	}
}

func TestRecommendForLanguage_Python(t *testing.T) {
	r := RecommendForLanguage("python")
	if !strings.Contains(r.ClaudeMd, "mypy") {
		t.Error("Python should mention mypy")
	}
}

func TestRecommendForLanguage_Rust(t *testing.T) {
	r := RecommendForLanguage("rust")
	if !strings.Contains(r.SettingsJSON, "clippy") {
		t.Error("Rust should have clippy hook")
	}
}

func TestRecommendForLanguage_CaseInsensitive(t *testing.T) {
	r1 := RecommendForLanguage("Go")
	r2 := RecommendForLanguage("GOLANG")
	if r1.Language != r2.Language {
		t.Error("case should not matter")
	}
}

func TestRecommendForLanguage_Generic(t *testing.T) {
	r := RecommendForLanguage("brainfuck")
	if r.Language != "brainfuck" {
		t.Errorf("generic should preserve lang label, got %q", r.Language)
	}
	// 最低限の structure があれば OK
	if r.ClaudeMd == "" || r.SettingsJSON == "" {
		t.Error("generic should still produce non-empty templates")
	}
}

func TestRecommendForLanguage_Serializable(t *testing.T) {
	// JSON marshal で MCP 経由送出可能なことを確認
	r := RecommendForLanguage("go")
	b, err := json.Marshal(r)
	if err != nil {
		t.Fatalf("marshal: %v", err)
	}
	if len(b) < 200 {
		t.Errorf("payload too small: %d bytes", len(b))
	}
}

// ─── AuditSkill ─────────────────────────────────────────────

func TestAuditSkill_Pristine(t *testing.T) {
	// 全部正解の skill
	content := `---
name: go-test
description: Use when the user asks to add tests or fix failing tests in Go code.
---

# Go Test Skill

## Patterns

Use t.TempDir for filesystem isolation.

## Gotchas

- ` + "`time.Now()`" + ` in tests must go through NowFn hook
- ` + "`go test ./...`" + ` without -count=1 uses cache

References in references/test-patterns.md.
`
	r := AuditSkill(content)
	if r.Score < 90 {
		t.Errorf("pristine skill: score=%d, want ≥90, issues=%v", r.Score, r.Issues)
	}
	if !r.IsTriggerFormat || !r.HasGotchasSection {
		t.Errorf("flags wrong: %+v", r)
	}
}

func TestAuditSkill_VagueDescription(t *testing.T) {
	content := `---
name: helper
description: A helpful skill for various coding tasks.
---

# Helper

Does things.
`
	r := AuditSkill(content)
	if !r.HasVagueKeywords {
		t.Error("should detect 'helpful' and 'various'")
	}
	if r.IsTriggerFormat {
		t.Error("'A helpful skill' is not trigger format")
	}
	if r.Score >= 70 {
		t.Errorf("vague skill should score low, got %d", r.Score)
	}
}

func TestAuditSkill_NoFrontmatter(t *testing.T) {
	content := `# Just a markdown
no frontmatter at all.`
	r := AuditSkill(content)
	if r.HasFrontmatter {
		t.Error("should detect missing frontmatter")
	}
	if r.Score >= 70 {
		t.Errorf("no-frontmatter skill: score=%d, want <70", r.Score)
	}
}

func TestAuditSkill_LongDescription(t *testing.T) {
	longDesc := "Use when " + strings.Repeat("very long detail ", 100) // ~1700 chars
	content := "---\nname: x\ndescription: " + longDesc + "\n---\n\n## Gotchas\n- thing"
	r := AuditSkill(content)
	if r.DescriptionLen <= 1024 {
		t.Errorf("test setup: desc should be > 1024, got %d", r.DescriptionLen)
	}
	foundLimit := false
	for _, iss := range r.Issues {
		if strings.Contains(iss, "1024") {
			foundLimit = true
		}
	}
	if !foundLimit {
		t.Error("should report 1024 char limit issue")
	}
}

func TestAuditSkill_MissingGotchas(t *testing.T) {
	content := `---
name: x
description: Use when working with X.
---

# X

` + strings.Repeat("Some content here. ", 30)
	r := AuditSkill(content)
	if r.HasGotchasSection {
		t.Error("should detect missing gotchas")
	}
}

// ─── AuditSubagent ──────────────────────────────────────────

func TestAuditSubagent_Pristine(t *testing.T) {
	content := `---
name: code-reviewer
description: Expert Go code reviewer. Use proactively after any commit.
tools: Read, Grep, Glob
model: sonnet
---

You are a senior Go reviewer. Focus on race conditions and error handling.
For each issue, cite line, explain why, suggest fix. Don't modify files.
`
	r := AuditSubagent(content)
	if r.Score < 90 {
		t.Errorf("pristine subagent: score=%d, issues=%v", r.Score, r.Issues)
	}
	if !r.IsSystemPromptStyle {
		t.Error("'You are a senior' should be system-prompt style")
	}
	if !r.HasToolsAllowlist {
		t.Error("'tools: Read, Grep, Glob' present")
	}
	if !r.IsActionOriented {
		t.Error("'Use proactively' should be action-oriented")
	}
}

func TestAuditSubagent_UserPromptStyle(t *testing.T) {
	// #1 misunderstanding: body が user prompt 風
	content := `---
name: reviewer
description: Reviews code.
tools: Read
---

Please review this code carefully and tell me what's wrong with it.
`
	r := AuditSubagent(content)
	if r.IsSystemPromptStyle {
		t.Error("'Please review' is user-prompt style; should fail check")
	}
	foundIssue := false
	for _, iss := range r.Issues {
		if strings.Contains(iss, "system-prompt") {
			foundIssue = true
		}
	}
	if !foundIssue {
		t.Errorf("expected system-prompt issue, got: %v", r.Issues)
	}
}

func TestAuditSubagent_NoToolsRestriction(t *testing.T) {
	content := `---
name: dangerous
description: Use proactively for everything.
---

You are an all-powerful agent with no tool restrictions.
`
	r := AuditSubagent(content)
	if r.HasToolsAllowlist {
		t.Error("should detect missing tools allowlist")
	}
	// Score should be reduced
	if r.Score >= 90 {
		t.Errorf("no-tools subagent: score=%d, expected reduction", r.Score)
	}
}

func TestAuditSubagent_NotActionOriented(t *testing.T) {
	content := `---
name: thing
description: A thing for stuff.
tools: Read
---

You are a thing.
`
	r := AuditSubagent(content)
	if r.IsActionOriented {
		t.Error("'A thing for stuff' not action-oriented")
	}
}

// ─── splitFrontmatterAndBody helper ─────────────────────────

func TestSplitFrontmatter_Basic(t *testing.T) {
	c := "---\nname: test\ndescription: hello\n---\nbody here"
	name, desc, body := splitFrontmatterAndBody(c)
	if name != "test" || desc != "hello" || !strings.Contains(body, "body here") {
		t.Errorf("parse failed: name=%q desc=%q body=%q", name, desc, body)
	}
}

func TestSplitFrontmatter_NoFrontmatter(t *testing.T) {
	c := "# Just markdown\nno frontmatter"
	name, desc, _ := splitFrontmatterAndBody(c)
	if name != "" || desc != "" {
		t.Error("should return empties when no frontmatter")
	}
}

func TestSplitFrontmatter_QuotedValues(t *testing.T) {
	c := `---
name: "quoted-name"
description: 'single quoted'
---
body`
	name, desc, _ := splitFrontmatterAndBody(c)
	if name != "quoted-name" || desc != "single quoted" {
		t.Errorf("quote stripping failed: name=%q desc=%q", name, desc)
	}
}
