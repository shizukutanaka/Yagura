// tools_quality.go: cortex flywheel ② Review の quality 系 tools
// (quality_check / ai_verify / test_audit)。tools.go から分割(挙動非変更)。
package mcp

import (
	"context"
	"encoding/json"
	"os"
	"path/filepath"
	"strings"

	"github.com/shizukutanaka/yagura/internal/aiverify"
	"github.com/shizukutanaka/yagura/internal/qualitycheck"
	"github.com/shizukutanaka/yagura/internal/testcoverage"
)

// ─── yagura_quality_check (v0.19.0) ───────────────────────────
//
// cortex (aircloset 2026/05) 翻訳: 「逸脱を物理的に潰す」品質ゲート。
// `as any` / @ts-ignore / eslint-disable / TODO / FIXME 等を line-based
// regex で検出し、severity 別に集計する。CI で `prohibited > 0` なら fail
// するのが想定運用。

func buildQualityCheckTool(d Deps, cache qualitycheck.CacheLike) *Tool {
	return &Tool{
		Name:        "yagura_quality_check",
		Description: "[G] Code lint: as any, ts-ignore, TODO. 3 severity tiers.",
		InputSchema: map[string]any{
			"type": "object",
			"properties": map[string]any{
				"files":        map[string]any{"type": "object"},
				"text":         map[string]any{"type": "string"},
				"language":     map[string]any{"type": "string"},
				"summary_only": map[string]any{"type": "boolean"},
			},
		},
		Handler: func(ctx context.Context, args json.RawMessage) (any, error) {
			var in struct {
				Files       map[string]string `json:"files"`
				Text        string            `json:"text"`
				Language    string            `json:"language"`
				SummaryOnly bool              `json:"summary_only"`
			}
			if err := json.Unmarshal(args, &in); err != nil {
				return nil, &ToolError{Code: "invalid_input", Cause: err}
			}
			if len(in.Files) == 0 && in.Text == "" {
				return nil, &ToolError{Code: "invalid_input",
					Message: "either 'files' or 'text' is required"}
			}
			rules := qualitycheck.DefaultRules()

			if in.Text != "" {
				findings := qualitycheck.ScanText("<input>", in.Text, in.Language, rules)
				res := qualitycheck.Result{
					FilesScanned: 1,
					Findings:     findings,
					BySeverity:   map[qualitycheck.Severity]int{},
					ByRule:       map[string]int{},
				}
				for _, f := range findings {
					res.BySeverity[f.Severity]++
					res.ByRule[f.RuleID]++
				}
				return formatQualityResult(res, in.SummaryOnly), nil
			}
			// v0.23.0: cache 統合(content-hash で同 content の再 scan を skip)
			res := qualitycheck.ScanFilesCached(in.Files, rules, cache)
			return formatQualityResult(res, in.SummaryOnly), nil
		},
	}
}

// formatQualityResult is MCP-friendly output formatter.
func formatQualityResult(res qualitycheck.Result, summaryOnly bool) any {
	out := map[string]any{
		"files_scanned":  res.FilesScanned,
		"total_lines":    res.TotalLines,
		"finding_count":  len(res.Findings),
		"by_severity":    res.BySeverity,
		"by_rule":        res.ByRule,
		"has_prohibited": res.HasProhibited(),
		"summary":        res.Summary(),
	}
	if !summaryOnly {
		out["findings"] = res.Findings
		if len(res.ByFile) > 0 {
			out["by_file"] = res.ByFile
		}
	}
	return out
}

// scanProjectAICode は LocalPath 配下の主要 source file を aiverify で scan する。
//
// 完全 walk は重いので、上位 N file (size 制限あり) のみ。
// 言語: Go / Python / TS / JS / Rust。
// 各 file 最大 256KB、合計 64 file まで(暴走防止)。
func scanProjectAICode(localPath string) aiverify.Result {
	const maxFiles = 64
	const maxFileSize = 256 * 1024

	files := map[string]string{}
	walked := 0
	_ = filepath.Walk(localPath, func(path string, info os.FileInfo, err error) error {
		if err != nil || info == nil || info.IsDir() {
			return nil
		}
		if walked >= maxFiles {
			return filepath.SkipDir
		}
		// 隠しディレクトリと vendor / node_modules を skip
		base := filepath.Base(path)
		if strings.HasPrefix(base, ".") || base == "vendor" || base == "node_modules" {
			return nil
		}
		ext := filepath.Ext(path)
		switch ext {
		case ".go", ".py", ".ts", ".tsx", ".js", ".jsx", ".rs":
		default:
			return nil
		}
		if info.Size() > maxFileSize {
			return nil
		}
		data, rerr := os.ReadFile(path)
		if rerr != nil {
			return nil
		}
		rel, _ := filepath.Rel(localPath, path)
		files[rel] = string(data)
		walked++
		return nil
	})
	if len(files) == 0 {
		return aiverify.Result{}
	}
	return aiverify.Scan(files)
}

// ─── yagura_ai_verify (v0.25.0) ──────────────────────────────
//
// AI-generated コードの risk pattern を検出する。m's harness G0.7 INVARIANT
// 「AI出力検証義務」への直接対応。
//
// Veracode 2025: 45% of AI code ships OWASP Top-10
// Apiiro Fortune 50: 322% privilege-escalation paths, 40% secrets exposure
// CodeRabbit: 1.7× issue multiplier — AI zone 内 finding は score 2x。

func buildAIVerifyTool(d Deps, cache aiverify.CacheLike) *Tool {
	return &Tool{
		Name:        "yagura_ai_verify",
		Description: "[G] AI code risk audit. 6 categories: auth/billing/data/external/crypto/secret. 2x multiplier inside AI-marker zones.",
		InputSchema: map[string]any{
			"type": "object",
			"properties": map[string]any{
				"files":        map[string]any{"type": "object"},
				"text":         map[string]any{"type": "string"},
				"path":         map[string]any{"type": "string"},
				"summary_only": map[string]any{"type": "boolean"},
			},
		},
		Handler: func(ctx context.Context, args json.RawMessage) (any, error) {
			var in struct {
				Files       map[string]string `json:"files"`
				Text        string            `json:"text"`
				Path        string            `json:"path"`
				SummaryOnly bool              `json:"summary_only"`
			}
			if err := json.Unmarshal(args, &in); err != nil {
				return nil, &ToolError{Code: "invalid_input", Cause: err}
			}
			if len(in.Files) == 0 && in.Text == "" {
				return nil, &ToolError{Code: "invalid_input",
					Message: "either 'files' or 'text' is required"}
			}

			var res aiverify.Result
			if in.Text != "" {
				path := in.Path
				if path == "" {
					path = "<input>"
				}
				res = aiverify.Scan(map[string]string{path: in.Text})
			} else if cache != nil {
				res = aiverify.ScanCached(in.Files, cache)
			} else {
				res = aiverify.Scan(in.Files)
			}

			// v0.26.0: testcoverage と結合し untested AI 生成を flag (+5/file)
			// files が複数与えられた場合のみ意味があるので text mode は skip
			if len(in.Files) > 0 {
				tcRes := testcoverage.Audit(in.Files)
				hasTestMap := make(map[string]bool, len(in.Files))
				// untested ではない source を has_test 認定
				untestedSet := make(map[string]bool, len(tcRes.UntestedFiles))
				for _, p := range tcRes.UntestedFiles {
					untestedSet[p] = true
				}
				for p := range in.Files {
					if testcoverage.IsTestFile(p) {
						continue
					}
					if !untestedSet[p] {
						hasTestMap[p] = true
					}
				}
				res = aiverify.AnnotateUntested(res, in.Files, func(p string) bool {
					return hasTestMap[p]
				})
			}

			return formatAIVerifyResult(res, in.SummaryOnly), nil
		},
	}
}

func formatAIVerifyResult(res aiverify.Result, summaryOnly bool) any {
	out := map[string]any{
		"files_scanned": res.FilesScanned,
		"total_lines":   res.TotalLines,
		"ai_gen_lines":  res.AIGenLines,
		"finding_count": len(res.Findings),
		"risk_score":    res.RiskScore,
		"has_critical":  res.HasCritical,
		"by_severity":   res.BySeverity,
		"by_category":   res.ByCategory,
		"summary":       res.Summary(),
	}
	if len(res.AIGenWithoutTests) > 0 {
		out["ai_gen_without_tests"] = res.AIGenWithoutTests
	}
	if !summaryOnly {
		out["findings"] = res.Findings
	}
	if res.CacheHits > 0 || res.CacheMisses > 0 {
		out["cache_hits"] = res.CacheHits
		out["cache_misses"] = res.CacheMisses
	}
	return out
}

// ─── yagura_test_audit + ai_verify との結合 (v0.26.0) ───────
//
// m's harness G0.7 「テスト通過 + 人間確認が必須」への直接対応。
// language-aware な test file 検出 + AI 生成 untested risk 強化。

func buildTestAuditTool(d Deps) *Tool {
	return &Tool{
		Name:        "yagura_test_audit",
		Description: "[G] Source-test coverage detection. Go/TS/JS/Python/Rust/Java filename + Rust inline #[cfg(test)] + Python doctest.",
		InputSchema: map[string]any{
			"type": "object",
			"properties": map[string]any{
				"files":         map[string]any{"type": "object"},
				"untested_only": map[string]any{"type": "boolean"},
			},
			"required": []string{"files"},
		},
		Handler: func(ctx context.Context, args json.RawMessage) (any, error) {
			var in struct {
				Files        map[string]string `json:"files"`
				UntestedOnly bool              `json:"untested_only"`
			}
			if err := json.Unmarshal(args, &in); err != nil {
				return nil, &ToolError{Code: "invalid_input", Cause: err}
			}
			if len(in.Files) == 0 {
				return nil, &ToolError{Code: "invalid_input", Message: "files required"}
			}
			res := testcoverage.Audit(in.Files)
			out := map[string]any{
				"files_scanned":     res.FilesScanned,
				"source_files":      res.SourceFiles,
				"test_files":        res.TestFiles,
				"sources_with_test": res.SourcesWithTest,
				"sources_no_test":   res.SourcesNoTest,
				"coverage_ratio":    res.CoverageRatio,
				"untested_files":    res.UntestedFiles,
				"by_language":       res.ByLanguage,
			}
			return out, nil
		},
	}
}
