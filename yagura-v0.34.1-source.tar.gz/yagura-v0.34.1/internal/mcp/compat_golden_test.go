package mcp

import (
	"bytes"
	"encoding/json"
	"flag"
	"os"
	"path/filepath"
	"sort"
	"testing"
)

// updateGolden regenerates the API-contract golden file instead of asserting.
//
//	go test ./internal/mcp -run TestToolsListContract -update-golden
var updateGolden = flag.Bool("update-golden", false, "update the tools/list contract golden file")

// goldenContractPath is the checked-in snapshot of the MCP tools/list contract.
const goldenContractPath = "testdata/tools_list_contract.golden.json"

// contractEntry is the *stable* surface of a tool: its name and input schema.
//
// The human-facing Description is intentionally excluded — prose may change
// freely without breaking clients, whereas the name and input schema are the
// wire contract. This golden test backs the v1.0 API-stability gate
// (see docs/adr/0007): any rename or schema change must be a deliberate,
// reviewed update to the golden file, surfacing breaking changes in PR review.
type contractEntry struct {
	Name        string `json:"name"`
	InputSchema any    `json:"inputSchema"`
}

// canonicalContract drives the live server with tools/list and returns the
// indented, name-sorted contract JSON.
func canonicalContract(t *testing.T) []byte {
	t.Helper()
	s, _ := newServerForTest(t, "")
	w := postJSON(t, s, `{"jsonrpc":"2.0","id":1,"method":"tools/list"}`, "")
	if w.Code != 200 {
		t.Fatalf("tools/list status = %d, want 200", w.Code)
	}
	var resp struct {
		Result struct {
			Tools []contractEntry `json:"tools"`
		} `json:"result"`
	}
	if err := json.Unmarshal(w.Body.Bytes(), &resp); err != nil {
		t.Fatalf("decode tools/list: %v", err)
	}
	tools := resp.Result.Tools
	if len(tools) == 0 {
		t.Fatal("tools/list returned no tools")
	}
	sort.Slice(tools, func(i, j int) bool { return tools[i].Name < tools[j].Name })

	// Re-marshal through a generic value so map keys are emitted in Go's
	// deterministic (sorted) order, making the golden stable.
	canon, err := json.MarshalIndent(tools, "", "  ")
	if err != nil {
		t.Fatalf("marshal contract: %v", err)
	}
	var generic any
	if err := json.Unmarshal(canon, &generic); err != nil {
		t.Fatalf("normalize contract: %v", err)
	}
	out, err := json.MarshalIndent(generic, "", "  ")
	if err != nil {
		t.Fatalf("marshal normalized contract: %v", err)
	}
	return append(out, '\n')
}

// TestToolsListContract pins the MCP tools/list wire contract (names + input
// schemas) against a checked-in golden file. Run with -update-golden to accept
// an intentional change.
func TestToolsListContract(t *testing.T) {
	got := canonicalContract(t)

	if *updateGolden {
		if err := os.MkdirAll(filepath.Dir(goldenContractPath), 0o755); err != nil {
			t.Fatal(err)
		}
		if err := os.WriteFile(goldenContractPath, got, 0o644); err != nil {
			t.Fatal(err)
		}
		t.Logf("updated %s (%d bytes)", goldenContractPath, len(got))
		return
	}

	want, err := os.ReadFile(goldenContractPath)
	if err != nil {
		t.Fatalf("read golden (run with -update-golden to create): %v", err)
	}
	if !bytes.Equal(got, want) {
		t.Errorf("MCP tools/list contract drifted from %s.\n"+
			"If this change is intentional (a deliberate, semver-aware API change),\n"+
			"regenerate with: go test ./internal/mcp -run TestToolsListContract -update-golden",
			goldenContractPath)
	}
}
