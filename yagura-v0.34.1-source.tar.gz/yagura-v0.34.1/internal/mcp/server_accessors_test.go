package mcp

import (
	"path/filepath"
	"testing"

	"github.com/shizukutanaka/yagura/internal/alertfix"
	"github.com/shizukutanaka/yagura/internal/project"
)

// ToolStats の平均は Calls=0 で 0、それ以外は byte/Calls。
func TestToolStatsAverages(t *testing.T) {
	zero := &ToolStats{}
	if zero.AvgReqBytes() != 0 || zero.AvgRespBytes() != 0 {
		t.Errorf("zero calls should give 0 averages")
	}
	st := &ToolStats{Calls: 2, RequestBytes: 10, ResponseBytes: 30}
	if st.AvgReqBytes() != 5 {
		t.Errorf("AvgReqBytes = %v, want 5", st.AvgReqBytes())
	}
	if st.AvgRespBytes() != 15 {
		t.Errorf("AvgRespBytes = %v, want 15", st.AvgRespBytes())
	}
}

// Cache / CacheStats / recordStats / AllToolStats の基本動作。
func TestServerCacheAndStats(t *testing.T) {
	s := New("", nil)
	if s.Cache() == nil {
		t.Fatal("Cache() should be non-nil by default")
	}
	// 新規 cache の統計はゼロ。
	if cs := s.CacheStats(); cs.Hits != 0 || cs.Misses != 0 {
		t.Errorf("fresh CacheStats not zero: %+v", cs)
	}

	if len(s.AllToolStats()) != 0 {
		t.Errorf("fresh server should have no tool stats")
	}
	s.recordStats("yagura_x", 100, 200, false, fixedNow)
	s.recordStats("yagura_x", 50, 50, true, fixedNow)
	all := s.AllToolStats()
	if len(all) != 1 {
		t.Fatalf("AllToolStats len = %d, want 1", len(all))
	}
	got := all[0]
	if got.Name != "yagura_x" || got.Calls != 2 || got.RequestBytes != 150 || got.ErrorCount != 1 {
		t.Errorf("stats snapshot wrong: %+v", got)
	}
}

// audit / alertStore / hookReceiver の setter/getter (nil 許容)。
func TestServerOptionalSinks(t *testing.T) {
	s := New("", nil)

	s.SetAudit(nil) // nil は許容
	s.SetHookReceiver(nil)
	if s.HookReceiver() != nil {
		t.Error("HookReceiver should be nil")
	}

	if s.AlertStore() != nil {
		t.Error("AlertStore should start nil")
	}
	store, err := alertfix.NewStore(filepath.Join(t.TempDir(), "alerts.json"))
	if err != nil {
		t.Fatalf("NewStore: %v", err)
	}
	s.SetAlertStore(store)
	if s.AlertStore() != store {
		t.Error("AlertStore should return the set store")
	}
	s.SetAlertStore(nil)
	if s.AlertStore() != nil {
		t.Error("AlertStore should be nil after clearing")
	}
}

// toGraphProjects は Slug / DependsOn のみを写す。
func TestToGraphProjects(t *testing.T) {
	in := []*project.Project{
		{Slug: "a", DependsOn: []string{"b"}},
		{Slug: "b"},
	}
	out := toGraphProjects(in)
	if len(out) != 2 {
		t.Fatalf("len = %d, want 2", len(out))
	}
	if out[0].Slug != "a" || len(out[0].DependsOn) != 1 || out[0].DependsOn[0] != "b" {
		t.Errorf("out[0] = %+v", out[0])
	}
	if out[1].Slug != "b" || len(out[1].DependsOn) != 0 {
		t.Errorf("out[1] = %+v", out[1])
	}
}
