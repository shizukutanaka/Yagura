package scanner

import (
	"context"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"strings"
	"sync/atomic"
	"testing"
	"time"

	"github.com/shizukutanaka/yagura/internal/github"
	"github.com/shizukutanaka/yagura/internal/logging"
	"github.com/shizukutanaka/yagura/internal/project"
	"github.com/shizukutanaka/yagura/internal/registry"
)

// fakeGitHub は最小限の GitHub REST API を模す httptest server。
func fakeGitHub(t *testing.T, archived bool, prCount, issuesCount int, conclusion string) *httptest.Server {
	t.Helper()
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch {
		case strings.HasSuffix(r.URL.Path, "/pulls"):
			// per_page=1 + Link header trick
			if prCount > 1 {
				w.Header().Set("Link",
					`<https://api.github.com/repos/o/r/pulls?per_page=1&page=`+itoa(prCount)+`>; rel="last"`)
			}
			items := make([]struct{}, minI(prCount, 1))
			_ = json.NewEncoder(w).Encode(items)
		case strings.HasSuffix(r.URL.Path, "/issues"):
			// issue count via per_page=1 + Link header
			if issuesCount > 1 {
				w.Header().Set("Link",
					`<https://api.github.com/repos/o/r/issues?per_page=1&page=`+itoa(issuesCount)+`>; rel="last"`)
			}
			items := make([]struct{}, minI(issuesCount, 1))
			_ = json.NewEncoder(w).Encode(items)
		case strings.HasSuffix(r.URL.Path, "/releases/latest"):
			_ = json.NewEncoder(w).Encode(map[string]any{
				"tag_name":     "v1.2.3",
				"published_at": time.Now().Format(time.RFC3339),
			})
		case strings.Contains(r.URL.Path, "/actions/runs") || strings.Contains(r.URL.Path, "/check-runs"):
			runs := []map[string]any{}
			if conclusion != "" {
				runs = append(runs, map[string]any{
					"status":      "completed",
					"conclusion":  conclusion,
					"head_branch": "main",
					"updated_at":  time.Now().Format(time.RFC3339),
				})
			}
			_ = json.NewEncoder(w).Encode(map[string]any{
				"total_count":   len(runs),
				"workflow_runs": runs,
				"check_runs":    runs,
			})
		case strings.HasPrefix(r.URL.Path, "/repos/"):
			_ = json.NewEncoder(w).Encode(map[string]any{
				"full_name":         "o/r",
				"description":       "test repo",
				"language":          "Go",
				"open_issues_count": issuesCount,
				"pushed_at":         time.Now().Add(-24 * time.Hour).Format(time.RFC3339),
				"updated_at":        time.Now().Format(time.RFC3339),
				"default_branch":    "main",
				"archived":          archived,
				"disabled":          false,
			})
		default:
			http.NotFound(w, r)
		}
	}))
	return srv
}

func itoa(n int) string {
	if n == 0 {
		return "0"
	}
	digits := []byte{}
	for n > 0 {
		digits = append([]byte{byte('0' + n%10)}, digits...)
		n /= 10
	}
	return string(digits)
}

func minI(a, b int) int {
	if a < b {
		return a
	}
	return b
}

func newTestEnv(t *testing.T, prCount, issuesCount int, conclusion string, archived bool) (*Scanner, *registry.Registry, *httptest.Server) {
	t.Helper()
	srv := fakeGitHub(t, archived, prCount, issuesCount, conclusion)
	gh := github.NewClient(github.Config{
		Token:   "test-token",
		BaseURL: srv.URL,
		Timeout: 5 * time.Second,
	})

	reg, err := registry.New(t.TempDir())
	if err != nil {
		t.Fatal(err)
	}

	s := New(Config{
		Interval: 30 * time.Second,
		GitHub:   gh,
		Registry: reg,
		Logger:   logging.Discard(),
	})
	return s, reg, srv
}

func sampleProj(slug string) *project.Project {
	return &project.Project{
		Slug:        slug,
		DisplayName: slug,
		Repository:  "github.com/o/r",
		Stage:       project.StageActive,
		Priority:    3,
		Notes:       "manual notes",
		Tags:        []string{"manual-tag"},
	}
}

func TestScanner_ScanAll_Empty(t *testing.T) {
	s, _, srv := newTestEnv(t, 0, 0, "", false)
	defer srv.Close()
	s.ScanAll(context.Background())
	// no panic, no projects to scan
}

func TestScanner_ScanProject_UpdatesAutoFields(t *testing.T) {
	s, reg, srv := newTestEnv(t, 3, 7, "success", false)
	defer srv.Close()

	if err := reg.Add(sampleProj("p1")); err != nil {
		t.Fatal(err)
	}
	s.ScanAll(context.Background())

	got, err := reg.Get("p1")
	if err != nil {
		t.Fatal(err)
	}
	if got.LatestVersion == "" {
		t.Errorf("LatestVersion not updated: %q", got.LatestVersion)
	}
	if got.CIStatus == "" || got.CIStatus == project.CIStatusUnknown {
		t.Errorf("CIStatus not updated: %q", got.CIStatus)
	}
}

func TestScanner_ScanProject_PreservesManualFields(t *testing.T) {
	s, reg, srv := newTestEnv(t, 1, 1, "success", false)
	defer srv.Close()

	if err := reg.Add(sampleProj("preserve")); err != nil {
		t.Fatal(err)
	}
	s.ScanAll(context.Background())

	got, _ := reg.Get("preserve")
	if got.Priority != 3 {
		t.Errorf("manual Priority overwritten: %d", got.Priority)
	}
	if got.Notes != "manual notes" {
		t.Errorf("manual Notes overwritten: %q", got.Notes)
	}
	if len(got.Tags) != 1 || got.Tags[0] != "manual-tag" {
		t.Errorf("manual Tags overwritten: %v", got.Tags)
	}
}

func TestScanner_FailingCI(t *testing.T) {
	s, reg, srv := newTestEnv(t, 0, 0, "failure", false)
	defer srv.Close()

	if err := reg.Add(sampleProj("fail-ci")); err != nil {
		t.Fatal(err)
	}
	s.ScanAll(context.Background())

	got, _ := reg.Get("fail-ci")
	if got.CIStatus != project.CIStatusFailing {
		t.Errorf("CIStatus = %q, want failing", got.CIStatus)
	}
}

func TestScanner_SkipsNonScannable(t *testing.T) {
	s, reg, srv := newTestEnv(t, 99, 99, "success", false)
	defer srv.Close()

	// Pre-archive a project — scanner should skip it via IsScannable()
	p := sampleProj("skipme")
	p.Stage = project.StageArchived
	if err := reg.Add(p); err != nil {
		t.Fatal(err)
	}
	s.ScanAll(context.Background())

	got, _ := reg.Get("skipme")
	if got.LatestVersion != "" {
		t.Errorf("archived stage should be skipped, got ver=%q", got.LatestVersion)
	}
}

func TestScanner_Start_StopsOnContextCancel(t *testing.T) {
	s, _, srv := newTestEnv(t, 0, 0, "", false)
	defer srv.Close()
	ctx, cancel := context.WithCancel(context.Background())

	done := make(chan struct{})
	go func() {
		s.Start(ctx)
		close(done)
	}()

	time.Sleep(50 * time.Millisecond)
	cancel()
	s.Stop()
	select {
	case <-done:
	case <-time.After(2 * time.Second):
		t.Fatal("Start did not stop within 2s of cancel")
	}
}

// concurrent counter for verifying max concurrency
type concMetrics struct {
	current atomic.Int32
	max     atomic.Int32
}

func (c *concMetrics) IncScanned() {
	n := c.current.Add(1)
	for {
		m := c.max.Load()
		if n <= m || c.max.CompareAndSwap(m, n) {
			break
		}
	}
}
func (c *concMetrics) IncFailed()                        {}
func (c *concMetrics) SetLastScanDuration(time.Duration) {}
func (c *concMetrics) SetLastScanAt(time.Time)           {}

// ─── helper / interface coverage ─────────────────────────────

func TestNoopMetrics(t *testing.T) {
	// 単純に呼出が panic しないことを保証
	var m noopMetrics
	m.IncScanned()
	m.IncFailed()
	m.SetLastScanDuration(time.Second)
	m.SetLastScanAt(time.Now())
}

func TestMapCIStatus_AllInputs(t *testing.T) {
	tests := map[string]project.CIStatus{
		"success":         project.CIStatusPassing,
		"SUCCESS":         project.CIStatusPassing,
		"Success":         project.CIStatusPassing,
		"failure":         project.CIStatusFailing,
		"timed_out":       project.CIStatusFailing,
		"startup_failure": project.CIStatusFailing,
		"action_required": project.CIStatusFailing,
		"":                project.CIStatusUnknown,
		"pending":         project.CIStatusUnknown,
		"queued":          project.CIStatusUnknown,
		"in_progress":     project.CIStatusUnknown,
		"skipped":         project.CIStatusUnknown,
		"cancelled":       project.CIStatusUnknown,
		"random_garbage":  project.CIStatusUnknown,
	}
	for in, want := range tests {
		if got := mapCIStatus(in); got != want {
			t.Errorf("mapCIStatus(%q): got %q want %q", in, got, want)
		}
	}
}
