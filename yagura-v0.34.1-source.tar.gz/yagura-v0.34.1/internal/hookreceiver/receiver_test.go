package hookreceiver

import (
	"bytes"
	"encoding/json"
	"io"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"
)

func fixedNowH() time.Time {
	return time.Date(2026, 5, 13, 12, 0, 0, 0, time.UTC)
}

type fakeLookup struct {
	m map[string]string // path prefix → slug
}

func (f *fakeLookup) ResolveByPath(cwd string) (string, bool) {
	for prefix, slug := range f.m {
		if strings.HasPrefix(cwd, prefix) {
			return slug, true
		}
	}
	return "", false
}

func newRcv(t *testing.T) (*Receiver, string) {
	t.Helper()
	dir := t.TempDir()
	path := filepath.Join(dir, "hooks.jsonl")
	lookup := &fakeLookup{m: map[string]string{
		"/home/m/breeze":  "breeze",
		"/home/m/tessera": "tessera",
	}}
	r, err := NewReceiver(path, lookup, 100)
	if err != nil {
		t.Fatal(err)
	}
	r.NowFn = fixedNowH
	return r, path
}

// ─── Basic POST handling ───────────────────────────

func TestHandle_PreToolUse(t *testing.T) {
	r, _ := newRcv(t)
	payload := `{
		"hook_event_name": "PreToolUse",
		"session_id": "sess-1",
		"cwd": "/home/m/breeze/src",
		"tool_name": "Bash",
		"tool_input": {"command": "ls"}
	}`
	req := httptest.NewRequest(http.MethodPost, "/hooks/claude-code", strings.NewReader(payload))
	w := httptest.NewRecorder()
	r.Handle(w, req)
	if w.Code != http.StatusOK {
		t.Fatalf("status: %d, body=%s", w.Code, w.Body.String())
	}
	if !bytes.Contains(w.Body.Bytes(), []byte("{}")) {
		t.Errorf("response should be empty object: %s", w.Body.String())
	}
	st := r.ProjectStats("breeze")
	if st.Total != 1 || st.ByEvent["PreToolUse"] != 1 || st.ByTool["Bash"] != 1 {
		t.Errorf("stats not updated: %+v", st)
	}
}

func TestHandle_RejectsGET(t *testing.T) {
	r, _ := newRcv(t)
	req := httptest.NewRequest(http.MethodGet, "/hooks/claude-code", http.NoBody)
	w := httptest.NewRecorder()
	r.Handle(w, req)
	if w.Code != http.StatusMethodNotAllowed {
		t.Errorf("expected 405, got %d", w.Code)
	}
}

func TestHandle_InvalidJSON(t *testing.T) {
	r, _ := newRcv(t)
	req := httptest.NewRequest(http.MethodPost, "/hooks/claude-code", strings.NewReader(`{not json`))
	w := httptest.NewRecorder()
	r.Handle(w, req)
	if w.Code != http.StatusBadRequest {
		t.Errorf("expected 400, got %d", w.Code)
	}
}

func TestHandle_UnknownProject(t *testing.T) {
	r, _ := newRcv(t)
	payload := `{"hook_event_name":"Stop","session_id":"x","cwd":"/tmp/nowhere"}`
	req := httptest.NewRequest(http.MethodPost, "/hooks/claude-code", strings.NewReader(payload))
	w := httptest.NewRecorder()
	r.Handle(w, req)
	if w.Code != http.StatusOK {
		t.Fatalf("status: %d", w.Code)
	}
	st := r.ProjectStats("unknown")
	if st.Total != 1 {
		t.Errorf("unknown bucket: %+v", st)
	}
}

func TestHandle_PostToolUseDuration(t *testing.T) {
	r, _ := newRcv(t)
	payload := `{
		"hook_event_name": "PostToolUse",
		"session_id": "s",
		"cwd": "/home/m/breeze",
		"tool_name": "Bash",
		"duration_ms": 1234
	}`
	req := httptest.NewRequest(http.MethodPost, "/hooks/claude-code", strings.NewReader(payload))
	r.Handle(httptest.NewRecorder(), req)
	st := r.ProjectStats("breeze")
	if st.TotalMS != 1234 {
		t.Errorf("duration: %d", st.TotalMS)
	}
}

func TestHandle_PostToolUseFailureFlagsError(t *testing.T) {
	r, _ := newRcv(t)
	payload := `{
		"hook_event_name": "PostToolUseFailure",
		"session_id": "s",
		"cwd": "/home/m/breeze",
		"tool_name": "Bash"
	}`
	req := httptest.NewRequest(http.MethodPost, "/hooks/claude-code", strings.NewReader(payload))
	r.Handle(httptest.NewRecorder(), req)
	st := r.ProjectStats("breeze")
	if st.ErrorCount != 1 {
		t.Errorf("error_count: %d", st.ErrorCount)
	}
}

func TestHandle_ToolResponseIsErrorFlagged(t *testing.T) {
	r, _ := newRcv(t)
	payload := `{
		"hook_event_name": "PostToolUse",
		"session_id": "s",
		"cwd": "/home/m/breeze",
		"tool_name": "Bash",
		"tool_response": {"is_error": true, "stderr": "permission denied"}
	}`
	req := httptest.NewRequest(http.MethodPost, "/hooks/claude-code", strings.NewReader(payload))
	r.Handle(httptest.NewRecorder(), req)
	st := r.ProjectStats("breeze")
	if st.ErrorCount != 1 {
		t.Errorf("is_error should bump error count: %+v", st)
	}
}

// ─── Persistence ───────────────────────────────────

func TestPersistAndReplay(t *testing.T) {
	r, path := newRcv(t)
	for range 3 {
		req := httptest.NewRequest(http.MethodPost, "/hooks/claude-code",
			strings.NewReader(`{"hook_event_name":"PreToolUse","cwd":"/home/m/breeze","tool_name":"Bash","session_id":"s"}`))
		r.Handle(httptest.NewRecorder(), req)
	}
	// replay
	r2, err := NewReceiver(path, &fakeLookup{m: map[string]string{"/home/m/breeze": "breeze"}}, 100)
	if err != nil {
		t.Fatal(err)
	}
	st := r2.ProjectStats("breeze")
	if st.Total != 3 {
		t.Errorf("replay total: %d", st.Total)
	}
}

func TestReplay_CorruptLineSkipped(t *testing.T) {
	dir := t.TempDir()
	path := filepath.Join(dir, "h.jsonl")
	good := `{"hook_event_name":"Stop","project":"x","timestamp":"2026-05-13T12:00:00Z"}`
	os.WriteFile(path, []byte("{not_json\n"+good+"\n"), 0o644)
	r, err := NewReceiver(path, nil, 10)
	if err != nil {
		t.Fatal(err)
	}
	if r.ProjectStats("x").Total != 1 {
		t.Error("good entry should survive corrupt line")
	}
}

// ─── In-memory mode ────────────────────────────────

func TestInMemoryMode(t *testing.T) {
	r, err := NewReceiver("", nil, 10)
	if err != nil {
		t.Fatal(err)
	}
	req := httptest.NewRequest(http.MethodPost, "/hooks/claude-code",
		strings.NewReader(`{"hook_event_name":"Stop"}`))
	r.Handle(httptest.NewRecorder(), req)
	if r.ProjectStats("unknown").Total != 1 {
		t.Error("in-memory should still aggregate")
	}
}

// ─── Ring buffer eviction ─────────────────────────

func TestRingBufferEviction(t *testing.T) {
	r, err := NewReceiver("", nil, 3)
	if err != nil {
		t.Fatal(err)
	}
	r.NowFn = fixedNowH
	for range 5 {
		req := httptest.NewRequest(http.MethodPost, "/hooks/claude-code",
			strings.NewReader(`{"hook_event_name":"PreToolUse","tool_name":"Bash"}`))
		r.Handle(httptest.NewRecorder(), req)
	}
	r.mu.RLock()
	got := len(r.recent)
	r.mu.RUnlock()
	if got != 3 {
		t.Errorf("ring should cap at 3, got %d", got)
	}
}

// ─── Timeline & TopTools ──────────────────────────

func TestTimeline_FiltersBySlugAndEvent(t *testing.T) {
	r, _ := newRcv(t)
	send := func(event, cwd, tool string) {
		body, _ := json.Marshal(map[string]any{
			"hook_event_name": event, "cwd": cwd, "tool_name": tool, "session_id": "s",
		})
		req := httptest.NewRequest(http.MethodPost, "/hooks/claude-code", bytes.NewReader(body))
		r.Handle(httptest.NewRecorder(), req)
	}
	send("PreToolUse", "/home/m/breeze", "Bash")
	send("PostToolUse", "/home/m/breeze", "Bash")
	send("PreToolUse", "/home/m/tessera", "Read")
	tl := r.Timeline("breeze", fixedNowH().Add(-1*time.Hour), "", 10)
	if len(tl) != 2 {
		t.Errorf("breeze timeline: %d", len(tl))
	}
	tl = r.Timeline("breeze", fixedNowH().Add(-1*time.Hour), "PreToolUse", 10)
	if len(tl) != 1 {
		t.Errorf("breeze PreToolUse only: %d", len(tl))
	}
}

func TestTopTools_GlobalAndPerProject(t *testing.T) {
	r, _ := newRcv(t)
	send := func(cwd, tool string) {
		body, _ := json.Marshal(map[string]any{
			"hook_event_name": "PreToolUse", "cwd": cwd, "tool_name": tool,
		})
		r.Handle(httptest.NewRecorder(), httptest.NewRequest(http.MethodPost, "/h", bytes.NewReader(body)))
	}
	send("/home/m/breeze", "Bash")
	send("/home/m/breeze", "Bash")
	send("/home/m/breeze", "Read")
	send("/home/m/tessera", "Bash")

	top := r.TopTools("", 5)
	if len(top) < 2 || top[0].Tool != "Bash" {
		t.Errorf("global top: %v", top)
	}
	if top[0].Count != 3 {
		t.Errorf("global Bash count: %d", top[0].Count)
	}

	top = r.TopTools("breeze", 5)
	if top[0].Tool != "Bash" || top[0].Count != 2 {
		t.Errorf("breeze top: %v", top)
	}
}

func TestAllStats(t *testing.T) {
	r, _ := newRcv(t)
	body := `{"hook_event_name":"Stop","cwd":"/home/m/breeze"}`
	r.Handle(httptest.NewRecorder(),
		httptest.NewRequest(http.MethodPost, "/h", strings.NewReader(body)))
	all := r.AllStats()
	if _, ok := all["breeze"]; !ok {
		t.Error("breeze missing from AllStats")
	}
}

// helper imports
var _ = io.EOF
var _ = json.NewEncoder
