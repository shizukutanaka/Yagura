# ADR-0007: Semantic Versioning and API Stability

- **Status**: Proposed
- **Date**: 2026-06-03
- **Deciders**: yagura maintainers

## Context

Through the 0.x series yagura grew to 46 MCP tools and 11 HTTP routes, and
freely made breaking changes between minor releases (tool renames, schema
tweaks, response-shape changes). That was acceptable while the only consumer
was the maintainer's own Claude Code setup.

External consumers now depend on the surface:

- MCP clients (Claude Code / Windsurf) bind to **tool names** and **input
  schemas** via `tools/list`.
- CI pipelines call the **HTTP API** (`/sbom`, `/gha-audit`, `/pin-drift`)
  directly with `curl`.

Without a stability contract, every release risks silently breaking these
integrations. We need (a) a versioning policy that states what "breaking"
means for each surface, and (b) a mechanical gate that surfaces accidental
breaks in PR review.

Constraints: ADR-0001 (zero external dependencies) — the gate and any spec
generation must use only the Go standard library.

## Decision

1. **Adopt Semantic Versioning (semver) from v1.0.0 onward.** v1.0.0 is the
   API-stabilization gate; after it, the public surface changes only per the
   rules below.

2. **Define the public, versioned surface explicitly:**
   - MCP `tools/list`: each tool's **name** and **input schema**.
   - HTTP API: route paths, accepted methods, request bodies, and documented
     response fields (see `docs/openapi.yaml`).
   - `RegisterDefaultTools` ordering (already an immutable trust-base property).

   *Not* part of the contract (may change in any release): human-facing tool
   `description` prose, internal package layout, audit-log on-disk format,
   dashboard HTML, and Prometheus metric help text.

3. **Breaking vs non-breaking:**
   - **MAJOR**: remove/rename a tool, remove/rename a schema field, tighten a
     type or make an optional field required, remove an HTTP route/method, or
     change a documented response field's type.
   - **MINOR**: add a new tool, add an optional schema field, add a new HTTP
     route, or add a new response field.
   - **PATCH**: bug fixes and prose/doc changes with no surface change.

4. **Mechanical gate:** `internal/mcp.TestToolsListContract` snapshots the
   name+schema contract to `internal/mcp/testdata/tools_list_contract.golden.json`.
   Any drift fails the test; an intentional change is accepted by regenerating
   the golden (`go test ./internal/mcp -run TestToolsListContract -update-golden`),
   making every contract change a reviewed diff in the PR.

5. **Deprecation policy (post-1.0):** a removed/renamed tool keeps a working
   alias for at least one MAJOR cycle, emitting a deprecation note, before the
   alias is dropped.

## Consequences

### Positive
- Accidental API breaks are caught in CI before release.
- Consumers get a clear, documented stability guarantee and migration window.
- The golden diff doubles as human-readable release notes for API changes.

### Negative
- Adding/changing tools now requires regenerating the golden (one extra step,
  already documented in the failure message).
- MAJOR bumps carry a real migration cost (alias maintenance for one cycle).

### Neutral
- No runtime behavior change; the gate is test-only, so reproducible-build
  SHAs are unaffected.

## Alternatives considered

### Include tool descriptions in the contract
Rejected: descriptions are prose tuned frequently for LLM tool-selection
quality; pinning them would create constant golden churn without protecting
any real consumer contract.

### Hand-maintain a compatibility checklist instead of a golden test
Rejected: relies on reviewer diligence and drifts from reality. A golden test
is deterministic and self-updating.

### Generate OpenAPI/JSON-Schema from a third-party framework
Rejected: violates ADR-0001. `docs/openapi.yaml` is hand-authored and kept in
sync via review; the HTTP surface is small (3 CI routes + operational routes).
