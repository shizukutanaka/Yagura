package telemetry

import (
	"context"
	"errors"
	"testing"
	"time"
)

// ─── Attribute constructors ──────────────────────────────────

func TestAttributeConstructors(t *testing.T) {
	a := String("k", "v")
	if a.Key != "k" || a.Value != "v" {
		t.Errorf("String: %+v", a)
	}
	if Int("k", 42).Value != int64(42) {
		t.Error("Int")
	}
	if Int64("k", 42).Value != int64(42) {
		t.Error("Int64")
	}
	if Float64("k", 3.14).Value != 3.14 {
		t.Error("Float64")
	}
	if !Bool("k", true).Value.(bool) {
		t.Error("Bool")
	}
}

// ─── Noop ───────────────────────────────────────────────────

func TestNoopTracer_AllOps(t *testing.T) {
	tr := NewNoopTracer()
	ctx := context.Background()
	ctx2, span := tr.StartSpan(ctx, "test")
	if ctx2 != ctx {
		t.Error("noop should return same ctx")
	}
	// Should not crash
	span.SetAttributes(String("k", "v"))
	span.SetStatus(StatusOK, "ok")
	span.RecordError(errors.New("test"))
	span.End()
	span.End() // idempotent
}

// ─── Recording ──────────────────────────────────────────────

func TestRecordingTracer_BasicSpan(t *testing.T) {
	tr := NewRecordingTracer()
	_, span := tr.StartSpan(context.Background(), "operation",
		WithAttributes(String("user", "alice")))
	span.SetAttributes(Int("count", 5))
	span.End()

	spans := tr.Spans()
	if len(spans) != 1 {
		t.Fatalf("expected 1 span, got %d", len(spans))
	}
	s := spans[0]
	if s.Name != "operation" {
		t.Errorf("name: %s", s.Name)
	}
	if len(s.Attributes) != 2 {
		t.Errorf("attributes: %+v", s.Attributes)
	}
	if s.EndTime.IsZero() {
		t.Error("EndTime should be set")
	}
}

func TestRecordingTracer_SpanKind(t *testing.T) {
	tr := NewRecordingTracer()
	_, span := tr.StartSpan(context.Background(), "http", WithSpanKind(SpanKindServer))
	span.End()
	if tr.Spans()[0].Kind != SpanKindServer {
		t.Errorf("kind: %v", tr.Spans()[0].Kind)
	}
}

func TestRecordingTracer_Status(t *testing.T) {
	tr := NewRecordingTracer()
	_, span := tr.StartSpan(context.Background(), "op")
	span.SetStatus(StatusError, "failed")
	span.End()
	s := tr.Spans()[0]
	if s.Status != StatusError {
		t.Errorf("status: %v", s.Status)
	}
	if s.StatusDesc != "failed" {
		t.Errorf("desc: %s", s.StatusDesc)
	}
}

func TestRecordingTracer_RecordError(t *testing.T) {
	tr := NewRecordingTracer()
	_, span := tr.StartSpan(context.Background(), "op")
	span.RecordError(errors.New("boom"))
	span.RecordError(nil) // should be ignored
	span.End()
	if len(tr.Spans()[0].Errors) != 1 {
		t.Errorf("expected 1 error, got %d", len(tr.Spans()[0].Errors))
	}
}

func TestRecordingTracer_MultiSpan(t *testing.T) {
	tr := NewRecordingTracer()
	for i := 0; i < 5; i++ {
		_, sp := tr.StartSpan(context.Background(), "op")
		sp.End()
	}
	if len(tr.Spans()) != 5 {
		t.Errorf("expected 5, got %d", len(tr.Spans()))
	}
}

func TestRecordingTracer_Reset(t *testing.T) {
	tr := NewRecordingTracer()
	_, sp := tr.StartSpan(context.Background(), "op")
	sp.End()
	tr.Reset()
	if len(tr.Spans()) != 0 {
		t.Error("Reset should clear spans")
	}
}

func TestRecordingTracer_EndIdempotent(t *testing.T) {
	tr := NewRecordingTracer()
	_, sp := tr.StartSpan(context.Background(), "op")
	sp.End()
	first := tr.Spans()[0].EndTime
	time.Sleep(1 * time.Millisecond)
	sp.End()
	if !tr.Spans()[0].EndTime.Equal(first) {
		t.Error("second End() should be no-op")
	}
}

func TestSpanOption_WithStartTime(t *testing.T) {
	tr := NewRecordingTracer()
	fixed := time.Date(2020, 1, 1, 0, 0, 0, 0, time.UTC)
	_, sp := tr.StartSpan(context.Background(), "op", WithStartTime(fixed))
	sp.End()
	if !tr.Spans()[0].StartTime.Equal(fixed) {
		t.Errorf("StartTime: %v", tr.Spans()[0].StartTime)
	}
}

func TestEndOption_WithEndTime(t *testing.T) {
	tr := NewRecordingTracer()
	_, sp := tr.StartSpan(context.Background(), "op")
	fixed := time.Date(2030, 1, 1, 0, 0, 0, 0, time.UTC)
	sp.End(WithEndTime(fixed))
	if !tr.Spans()[0].EndTime.Equal(fixed) {
		t.Errorf("EndTime: %v", tr.Spans()[0].EndTime)
	}
}
