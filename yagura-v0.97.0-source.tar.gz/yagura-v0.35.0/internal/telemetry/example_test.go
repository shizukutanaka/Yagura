package telemetry_test

import (
	"context"
	"errors"
	"fmt"

	"github.com/shizukutanaka/yagura/internal/telemetry"
)

// ExampleNewNoopTracer は本番用 no-op tracer の使用例。
//
// no-op tracer は zero-allocation で、ホットパスに置いてもオーバーヘッドがない。
func ExampleNewNoopTracer() {
	tr := telemetry.NewNoopTracer()
	_, span := tr.StartSpan(context.Background(), "my.operation")
	defer span.End()

	span.SetAttributes(telemetry.String("user.id", "alice"))
	span.SetStatus(telemetry.StatusOK, "")
	fmt.Println("no-op tracing does nothing visible")
	// Output: no-op tracing does nothing visible
}

// ExampleNewRecordingTracer はテストで使う記録型 tracer の例。
func ExampleNewRecordingTracer() {
	tr := telemetry.NewRecordingTracer()
	_, span := tr.StartSpan(context.Background(), "user.signup",
		telemetry.WithSpanKind(telemetry.SpanKindServer),
		telemetry.WithAttributes(telemetry.Int("user.id", 42)))
	span.RecordError(errors.New("email taken"))
	span.SetStatus(telemetry.StatusError, "duplicate email")
	span.End()

	spans := tr.Spans()
	fmt.Println("recorded spans:", len(spans))
	fmt.Println("name:", spans[0].Name)
	fmt.Println("status:", spans[0].Status)
	fmt.Println("errors:", len(spans[0].Errors))
	// Output:
	// recorded spans: 1
	// name: user.signup
	// status: 2
	// errors: 1
}
